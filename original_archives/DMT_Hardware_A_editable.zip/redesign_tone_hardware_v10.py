"""One integrated pipeline schematic: one figure, no insets or subpanels."""
from pathlib import Path
import json
import zipfile

import fitz
from pypdf import PdfReader, PdfWriter
import build_dmt_figures as d

OUT=Path(__file__).resolve().parent/'output/system_hardware/two_figures'
OUT.mkdir(parents=True,exist_ok=True)
d.OUT=OUT
NAME='DMT_Hardware_A_Tone_datapath'
F=d.Figure(NAME,1420,530)

INK='#222a2f'; GRAY='#64717a'; RULE='#b9c5ca'
WHITE='#ffffff'; LIGHT='#f8fafb'; BLUE='#245c78'; BLUE_BG='#edf5f9'

def tx(x,y,s,z=18,b=False,c=INK,a='start',mw=None):
    return F.text(x,y,s,z,'Bold' if b else 'Sans',c,a,mw)
def box(x,y,w,h,fill=WHITE,stroke=INK,sw=1.35,layer='shape'):
    F.rect(x,y,w,h,fill,stroke,sw,layer=layer)
def wire(*pts,c=INK,w=1.55,arrow=True):
    F.line(list(pts),c,w,arrow)
def dot(x,y,c=BLUE):F.dot(x,y,c)
def bar(x,y,h):
    box(x,y,4,h,BLUE,BLUE,0,layer='shape')
def regcell(x,y,w,h,s,z=18):
    box(x,y,w,h,BLUE_BG,BLUE,1.2)
    bar(x+5,y+5,h-10)
    tx(x+w/2+2,y+h/2+z*.34,s,z,True,BLUE,'middle',w-19)
def bank(x,y,w,h,kind):
    box(x,y,w,h,WHITE,INK,1.35)
    tx(x+w/2,y+25,f'{kind}[M]',18,True,INK,'middle',w-12)
    wire((x+9,y+35),(x+w-9,y+35),c=RULE,w=.8,arrow=False)
    wire((x+w/2,y+35),(x+w/2,y+h-7),c=RULE,w=.8,arrow=False)
    wire((x+9,y+59),(x+w-9,y+59),c=RULE,w=.8,arrow=False)
    for xx,yy,t in ((x+w/4,y+53,f'{kind}<sub>256</sub>'),
                    (x+3*w/4,y+53,f'{kind}<sub>64</sub>'),
                    (x+w/4,y+78,f'{kind}<sub>16</sub>'),
                    (x+3*w/4,y+78,f'{kind}<sub>4</sub>')):
        tx(xx,yy,t,15.5,False,GRAY,'middle',w/2-12)
def mul(x,y,dims):
    F.circle(x,y,21,WHITE,INK,1.55)
    tx(x,y+9,'×',29,True,INK,'middle')
    tx(x,y+52,dims,16,False,GRAY,'middle')
def nettag(x,y,s):
    box(x,y,30,23,BLUE_BG,BLUE,1)
    tx(x+15,y+17,s,15.5,True,BLUE,'middle',24)

# One integrated drawing: pale register columns align tier, arithmetic and
# valid state. Component fills distinguish storage from combinational logic.
tx(34,42,'Per-tone QAM selection and BER engine',22,True)
tx(1385,42,'one tone / clock   ·   three register stages',16,False,GRAY,'end')
wire((30,57),(1390,57),c=RULE,w=.9,arrow=False)
tx(39,92,'Parallel qualification',18,True)
tx(504,92,'Y generation',18,True)
tx(839,92,'Fractional BER path',18,True)
for x,w,title in ((410,66,'R1'),(711,92,'R2'),(1270,88,'R3')):
    box(x,104,w,395,BLUE_BG,BLUE,.95,layer='background')
    tx(x+w/2,124,title,18,True,BLUE,'middle')

# Four independent 33-bit threshold add/compare lanes. Base and margin are
# separated within each row, and each cell drives one priority input.
tx(94,146,'θ<sup>0</sup><sub>M</sub> + m<sub>M</sub>',16,False,GRAY,'middle')
tx(180,146,'ADD',15,False,GRAY,'middle')
tx(271,146,'CMP · 33 bit',15,False,GRAY,'middle')
tx(369,146,'PRI',15,True,GRAY,'middle')
centres=(185,243,301,359)
orders=(256,64,16,4); bases=(24,18,12,6)
box(347,159,47,224,WHITE,INK,1.4)
for i,(yc,m,base) in enumerate(zip(centres,orders,bases)):
    box(37,yc-24,111,48,LIGHT,INK,1.25)
    wire((37,yc),(148,yc),c=RULE,w=.8,arrow=False)
    tx(92.5,yc-6,f'{base} dB',17,True,INK,'middle',99)
    tx(92.5,yc+17,f'm<sub>{m}</sub>',17,False,INK,'middle',99)
    F.circle(180,yc,17,WHITE,INK,1.35)
    tx(180,yc+7,'+',23,False,INK,'middle')
    wire((148,yc-11),(160,yc-11),(164,yc-7),w=1.2)
    wire((148,yc+11),(160,yc+11),(164,yc+7),w=1.2)
    wire((197,yc),(218,yc),w=1.35)
    box(218,yc-20,105,40,WHITE,INK,1.25)
    tx(270.5,yc+6,f'γ<sub>dB</sub> ≥ θ<sub>{m}</sub>',16,True,INK,'middle',93)
    wire((323,yc),(347,yc),w=1.35)
    tx(370.5,yc+6,str(m),16,True,INK,'middle')
    if i<3:wire((353,yc+29),(388,yc+29),c=RULE,w=.7,arrow=False)
tx(39,399,'γ<sub>k,lin</sub>  Q16',17,True)
wire((39,414),(402,414),(402,344),(410,344),w=1.45)
wire((394,185),(402,185),(402,150),(410,150),c=BLUE,w=1.35)

# Register cuts and tier trajectory: M1 selects K and propagates to M2;
# M2 selects C, feeds the OFF gate and propagates to M3.
regcell(417,132,52,40,'M<sub>1</sub>')
regcell(417,322,52,45,'γ<sub>lin</sub>',17)
regcell(417,453,52,36,'v<sub>1</sub>',16)
wire((469,151),(711,151),c=BLUE,w=1.5)
dot(559,151)
wire((559,151),(559,190),c=BLUE,w=1.25)
bank(506,190,127,86,'K')
wire((602,276),(602,299),(650,299),(650,323),w=1.35)
wire((469,344),(629,344),w=1.55)
mul(650,344,'16 × 32')
wire((671,344),(699,344),w=1.45)
wire((699,288),(699,379),w=1.2,arrow=False)
dot(699,344,INK)
for yy in (288,337,378):wire((699,yy),(711,yy),w=1.25)
tx(757,238,'Y[47:0]',16,True,GRAY,'middle')

regcell(718,132,78,40,'M<sub>2</sub>')
for yy,s in ((269,'s ≥ 24'),(311,'q[4:0]'),(353,'f[4:0]')):
    regcell(718,yy,78,40,s,16)
regcell(718,453,78,36,'v<sub>2</sub>',16)
wire((796,151),(1270,151),c=BLUE,w=1.5)
dot(900,151)
wire((900,151),(900,190),c=BLUE,w=1.25)
bank(846,190,127,86,'C')
nettag(805,283,'s')
nettag(805,325,'q')
wire((796,373),(825,373),(825,355),(846,355),c=BLUE,w=1.3)

box(846,320,127,69,WHITE,INK,1.35)
tx(909.5,347,'EXP LUT',18,True,INK,'middle')
tx(909.5,373,'32 × 17-bit',15,False,GRAY,'middle')
wire((938,276),(938,301),(1030,301),(1030,323),w=1.35)
wire((973,353),(1009,353),w=1.45)
mul(1030,353,'16 × 17')
wire((1051,353),(1073,353),w=1.45)
box(1073,326,69,54,WHITE,INK,1.3)
tx(1107.5,348,'[31:8]',15.5,False,GRAY,'middle',57)
tx(1107.5,371,'Q24',15.5,True,INK,'middle')
wire((1142,353),(1155,353),w=1.45)
box(1155,326,51,54,WHITE,INK,1.3)
tx(1180.5,359,'≫ q',17,True,INK,'middle',43)
nettag(1165,296,'q')
wire((1206,353),(1217,353),w=1.45)
F.poly([(1217,327),(1255,340),(1255,366),(1217,379)],WHITE,INK,1.35)
tx(1236,359,'0/p',15,True,INK,'middle')
nettag(1218,296,'s')
wire((1239,151),(1239,290),c=BLUE,w=1.15,arrow=False)
tx(1262,288,'M=0',13.5,False,BLUE,'end')
wire((1255,353),(1277,353),w=1.45)

regcell(1277,132,74,40,'M<sub>k</sub>')
regcell(1277,323,74,58,'P<sub>b,k</sub>',17)
tx(1314,372,'Q24',14,False,BLUE,'middle')
regcell(1277,453,74,36,'v<sub>3</sub>',16)
wire((1351,151),(1385,151),c=BLUE,w=1.3)
wire((1351,353),(1385,353),c=BLUE,w=1.3)
wire((1351,471),(1385,471),c=BLUE,w=1.3)

# Valid is an independent one-per-cycle pipeline lane, leaving arithmetic
# arrows and tier fan-outs untouched.
tx(40,475,'valid',17,True,GRAY)
wire((97,471),(417,471),c=BLUE,w=1.3)
wire((469,471),(718,471),c=BLUE,w=1.3)
wire((796,471),(1277,471),c=BLUE,w=1.3)
tx(41,520,'base θ<sup>0</sup> = [24, 18, 12, 6] dB  ·  margins Q16  ·  tier code: OFF/4/16/64/256',16,False,GRAY)

res=F.save()
pdf=OUT/(NAME+'.pdf')
rd=PdfReader(pdf);wr=PdfWriter()
for p in rd.pages:
    p.scale_by(180/210);wr.add_page(p)
with pdf.open('wb') as s:wr.write(s)
doc=fitz.open(pdf)
doc[0].get_pixmap(dpi=360,alpha=False).save(OUT/(NAME+'.png'))
doc[0].get_pixmap(matrix=fitz.Matrix(2.55,2.55),alpha=False).save(OUT/(NAME+'_preview.png'))
(OUT/(NAME+'_caption.md')).write_text(
    '**Suggested caption.** Integrated three-stage per-tone QAM/BER '
    'microarchitecture. Four parallel 33-bit add/compare lanes produce '
    'qualification bits for the priority encoder at R1. The tier selects '
    'K and C constants from separate four-entry banks and propagates to R3. '
    'A 16×32 product generates Y; R2 registers its saturation flag, integer '
    'shift and 5-bit fractional LUT address. The 32×17-bit exponential LUT '
    'and selected C feed a 16×17 product. Its [31:8] Q24 slice is shifted '
    'by q and zeroed when s or M=0, while valid advances through the same '
    'three register stages. Matching blue s/q labels denote the same nets.\n',
    encoding='utf-8')
(OUT/'layout_checks_a_v10.json').write_text(json.dumps(res,indent=2))
with zipfile.ZipFile(OUT/'DMT_Hardware_A_editable.zip','w',zipfile.ZIP_DEFLATED) as z:
    for suffix in ('.pdf','.svg','.png','_caption.md'):
        p=OUT/(NAME+suffix);z.write(p,p.name)
    for p in (Path(__file__),Path(d.__file__)):
        z.write(p,p.name)
print(json.dumps(res,indent=2))
