# DMT 하드웨어 도면 수정본

제공된 이미지의 4분할 형식과 회로 정보 밀도를 기준으로 다시 구성했습니다. 큰 발표용 제목, 일반적인 상자 나열 및 장문의 설명 영역을 없애고 실제 연산·저장·선택 관계를 배치했습니다.

## 파일 안내

- `DMT_02_hardware.pdf`: 하드웨어 단독 벡터 PDF, 폭 210 mm.
- `DMT_02_hardware.svg`: 글자와 도형을 수정할 수 있는 SVG 원본.
- `DMT_02_hardware.png`: 3200 px 미리보기.
- `DMT_algorithm_hardware.pdf`: 알고리즘·하드웨어 2페이지 PDF.
- `paper/`: 폭 180 mm 하드웨어 PDF 및 큰 페이지 제목을 제외한 알고리즘 도면.
- `panels/`: (a)~(d) 각 패널의 독립 SVG·PDF.
- `regenerate_all.py`: 두 그림과 통합 PDF 재생성 진입점.
- `draw_dense_hardware.py`: 새 하드웨어 도면 코드.
- `build_dmt_figures.py`: 공통 벡터 렌더러 및 알고리즘 도면 코드.

SVG 편집 시 DejaVu Sans를 사용하면 배치가 유지됩니다. PDF에는 글꼴이 포함되어 있습니다. 재생성에는 ReportLab, PyMuPDF, pypdf가 필요합니다.

## 확인한 RTL

아래 두 파일의 전체 내용을 읽고 대조했습니다. 두 항목의 수정 일자는 2026-08-13입니다. 이후의 다른 미제공 RTL까지 확인했다는 뜻은 아닙니다.

- `per_qam_datapath_balanced(2).v`
- `per_qam_margin_ctrl_balanced(2).v`

| 패널 | 내용 | RTL 대응 |
|---|---|---|
| (a) | 33-bit 임계값 합산, 비교, 우선순위 인코딩, R1 | `req_*`, `qual_*`, `next_m_tier`, `tier_st1`, `snr_linear_st1`, `valid_st1` |
| (b) | 16×32 곱셈, Y 필드, R2, 32×17 LUT, 16×17 곱셈, Q24 변환, 시프트·0 선택, R3 | `y_mult_wire`, `*_st2`, `exp_lut`, `c_lut_mult`, `base_q24`, `shifted_q24`, 출력 레지스터 |
| (c) | shift-add 가중치, 누산·목표 판정, tier 통계, 공유 곱셈기, 교차곱 저장, winner 선택 | `weighted_error_term`, `weighted_err_sum`, `total_bits_sum`, `target_met`, `err_sum_*`, `cnt_*`, `mul_product`, `cross_*`, `win12_*`, `win34_*` |
| (d) | active/baseline/best 마진, 선택 차수 증감·삽입, 최적 후보 통계, 적격성, FSM·scan 계수 | `o_margin_*`, `ref_base_margin_*`, `ref_best_margin_*`, `ref_best_*`, `ref_candidate_idx`, `state`, `req_cnt`, `rsp_cnt` |

## 표기와 동작

- `t=0,1,2,3,4`는 OFF, 4-, 16-, 64-, 256-QAM입니다. 빨간 예의 `t₁=3`은 64-QAM입니다.
- `γ_k,dB`, `γ_k,lin`은 각각 dB 및 선형 SNR 입력이고 Q16입니다. 비교 결과 비트가 BER 곱셈기에 들어가지 않습니다.
- `Y=K(t₁)γ₁`은 48-bit Q32입니다. `s=[Y[47:32]≥24]`, `q=Y[36:32]`, `f=Y[31:27]`를 저장합니다.
- `p_k`는 24-bit Q24 BER 코드입니다. `C(t₂)L[f]`에서 `[31:8]`을 취하고 q만큼 우측 시프트합니다. cutoff 또는 OFF이면 0입니다.
- `E_w`는 35-bit 가중 오류 합, `B`는 12-bit 총 비트 수입니다. `E_M`은 32-bit tier 오류 합, `N_M`은 9-bit 톤 수입니다.
- `G=2^24−10000·2^4=16,617,216`입니다. RTL 판정은 `(B=0) 또는 (10000 E_w≤GB)`이며 잔여 BER `2^-20`을 고려합니다.
- **공유 32×9 곱셈기 하나**가 여섯 곱을 순차 계산합니다. `6 multiply cycles`는 곱셈 수행 횟수입니다. 비교·갱신 상태가 별도로 있으므로 전체 worst-tier 결정이 6클록이라는 뜻은 아닙니다.
- 여섯 41-bit 결과는 `E256·N64`, `E64·N256`, `E16·N4`, `E4·N16`, `EH·NL`, `EL·NH`입니다. 공통 결과 버스를 공유하며 해당 사이클의 레지스터만 갱신합니다.
- `CMP/SEL`은 곱 비교와 연관된 `(t,E,N)` 레코드 선택을 묶은 조합 논리입니다. `V`는 count에 따른 빈 tier 제외 조건입니다. `WH/WL`의 E와 N은 같은 이름의 operand MUX 입력으로 돌아갑니다.
- `m_b`, `m*`는 baseline 및 best margin bank입니다. `e=[m_b,j≥Δ]`는 감소 후보 적격성입니다. `Δ_Q16=6554`는 약 0.1 dB입니다.
- `F`는 best-found 플래그입니다. refinement 판정 상태에서 `τ && (!F || B>B*)`이면 best 레코드를 갱신합니다. 후보 순서는 4→16→64→256이고 같은 B에서는 앞선 후보를 유지합니다.
- 논리 톤은 1~255, RTL 주소는 0~254입니다. 마지막 응답 조건은 `rsp=254`입니다.

## 추상화 범위

RTL 수준의 논문용 데이터패스입니다. 연산 폭, 파이프라인 필드, 명시적인 곱셈기 공유 및 마진 저장소는 코드에 근거합니다. 마진 읽기/쓰기 조건은 8:1 read 선택, selected-lane insert, 4:1 write 선택으로 묶었습니다. 실제 합성 후 모든 게이트 수와 셀 공유를 단정하는 넷리스트는 아닙니다. 반복되는 신호 이름은 같은 논리 신호이며 공통 clock/reset, 일부 enable·제어 연결은 생략했습니다. 타임아웃·출력 스트리밍 상태는 FSM 내부에 포함됩니다.

알고리즘 도면도 Q24 코드값, G의 정의, 감소 후보 적격성 및 best-B 선택 정책을 같은 RTL에 맞춰 보완했습니다.

## 영문 캡션

**Fig. X.** RTL-level organization of the proposed DMT bit-loading engine. (a) Per-QAM threshold comparison, priority encoding, and input capture (S1). (b) BER estimation with registered exponent fields (S2) and a shared 32-entry LUT, Q24 conversion, and output capture (S3). (c) Bit-weighted BER testing and worst-tier selection using one time-shared 32×9 multiplier. (d) Margin storage, candidate update and selection, and scan control. Red denotes an illustrative 64-QAM data path; dashed blue lines denote control signals. Repeated net names denote common signals. CMP/SEL selects the associated (tier, error sum, count) record after cross-product comparison and valid-count qualification. Common clock/reset and selected control connections are omitted for clarity.
