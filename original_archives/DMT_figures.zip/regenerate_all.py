from pathlib import Path
from pypdf import PdfWriter
import fitz
import build_dmt_figures as basic
import draw_dense_hardware as dense

for figure in [basic.algorithm(), dense.draw()]:
    result=figure.save()
    if result['text_checks']:
        raise RuntimeError(result['text_checks'])
out=basic.OUT
writer=PdfWriter()
writer.append(str(out/'DMT_01_algorithm.pdf'))
writer.append(str(out/'DMT_02_hardware.pdf'))
with (out/'DMT_algorithm_hardware.pdf').open('wb') as stream:
    writer.write(stream)
doc=fitz.open(out/'DMT_02_hardware.pdf')
page=doc[0]
page.get_pixmap(matrix=fitz.Matrix(3200/page.rect.width,3200/page.rect.width),alpha=False).save(out/'DMT_02_hardware.png')
print(out)
