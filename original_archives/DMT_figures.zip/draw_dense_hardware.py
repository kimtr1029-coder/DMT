"""Paper-oriented DMT schematic, grounded in the balanced Q24 RTL.

Source: per_qam_datapath_balanced(2).v and per_qam_margin_ctrl_balanced(2).v.
The four panels expand selection, the pipeline, shared arithmetic and storage.
"""
from pathlib import Path
import json, math
import build_dmt_figures as old
from reportlab.pdfbase import pdfmetrics

I='#111111'; R='#ce2626'; B='#075e98'; PALE='#ffe9e9'; GRAY='#f3f3f3'; W='#ffffff'
old.INK=I

class Schematic(old.Figure):
    def __init__(self):
        super().__init__('DMT_02_hardware',1600,1152)
    def mark(self):
        return {k:len(v) for k,v in self.layers.items()}
    def shift(self,mark,dy):
        for layer,start in mark.items():
            for q in self.layers[layer][start:]:
                if 'y' in q:q['y']+=dy
                if 'pts' in q:q['pts']=[(x,y+dy) for x,y in q['pts']]
    def T(self,x,y,s,sz=23,bold=False,c=I,a='start',maxw=None):
        return self.text(x,y,s,size=sz,font='Bold' if bold else 'Sans',color=c,anchor=a,maxw=maxw)
    def E(self,pts,c=I,arrow=True,dash=False,w=2.0):
        return self.line(pts,color=c,width=w,arrow=arrow,dash=dash)
    def cell(self,x,y,w,h,s,sz=24,c=I,fill=W,bold=False,reg=False):
        self.rect(x,y,w,h,fill=fill,stroke=c,sw=2.0)
        self.T(x+w/2,y+h/2+sz*.34,s,sz,bold,c,'middle',w-10)
        if reg: self.clock(x,y+h-10,c)
    def clock(self,x,y,c=I):
        self.poly([(x,y-6),(x+7,y),(x,y+6)],fill=W,stroke=c,sw=1.4)
    def op(self,x,y,label='×',r=22,c=I):
        self.circle(x,y,r,fill=W,stroke=c,sw=2.2)
        self.T(x,y+9,label,31,False,c,'middle')
    def mux(self,x,y,w,h,c=I,fill=W,label=None):
        self.poly([(x,y),(x+w,y+h*.22),(x+w,y+h*.78),(x,y+h)],fill=fill,stroke=c,sw=2)
        if label:self.T(x+w*.43,y+h/2+6,label,18,False,c,'middle')
    def panel2(self,x,y,w,h,l,title):
        self.rect(x,y,w,h,fill=W,stroke=I,sw=2.6,layer='background')
        self.T(x+17,y+33,f'({l}) {title}',25,True,maxw=w-35)
    def bus(self,x,y,w=12,c=I,label=None):
        self.E([(x-w/2,y+5),(x+w/2,y-5)],c,arrow=False,w=1.4)
        if label:self.T(x+8,y-8,str(label),17,c=c)
    def slots(self,x,y,width,h,labels,active=None,reg=False,sz=23):
        cw=width/len(labels)
        for i,s in enumerate(labels):
            c=R if i==active else I
            self.cell(x+i*cw,y,cw,h,s,sz,c,PALE if i==active else W,reg=reg)
        return cw


def draw():
    f=Schematic()
    f.panel2(16,16,770,474,'a','QAM selection and input registers (S1)')
    f.panel2(818,16,766,474,'b','Three-stage BER datapath')
    f.panel2(16,510,770,592,'c','BER test and shared worst-tier selection')
    f.panel2(818,510,766,592,'d','Margin registers and scan controller')

    # (a): all four real 33-bit threshold sums and comparisons.
    f.T(93,89,'θ<sub>M</sub><sup>(0)</sup>',24,a='middle')
    f.T(205,89,'m<sub>M</sub>',24,a='middle')
    f.T(590,80,'Priority',23,True,a='middle')
    f.T(590,106,'encoder',23,True,a='middle')
    f.rect(538,115,110,278,stroke=I,sw=2.2)
    f.rect(539,186,108,51,fill=PALE,stroke=None)
    for j,(m,base,y,q) in enumerate(zip([256,64,16,4],[24,18,12,6],[138,212,286,360],[0,1,1,1])):
        c=R if m==64 else I
        f.cell(50,y-22,86,44,f'{base} dB',23,c,PALE if m==64 else W,True)
        f.cell(165,y-22,81,44,f'm<sub>{m}</sub>',24,c,PALE if m==64 else W)
        f.op(284,y,'+',19,c)
        f.E([(136,y),(150,y),(150,y-31),(284,y-31),(284,y-19)],c)
        f.E([(246,y),(265,y)],c)
        f.E([(303,y),(349,y)],c)
        f.T(326,y-11,f'θ<sub>{m}</sub>',19,c=c,a='middle')
        f.cell(349,y-23,83,46,'≥',29,c)
        f.T(389,y-42,'γ<sub>k,dB</sub>',18,a='middle')
        f.E([(389,y-33),(389,y-23)])
        f.E([(432,y),(538,y)],c)
        f.T(484,y-10,f'c<sub>{m}</sub> = {q}',20,c=c,a='middle')
        f.T(590,y+8,str(m),25,m==64,c,'middle')
    f.E([(648,212),(692,212)],R)
    f.T(670,197,'3',20,c=R,a='middle')
    f.T(731,172,'R1',23,True,a='middle')
    f.cell(692,184,77,56,'t<sub>1</sub> = 3',22,R,PALE,reg=True)
    f.T(730,269,'64-QAM',22,True,R,'middle')
    f.T(731,301,'OFF: t = 0',18,a='middle')
    f.T(731,333,'3-bit code',18,a='middle')
    # Two other fields captured alongside the selected tier in Stage 1.
    f.E([(37,416),(765,416)],arrow=False,w=1.0)
    f.T(45,453,'γ<sub>k,lin</sub>',24)
    f.E([(120,445),(179,445)])
    f.bus(147,445,label=32)
    f.cell(179,427,104,37,'γ<sub>1</sub>',23,reg=True)
    f.T(346,453,'v<sub>in</sub>',23)
    f.E([(394,445),(435,445)])
    f.cell(435,427,89,37,'v<sub>1</sub>',23,reg=True)
    f.T(589,445,'θ: 33 bits',20)
    f.T(589,473,'SNR / m: Q16',20)

    # (b), stage 2: table selection and a 16x32 multiplication.
    f.T(852,91,'Stage 2',21,True)
    f.T(1067,91,'K constants [15:0]',20,a='middle')
    f.slots(911,109,250,46,['K<sub>256</sub>','K<sub>64</sub>','K<sub>16</sub>','K<sub>4</sub>'],active=1,sz=21)
    f.T(851,142,'t<sub>1</sub>',24,c=R)
    f.E([(883,134),(911,134)],R)
    f.E([(1005,155),(1005,181),(1020,181),(1020,205)],R)
    f.T(1050,183,'K(t<sub>1</sub>)',19,c=R)
    f.T(844,235,'γ<sub>1</sub>',24)
    f.E([(884,227),(996,227)])
    f.bus(935,227,label=32)
    f.op(1020,227,'×',23,R)
    f.T(1020,273,'16 × 32',21,True,a='middle')
    f.E([(1043,227),(1179,227)])
    f.T(1106,213,'Y[47:0]',22,a='middle')
    f.T(1106,253,'Q32',19,a='middle')
    f.E([(1179,158),(1179,229)],arrow=False)
    f.T(1370,81,'R2',23,True,a='middle')
    r2x=1220; r2w=306; r2y=99; rh=35
    fields=[('t<sub>2</sub> ← t<sub>1</sub>','t<sub>2</sub>',R),('s ← [Y[47:32] ≥ 24]','s',I),('q ← Y[36:32]','q',I),('f ← Y[31:27]','f',R),('v<sub>2</sub> ← v<sub>1</sub>','v<sub>2</sub>',I)]
    for i,(txt,port,c) in enumerate(fields):
        yy=r2y+i*rh
        f.cell(r2x,yy,r2w,rh,txt,20,c,PALE if i==0 else W,reg=True)
        f.E([(r2x+r2w,yy+rh/2),(1541,yy+rh/2)],c)
        f.T(1550,yy+rh/2+6,port,19,c=c)
    for yy in [151.5,186.5,221.5]:
        f.E([(1179,yy),(1220,yy)])
        f.dot(1179,yy)
    f.T(1184,122,'t<sub>1</sub>',19,c=R,a='end')
    f.E([(1189,116.5),(1220,116.5)],R)
    f.T(1184,263,'v<sub>1</sub>',19,a='end')
    f.E([(1189,256.5),(1220,256.5)])
    # Stage 3; named fields are the actual R2 outputs.
    f.E([(838,293),(1563,293)],arrow=False,w=1)
    f.T(850,319,'Stage 3',21,True)
    f.T(919,348,'L[f] : 32 × 17',22,True,a='middle')
    # Exactly 32 LUT cells, with one highlighted addressed entry.
    for row in range(4):
        for col in range(8):
            active=(row==1 and col==4)
            f.rect(845+col*19,360+row*20,16,16,fill=PALE if active else W,stroke=R if active else I,sw=1.35)
    f.T(864,464,'f [4:0]',20,c=R)
    f.E([(917,453),(917,439)],R)
    f.cell(1015,317,130,42,'C(t<sub>2</sub>)',23,R,PALE)
    f.T(999,325,'t<sub>2</sub>',18,c=R,a='end')
    f.E([(1002,338),(1015,338)],R)
    f.E([(1080,359),(1080,374)],R)
    f.op(1080,399,'×',23,R)
    f.E([(997,399),(1057,399)],R)
    f.T(1031,386,'17',18,a='middle')
    f.T(1080,447,'16 × 17',20,True,a='middle')
    f.E([(1103,399),(1131,399)],R)
    f.cell(1131,373,107,52,'[31:8]',23,R)
    f.T(1184,451,'Q32 → Q24',18,a='middle')
    f.E([(1238,399),(1270,399)],R)
    f.cell(1270,373,88,52,'≫ q',26,R)
    f.T(1314,341,'q [4:0]',20,a='middle')
    f.E([(1314,346),(1314,373)])
    f.mux(1401,353,38,91,R)
    f.T(1378,369,'0',22,a='middle')
    f.E([(1377,376),(1401,376)])
    f.E([(1358,399),(1377,399),(1377,414),(1401,414)],R)
    f.T(1388,480,'s ∨ (t<sub>2</sub> = 0)',20,a='middle')
    f.E([(1413,457),(1413,438)],B,dash=True)
    f.T(1504,321,'R3',23,True,a='middle')
    f.cell(1461,335,95,35,'t<sub>3</sub>',22,R,PALE,reg=True)
    f.cell(1461,370,95,58,'p<sub>k</sub>',27,R,PALE,reg=True)
    f.cell(1461,428,95,35,'v<sub>3</sub>',22,reg=True)
    f.E([(1439,399),(1461,399)],R)
    f.T(1441,338,'t<sub>2</sub>',17,c=R,a='end')
    f.E([(1436,352.5),(1461,352.5)],R)
    f.T(1441,460,'v<sub>2</sub>',17,a='end')
    f.E([(1436,445.5),(1461,445.5)])
    f.E([(1556,399),(1570,399)],R)
    f.T(1570,387,'24',17,c=R,a='end')

    # (c), bit-weighted streaming accumulators and integer target test.
    c_start=f.mark()
    f.T(40,579,'p<sub>k</sub>',24)
    f.cell(133,553,159,43,'Shift-add',22,bold=True)
    f.T(212,620,'b<sub>k</sub>p<sub>k</sub>',21,a='middle')
    f.E([(82,575),(133,575)])
    f.T(87,644,'t<sub>3</sub>',23,a='end')
    f.cell(133,626,159,42,'b(t<sub>3</sub>)',23)
    f.E([(96,647),(133,647)])
    f.T(108,560,'t<sub>3</sub>',19,a='end')
    f.E([(113,547),(205,547),(205,553)])
    for y,regname in [(575,'E<sub>w</sub>'),(647,'B')]:
        f.E([(292,y),(326,y)])
        f.op(346,y,'+',20)
        f.E([(366,y),(396,y)])
        f.cell(396,y-23,105,46,regname,25,reg=True)
        off=35 if y==575 else 28
        f.E([(501,y),(514,y),(514,y-off),(346,y-off),(346,y-20)])
        f.dot(514,y)
    f.T(449,612,'35 bits',18,a='middle')
    f.T(449,686,'12 bits',18,a='middle')
    f.E([(501,575),(544,575)])
    f.cell(544,552,76,46,'×10<sup>4</sup>',22)
    f.E([(501,647),(544,647)])
    f.cell(544,624,76,46,'×G',24)
    f.E([(620,575),(635,575),(635,590),(652,590)])
    f.E([(620,647),(635,647),(635,619),(652,619)])
    f.cell(652,578,44,54,'≤',27)
    f.op(733,605,'∨',17)
    f.E([(696,605),(716,605)])
    f.E([(750,605),(770,605)])
    f.T(765,592,'τ',26,a='middle')
    f.T(734,658,'B = 0',19,a='middle')
    f.E([(733,640),(733,622)])
    f.T(40,707,'τ = target_met;   G = 2<sup>24</sup> − 10<sup>4</sup> · 2<sup>4</sup> = 16,617,216',20,maxw=720)
    f.E([(35,720),(766,720)],arrow=False,w=1)
    f.T(38,752,'One shared 32 × 9 multiplier',24,True)
    f.T(655,752,'6 multiply cycles',20,a='middle')
    # Tier statistic bank: each row contains an error sum and a population.
    f.T(68,786,'M',21,a='middle')
    f.T(141,786,'E<sub>M</sub> [31:0]',18,a='middle')
    f.T(224,786,'N<sub>M</sub> [8:0]',18,a='middle')
    for row,m in enumerate([256,64,16,4]):
        y=801+row*47;c=R if m==64 else I
        f.cell(40,y,55,45,str(m),21,c,PALE if m==64 else W,True)
        f.cell(95,y,86,45,f'E<sub>{m}</sub>',23,c,PALE if m==64 else W,reg=True)
        f.cell(181,y,86,45,f'N<sub>{m}</sub>',23,c,PALE if m==64 else W,reg=True)
    f.mux(293,811,28,89)
    f.mux(293,945,28,78)
    f.T(293,800,'E',22,a='middle')
    f.T(289,937,'N',22,a='middle')
    f.E([(267,849),(293,849)],R)
    f.E([(267,968),(293,968)])
    f.E([(321,855),(360,855),(360,874)])
    f.T(342,846,'32',17,a='middle')
    f.E([(321,984),(329,984),(329,898),(336,898)])
    f.T(338,951,'9',17)
    f.op(360,898,'×',24,R)
    f.E([(384,898),(401,898)],R,arrow=False)
    f.E([(401,819),(401,999)],R,arrow=False)
    f.dot(401,898,R)
    f.T(468,787,'6 × 41-bit',18,a='middle')
    for i,name in enumerate(['E<sub>256</sub>N<sub>64</sub>','E<sub>64</sub>N<sub>256</sub>','E<sub>16</sub>N<sub>4</sub>','E<sub>4</sub>N<sub>16</sub>','E<sub>H</sub>N<sub>L</sub>','E<sub>L</sub>N<sub>H</sub>']):
        f.cell(419,801+i*36,98,36,name,21,reg=True)
        f.E([(401,819+i*36),(419,819+i*36)],R)
        f.dot(401,819+i*36,R)
    # Each comparison is accompanied by its valid-count test in the RTL.
    for top,ycenter in [(807,837),(879,909),(951,981)]:
        if top < 951:
            f.rect(558,top,84,58,stroke=I,sw=2)
            f.T(600,top+22,'CMP/SEL',17,True,a='middle')
            f.T(600,top+47,'≥, V',21,a='middle')
        else:
            f.cell(558,top,84,58,'≥ / V',21)
    for i,(ya,yb,ta,tb) in enumerate([(819,855,824,850),(891,927,896,922),(963,999,968,994)]):
        f.E([(517,ya),(537,ya),(537,ta),(558,ta)])
        f.E([(517,yb),(546,yb),(546,tb),(558,tb)])
    f.E([(642,837),(688,837)],R)
    f.E([(642,909),(688,909)])
    f.cell(688,814,78,46,'W<sub>H</sub>',23,R,PALE,reg=True)
    f.cell(688,886,78,46,'W<sub>L</sub>',23,reg=True)
    f.mux(704,948,29,78,R)
    f.T(672,956,'t<sub>H</sub>',18,c=R,a='middle')
    f.T(672,1026,'t<sub>L</sub>',18,a='middle')
    f.E([(659,968),(704,968)],R)
    f.E([(659,1006),(704,1006)])
    f.E([(642,981),(651,981),(651,1044),(716,1044),(716,1021)],B,dash=True)
    f.E([(733,987),(768,987)],R)
    f.T(750,973,'j*',23,True,R,a='middle')
    f.T(40,1048,'W<sub>H,L</sub> = (t, E, N); feedback to operand MUXes.  V: nonempty tier.',17,maxw=600)
    f.T(293,917,'u<sub>mul</sub>',17,c=B,a='middle')
    f.E([(293,922),(307,922),(307,891)],B,dash=True)
    f.shift(c_start,32)

    # (d): actual active / baseline / best margin banks, with lane update.
    tags=['m<sub>256</sub>','m<sub>64</sub>','m<sub>16</sub>','m<sub>4</sub>']
    for y,title,active in [(592,'Active m',1),(697,'Baseline m<sub>b</sub>',None),(802,'Best m*',None)]:
        f.T(848,y-15,title,23,True)
        f.T(1118,y-15,'4 × 32',18,a='end')
        f.slots(848,y,272,50,tags,active,True,22)
    f.mux(1170,603,36,137,label='8:1')
    f.E([(1120,617),(1142,617),(1142,629),(1170,629)],R)
    f.E([(1120,722),(1142,722),(1142,714),(1170,714)])
    f.T(1190,770,'j, phase',18,c=B,a='middle')
    f.E([(1190,750),(1188,750),(1188,735)],B,dash=True)
    f.op(1260,671,'±',24,R)
    f.E([(1206,671),(1236,671)],R)
    f.T(1240,586,'Δ<sub>Q16</sub> = 6554',21,True,a='middle')
    f.E([(1260,599),(1260,647)])
    f.T(1245,630,'32',17,a='end')
    f.cell(1321,641,110,62,'Insert j',22)
    f.E([(1284,671),(1321,671)],R)
    f.T(1376,625,'lane j',20,c=B,a='middle')
    f.E([(1376,628),(1376,641)],B,dash=True)
    f.T(1376,742,'m<sub>src</sub>',22,a='middle')
    f.E([(1376,721),(1376,703)])
    f.mux(1471,582,38,258,label='4:1')
    f.T(1453,613,'0',22,a='end')
    f.E([(1457,617),(1471,617)])
    f.E([(1431,671),(1471,671)],R)
    f.T(1453,731,'m<sub>b</sub>',23,a='end')
    f.E([(1458,725),(1471,725)])
    f.T(1453,787,'m*',23,a='end')
    f.E([(1458,780),(1471,780)])
    f.E([(1509,711),(1550,711),(1550,558),(980,558),(980,592)],R)
    f.T(1535,744,'u<sub>wr</sub>',18,c=B,a='middle')
    f.E([(1535,752),(1535,845),(1488,845),(1488,832)],B,dash=True)
    # Baseline and best captures use repeated names for the active-margin bus.
    f.T(835,711,'m',20,c=R,a='middle')
    f.E([(826,722),(848,722)],R)
    f.T(835,816,'m',20,c=R,a='middle')
    f.E([(826,827),(848,827)],R)
    f.T(1082,763,'load_base',17,c=B,a='end')
    f.E([(1095,766),(1095,747)],B,dash=True)
    f.T(1050,882,'load_best',18,c=B,a='middle')
    f.E([(1050,862),(1050,852)],B,dash=True)
    f.cell(848,908,272,43,'m<sub>b,j</sub> ≥ Δ',24)
    f.E([(1120,929),(1143,929)],B,dash=True)
    f.T(1151,936,'e',23,c=B)
    f.T(1238,795,'Best statistics',20,True,a='middle')
    f.cell(1168,813,95,41,'B*',24,reg=True)
    f.cell(1274,813,95,41,'E*<sub>w</sub>',23,reg=True)
    f.cell(1380,813,43,41,'F',23,reg=True)
    f.T(1250,875,'12',17,a='middle')
    f.T(1321,875,'35',17,a='middle')
    f.cell(1208,887,137,42,'B &gt; B*',22)
    f.T(1174,915,'B',23,a='middle')
    f.E([(1186,908),(1208,908)])
    f.E([(1216,854),(1216,880),(1276,880),(1276,887)])
    f.op(1392,908,'∨',18)
    f.E([(1345,908),(1374,908)])
    f.E([(1401,854),(1401,872),(1392,872),(1392,890)])
    f.T(1429,882,'¬F',18,a='end')
    f.op(1474,908,'∧',19)
    f.E([(1410,908),(1455,908)])
    f.T(1474,875,'τ',24,a='middle')
    f.E([(1474,879),(1474,889)])
    f.E([(1493,908),(1546,908),(1546,943)],B,dash=True)
    f.T(1518,967,'load_best',18,c=B,a='middle')
    f.T(1431,969,'u<sub>ref</sub>',18,c=B,a='middle')
    f.E([(1431,950),(1431,941),(1474,941),(1474,927)],B,dash=True)
    # FSM and address/response control are circuits, not a flowchart.
    d_ctrl=f.mark()
    f.cell(844,954,236,98,'FSM [4:0]',27,bold=True,reg=True)
    f.T(962,943,'τ, j*, F, e',20,a='middle')
    f.E([(962,945),(962,954)],B,dash=True)
    f.T(962,1036,'u<sub>mul</sub>, u<sub>wr</sub>, u<sub>ref</sub>, en',20,c=B,a='middle')
    f.cell(1119,955,146,41,'req [8:0]',20,reg=True)
    f.cell(1119,1012,146,41,'rsp [8:0]',20,reg=True)
    f.E([(1080,976),(1119,976)],B,dash=True)
    f.E([(1080,1033),(1119,1033)],B,dash=True)
    f.T(1100,963,'en',17,c=B,a='middle')
    f.T(1100,1020,'v<sub>3</sub>',17,c=B,a='middle')
    f.E([(1265,976),(1353,976)])
    f.T(1340,964,'addr[7:0]',18,a='end')
    f.cell(1353,953,190,43,'Address / valid',20)
    f.E([(1265,1033),(1353,1033)])
    f.rect(1353,1006,190,52,stroke=I,sw=2)
    f.T(1448,1028,'rsp = 254',21,a='middle')
    f.T(1448,1049,'scan_done',17,c=B,a='middle')
    f.E([(1543,1033),(1567,1033)],B,dash=True)
    f.shift(d_ctrl,32)
    # Paper caption keys (no presentation headline or explanatory sidebars).
    legend=f.mark()
    f.E([(20,1097),(58,1097)],R)
    f.T(69,1104,'64-QAM example',18,c=R)
    f.E([(274,1097),(312,1097)],B,dash=True)
    f.T(323,1104,'Control',18,c=B)
    f.T(438,1104,'t: OFF / 4 / 16 / 64 / 256 ↔ 0 / 1 / 2 / 3 / 4',18)
    f.T(1026,1104,'p: Q24; margins: Q16; Δ ≈ 0.1 dB',18)
    f.shift(legend,32)
    return f

if __name__=='__main__':
    result=draw().save()
    print(json.dumps(result,ensure_ascii=False,indent=2))
