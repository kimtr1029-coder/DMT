#!/usr/bin/env python3
"""Generate a structure-first four-panel figure for the BER loading engine.

The drawing deliberately follows the visual grammar of the supplied reference
figures: matrices, repeated cells, dashed selections, concrete examples, and
reduction trees carry the explanation instead of prose-filled flowchart boxes.
"""

from __future__ import annotations

from html import escape
from pathlib import Path
import sys
import zipfile


WORK = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(WORK / "engine_four_part"))

from generate_figures import (  # noqa: E402
    Canvas,
    DEFS,
    BLACK,
    BLUE,
    RED,
    GRAY,
    MID_GRAY,
    LIGHT_GRAY,
    LIGHT_BLUE,
    LIGHT_RED,
    WHITE,
)


OUT = Path(__file__).resolve().parent / "final"
OUT.mkdir(parents=True, exist_ok=True)

W, H = 1800, 1000
SERIF = "Liberation Serif, Times New Roman, serif"
SANS = "Liberation Sans, Arial, sans-serif"


def title(c: Canvas, letter: str, label: str):
    # Paper-style panel header: quiet frame, compact panel tag, no UI-like badge.
    c.rect(26, 22, W - 52, H - 44, fill=WHITE, stroke="#D8DDE5", sw=1.5)
    c.text(58, 88, f"({letter})", size=38, weight=500,
           anchor="start", family=SERIF)
    c.text(145, 88, label, size=42, weight=500,
           anchor="start", family=SERIF)


def bracket(c: Canvas, x: float, y: float, w: float, h: float,
            *, color=BLACK, sw=4):
    arm = 22
    c.polyline([(x + arm, y), (x, y), (x, y + h), (x + arm, y + h)],
               color=color, sw=sw)
    c.polyline([(x + w - arm, y), (x + w, y), (x + w, y + h),
                (x + w - arm, y + h)], color=color, sw=sw)


def vector(c: Canvas, x: float, y: float, cells: list[str], *,
           cell_w=128, cell_h=70, gap=14, label=None, selected=None,
           selected_color=RED, fill=WHITE, font_size=29):
    total_h = len(cells) * cell_h + (len(cells) - 1) * gap
    bracket(c, x, y, cell_w + 54, total_h, sw=4)
    for i, text in enumerate(cells):
        cy = y + i * (cell_h + gap)
        is_sel = selected == i
        c.box_label(x + 27, cy, cell_w, cell_h, text,
                    fill=LIGHT_RED if is_sel else fill,
                    stroke=selected_color if is_sel else BLACK,
                    sw=4 if is_sel else 2,
                    dash="10 7" if is_sel else None,
                    size=font_size, weight=500)
    if label:
        c.text(x + cell_w / 2 + 27, y - 22, label, size=30, weight=500,
               family=SERIF)
    return total_h


def row_vector(c: Canvas, x: float, y: float, values: list[str], *,
               labels: list[str] | None = None, cell_w=112, cell_h=64,
               gap=12, selected=None, selected_color=RED, fill=WHITE,
               label=None, font_size=27):
    total_w = len(values) * cell_w + (len(values) - 1) * gap
    bracket(c, x, y, total_w + 54, cell_h, sw=4)
    for i, value in enumerate(values):
        xx = x + 27 + i * (cell_w + gap)
        is_sel = selected == i
        c.box_label(xx, y, cell_w, cell_h, value,
                    fill=LIGHT_RED if is_sel else fill,
                    stroke=selected_color if is_sel else BLACK,
                    sw=4 if is_sel else 2,
                    dash="10 7" if is_sel else None,
                    size=font_size, weight=500)
        if labels:
            c.text(xx + cell_w / 2, y - 15, labels[i], size=22,
                   color=GRAY, family=SERIF)
    if label:
        c.text(x - 18, y + cell_h / 2 + 11, label, size=31, weight=500,
               anchor="end", family=SERIF)
    return total_w


def reg(c: Canvas, x: float, y: float, label: str, *, h=205):
    c.register(x, y, w=56, h=h, label=label)


def mux(c: Canvas, x: float, y: float, w: float, h: float, label="SEL"):
    c.polygon([(x, y), (x + w, y + h * 0.16), (x + w, y + h * 0.84),
               (x, y + h)], fill=WHITE, stroke=BLACK, sw=3)
    c.text(x + w * 0.52, y + h * 0.57, label, size=23, weight=500,
           family=SERIF)


def multiplier(c: Canvas, cx: float, cy: float, r=47, *, stroke=BLACK,
               fill=WHITE):
    c.circle(cx, cy, r, fill=fill, stroke=stroke, sw=4)
    c.text(cx, cy + 18, "×", size=58, weight=500, family=SERIF)


def sigma(c: Canvas, x: float, y: float, w=116, h=88, *, fill=WHITE,
          stroke=BLACK, label="Σ"):
    c.box_label(x, y, w, h, label, fill=fill, stroke=stroke, sw=3,
                size=48, weight=500)


def small_rom(c: Canvas, x: float, y: float, *, cols=8, rows=4,
              cell=35, selected=11):
    c.text(x + cols * cell / 2, y - 19, "2⁻ᶠ ROM", size=28, weight=500,
           family=SERIF)
    for r in range(rows):
        for q in range(cols):
            idx = r * cols + q
            is_sel = idx == selected
            c.rect(x + q * cell, y + r * cell, cell - 3, cell - 3,
                   fill=LIGHT_RED if is_sel else (LIGHT_GRAY if (r + q) % 2 else WHITE),
                   stroke=RED if is_sel else BLACK,
                   sw=3 if is_sel else 1)
    bracket(c, x - 16, y - 8, cols * cell + 32, rows * cell + 13, sw=3)
    c.text(x + cols * cell / 2, y + rows * cell + 34,
           "32 entries · 17-bit Q16", size=21,
           color=GRAY, family=SERIF)


def panel_a() -> str:
    c = Canvas()
    title(c, "a", "Parallel per-tone QAM selection")

    # Compact vector arithmetic at the top: T + m = theta.
    ys = 172
    row_vector(c, 150, ys, ["24", "18", "12", "6"],
               labels=["256", "64", "16", "4"], cell_w=88, cell_h=60,
               gap=8, label="T [dB]", font_size=28)
    c.circle(640, ys + 30, 23, fill=WHITE, stroke=BLACK, sw=3)
    c.text(640, ys + 42, "+", size=36, weight=500, family=SERIF)
    row_vector(c, 700, ys, ["m₂₅₆", "m₆₄", "m₁₆", "m₄"],
               cell_w=95, cell_h=60, gap=8, font_size=24,
               selected=1, selected_color=BLUE)
    c.text(901, ys - 20, "m", size=27, weight=500, family=SERIF)
    c.circle(1215, ys + 30, 23, fill=WHITE, stroke=BLACK, sw=3)
    c.text(1215, ys + 42, "=", size=34, weight=500, family=SERIF)
    row_vector(c, 1275, ys, ["θ₂₅₆", "θ₆₄", "θ₁₆", "θ₄"],
               cell_w=90, cell_h=60, gap=8, font_size=24,
               selected=1)
    c.text(1471, ys - 20, "θ", size=27, weight=500, family=SERIF)

    # The threshold vector feeds a four-row comparator bank.
    c.polyline([(1490, 232), (1490, 286), (550, 286), (550, 340)],
               color=BLUE, sw=3, marker="arrow-blue")
    c.text(1000, 275, "θ", size=22, color=BLUE, family=SERIF)

    matrix_x, matrix_y, matrix_w, matrix_h = 150, 340, 800, 390
    bracket(c, matrix_x, matrix_y, matrix_w, matrix_h, sw=4)
    c.text(550, 326, "four parallel tests", size=27, weight=500,
           family=SERIF)
    c.text(250, 375, "M", size=23, color=GRAY, family=SERIF)
    c.text(430, 375, "θₘ", size=23, color=GRAY, family=SERIF)
    c.text(660, 375, "γₖ,dB ≥ θₘ", size=23, color=GRAY, family=SERIF)
    c.text(860, 375, "qₘ", size=23, color=GRAY, family=SERIF)

    rows = [
        (418, "256", "θ₂₅₆", "γₖ,dB ≥ θ₂₅₆", "0"),
        (498, "64",  "θ₆₄",  "γₖ,dB ≥ θ₆₄",  "1"),
        (578, "16",  "θ₁₆",  "γₖ,dB ≥ θ₁₆",  "1"),
        (658, "4",   "θ₄",   "γₖ,dB ≥ θ₄",   "1"),
    ]
    for i, (cy, qam, theta, test, bit) in enumerate(rows):
        selected = i == 1
        if selected:
            c.rect(178, cy - 34, 744, 68, fill=LIGHT_RED, stroke=RED,
                   sw=4, dash="10 7")
        c.box_label(195, cy - 27, 110, 54, qam, fill="none",
                    stroke="none", sw=0, size=25, weight=500,
                    color=RED if selected else BLACK)
        c.box_label(365, cy - 27, 130, 54, theta, fill=WHITE,
                    stroke=RED if selected else BLACK,
                    sw=3 if selected else 2, size=24, weight=500,
                    color=RED if selected else BLACK)
        c.line(495, cy, 545, cy, sw=3, marker="arrow-black")
        c.box_label(545, cy - 27, 225, 54, test, fill=WHITE,
                    stroke=RED if selected else BLACK,
                    sw=3 if selected else 2, size=21, weight=500,
                    color=RED if selected else BLACK)
        c.line(770, cy, 820, cy, sw=3, marker="arrow-black")
        c.box_label(820, cy - 27, 80, 54, bit,
                    fill=LIGHT_RED if selected else WHITE,
                    stroke=RED if selected else BLACK,
                    sw=3 if selected else 2, size=27, weight=500,
                    color=RED if selected else BLACK)

    # Per-tone dB SNR enters the comparator bank; q vector enters priority logic.
    c.text(118, 547, "γₖ,dB", size=27, weight=500, anchor="end",
           family=SERIF)
    c.line(122, 537, 150, 537, sw=4, marker="arrow-black")
    mux(c, 1040, 390, 100, 320, "PRI")
    target_ys = [440, 515, 590, 665]
    for (cy, *_), ty in zip(rows, target_ys):
        c.line(900, cy, 1040, ty, sw=3)

    c.line(1140, 550, 1230, 550, color=RED, sw=5,
           marker="arrow-red")
    c.box_label(1250, 493, 275, 114, "64-QAM", fill=LIGHT_RED,
                stroke=RED, sw=4, dash="11 7", size=35, weight=500,
                color=RED)
    c.text(1387, 650, "tier 3   ·   6 bits", size=23,
           color=GRAY, family=SERIF)
    c.line(1525, 550, 1730, 550, color=RED, sw=5,
           marker="arrow-red")
    c.text(1728, 527, "Mₖ", size=25, color=GRAY, anchor="end",
           family=SERIF)

    # A small ordered-threshold example explains the selected row without
    # turning the whole panel into a presentation-style colored ladder.
    c.text(180, 790, "ordered-threshold example", size=22, color=GRAY,
           anchor="start", family=SERIF)
    c.rect(930, 812, 440, 58, fill=LIGHT_RED, stroke="none", sw=0)
    c.line(180, 865, 1630, 865, sw=4, marker="arrow-black")
    marks = [(360, "θ₄"), (650, "θ₁₆"), (930, "θ₆₄"),
             (1370, "θ₂₅₆")]
    for xx, lab in marks:
        c.line(xx, 828, xx, 900, sw=3)
        c.text(xx, 930, lab, size=23, family=SERIF)
    for xx, lab, color in [
        (270, "OFF", BLACK), (505, "4-QAM", BLACK),
        (790, "16-QAM", BLACK), (1150, "64-QAM", RED),
        (1490, "256-QAM", BLACK),
    ]:
        c.text(xx, 840, lab, size=24, weight=500, color=color,
               family=SERIF)
    c.line(1140, 805, 1140, 900, color=RED, sw=4, dash="11 7")
    c.circle(1140, 865, 8, fill=RED, stroke=RED, sw=1)
    c.text(1140, 795, "γₖ,dB", size=24, weight=500, color=RED,
           family=SERIF)
    return "".join(c.parts)


def panel_b() -> str:
    c = Canvas()
    title(c, "b", "Pipelined Q24 BER datapath")

    c.rich(1235, 174, [
        {"text": "P̂", "style": "italic"},
        {"text": "b,k", "shift": "sub", "size": 19},
        {"text": " = C", "style": "italic"},
        {"text": "M", "shift": "sub", "size": 19},
        {"text": " · 2"},
        {"text": "−K_M γ_k,lin", "shift": "super", "size": 19},
    ], size=30, color=GRAY)

    # K/C coefficient bank as a selected matrix row.
    c.text(260, 172, "M", size=27, weight=500, family=SERIF)
    c.text(393, 172, "Kₘ", size=27, weight=500, family=SERIF)
    c.text(530, 172, "Cₘ", size=27, weight=500, family=SERIF)
    rows = [("256", "K₂₅₆", "C₂₅₆"), ("64", "K₆₄", "C₆₄"),
            ("16", "K₁₆", "C₁₆"), ("4", "K₄", "C₄"), ("0", "0", "0")]
    x0, y0 = 135, 195
    bracket(c, x0, y0, 525, 320, sw=4)
    for i, row in enumerate(rows):
        yy = y0 + 16 + i * 59
        selected = i == 1
        if selected:
            c.rect(x0 + 18, yy - 6, 488, 53, fill=LIGHT_RED, stroke=RED,
                   sw=4, dash="10 7")
        for j, val in enumerate(row):
            xx = x0 + 32 + j * 151
            c.box_label(xx, yy, 112, 42, val,
                        fill="none", stroke="none", sw=0,
                        size=25, weight=500,
                        color=RED if selected else BLACK)

    c.text(68, 301, "Mₖ", size=29, weight=500, color=BLUE,
           anchor="start", family=SERIF)
    c.line(112, 291, 135, 291, color=BLUE, sw=4,
           marker="arrow-blue")

    # Selected K/C outputs leave through row gaps and route outside the bank.
    c.polyline([(318, 291), (300, 291), (300, 520),
                (353, 520), (353, 540)],
               color=BLUE, sw=4, marker="arrow-blue")
    c.polyline([(581, 291), (750, 291), (750, 430),
                (1213, 430), (1213, 510)],
               color=BLUE, sw=4, marker="arrow-blue")
    # Pipeline backbone.
    y = 690
    c.text(65, y + 10, "γₖ,lin", size=31, weight=500,
           anchor="start", family=SERIF)
    c.line(125, y, 185, y, sw=4, marker="arrow-black")
    reg(c, 185, 588, "R1")
    c.line(241, y, 300, y, sw=4, marker="arrow-black")
    multiplier(c, 350, y)

    # K selector from coefficient bank.
    mux(c, 320, 540, 66, 78, "K")
    c.line(353, 618, 353, 641, color=BLUE, sw=4, marker="arrow-blue")

    c.line(397, y, 450, y, sw=4, marker="arrow-black")
    # Y word split instead of prose.
    c.text(570, 618, "Y = Kₘγₖ,lin", size=27, weight=500, family=SERIF)
    c.rect(450, 651, 280, 78, fill=WHITE, stroke=BLACK, sw=3)
    c.rect(450, 651, 145, 78, fill=LIGHT_GRAY, stroke=BLACK, sw=2)
    c.rect(595, 651, 135, 78, fill=LIGHT_BLUE, stroke=BLUE, sw=3)
    c.text(522, 699, "q=Y[36:32]", size=21, weight=500, family=SERIF)
    c.text(663, 699, "f=Y[31:27]", size=20, weight=500, color=BLUE,
           family=SERIF)
    reg(c, 760, 588, "R2")
    c.line(730, y, 760, y, sw=4, marker="arrow-black")

    # Fractional address selects one physical ROM entry.
    small_rom(c, 870, 486, cols=8, rows=4, cell=34, selected=11)
    c.polyline([(816, 650), (842, 650), (842, 554), (870, 554)],
               color=BLUE, sw=4, marker="arrow-blue")
    multiplier(c, 1140, y)

    # C selector from the same selected row.
    mux(c, 1180, 510, 66, 88, "C")
    c.line(1213, 598, 1164, 648, color=BLUE, sw=4, marker="arrow-blue")

    # ROM output enters the second multiplier.
    c.polyline([(1142, 554), (1142, 643)],
               color=BLACK, sw=4, marker="arrow-black")
    c.line(1187, y, 1260, y, sw=4, marker="arrow-black")

    # Q32-to-Q24 slice and integer shift shown structurally.
    c.rect(1260, 650, 160, 80, fill=WHITE, stroke=BLACK, sw=3)
    c.rect(1276, 665, 128, 50, fill=LIGHT_RED, stroke=RED, sw=3)
    c.text(1340, 699, "[31:8]", size=27, weight=500, color=RED, family=SERIF)
    c.line(1420, y, 1470, y, sw=4, marker="arrow-black")
    c.polygon([(1470, 642), (1580, 662), (1580, 718), (1470, 738)],
              fill=WHITE, stroke=BLACK, sw=3)
    c.text(1525, 701, ">> q", size=30, weight=500, family=SERIF)
    c.polyline([(788, 793), (788, 815), (1525, 815), (1525, 738)],
               color=BLUE, sw=4, marker="arrow-blue")

    # q>=24 selects zero, otherwise the shifted result.
    mux(c, 1605, 638, 68, 104, "0/P")
    c.line(1580, y, 1605, y, sw=4, marker="arrow-black")
    c.text(1639, 596, "Y≥24", size=19, color=RED, family=SERIF)
    c.text(1639, 620, "or M=0", size=18, color=RED, family=SERIF)
    c.line(1639, 620, 1639, 638, color=RED, sw=3, marker="arrow-red")
    reg(c, 1700, 588, "R3")
    c.line(1673, y, 1700, y, sw=4, marker="arrow-black")
    c.line(1756, y, 1782, y, sw=4, marker="arrow-black")
    c.text(1735, 555, "(Mₖ, P̂b,k)", size=22, weight=500,
           family=SERIF)
    c.text(1775, 735, "Q24", size=23, color=GRAY, anchor="end", family=SERIF)

    c.text(950, 904, "Mₖ pipeline · 1 tone / clk", size=25,
           weight=500, color=BLUE,
           family=SERIF)
    c.polyline([(241, 793), (241, 860), (1700, 860), (1700, 793)],
               color=BLUE, sw=3, dash="10 7")
    return "".join(c.parts)


def pair_box(c: Canvas, x: float, y: float, tier: str, *, selected=False):
    c.rect(x, y, 165, 74, fill=LIGHT_RED if selected else WHITE,
           stroke=RED if selected else BLACK, sw=4 if selected else 2,
           dash="10 7" if selected else None)
    c.text(x + 50, y + 47, tier, size=25, weight=500,
           color=RED if selected else BLACK, family=SERIF)
    c.line(x + 94, y + 8, x + 94, y + 66, sw=2)
    c.text(x + 130, y + 34, "E", size=22, family=SERIF)
    c.text(x + 130, y + 59, "N", size=22, family=SERIF)


def compare_node(c: Canvas, x: float, y: float, label="×↔×"):
    c.box_label(x, y, 116, 76, label, fill=WHITE, stroke=RED, sw=3,
                size=27, weight=500, color=RED)


def panel_c() -> str:
    c = Canvas()
    title(c, "c", "Full-band statistics & worst-tier tree")

    # Tone stream strip.
    c.text(90, 173, "k", size=27, weight=500, family=SERIF)
    sx = 135
    for i, lab in enumerate(["1", "2", "3", "…", "254", "255"]):
        c.box_label(sx + i * 105, 132, 82, 64, lab,
                    fill=LIGHT_GRAY if i % 2 == 0 else WHITE,
                    stroke=BLACK, sw=2, size=25, weight=500)
    bracket(c, sx - 18, 120, 6 * 105 + 10, 90, sw=3)
    c.text(455, 240, "(Mₖ, P̂b,k)", size=28, weight=500, family=SERIF)
    c.line(765, 165, 845, 165, sw=5, marker="arrow-black")
    c.dot(845, 165, r=7)

    # Target path: selected bit weight fans to numerator and denominator sums.
    row_vector(c, 900, 118, ["8", "6", "4", "2"],
               labels=["256", "64", "16", "4"], cell_w=60, cell_h=52,
               gap=8, font_size=23, selected=1)
    c.text(873, 151, "bₘ", size=24, weight=500, anchor="end", family=SERIF)
    mux(c, 1245, 108, 58, 100, "M")
    c.line(1220, 144, 1245, 144, color=BLUE, sw=3, marker="arrow-blue")
    c.polyline([(845, 165), (875, 165), (875, 144), (900, 144)],
               color=BLUE, sw=3, marker="arrow-blue")
    c.box_label(1315, 205, 105, 70, "≪ / +", fill=LIGHT_BLUE,
                stroke=BLUE, sw=3, size=27, weight=500, color=BLUE)
    c.polyline([(845, 165), (845, 240), (1324, 240)],
               color=BLACK, sw=4, marker="arrow-black")
    c.polyline([(1303, 158), (1367, 158), (1367, 205)],
               color=BLUE, sw=3, marker="arrow-blue")
    sigma(c, 1430, 205, w=98, h=64, fill=LIGHT_RED, stroke=RED)
    sigma(c, 1430, 282, w=98, h=64, fill=WHITE, stroke=RED)
    c.text(1412, 230, "Ew", size=21, anchor="end", color=RED, family=SERIF)
    c.text(1412, 307, "B", size=21, anchor="end", color=RED, family=SERIF)
    c.line(1420, 240, 1430, 240, color=RED, sw=4,
           marker="arrow-red")
    c.polyline([(1303, 158), (1320, 158), (1320, 314), (1430, 314)],
               color=BLUE, sw=3, marker="arrow-blue")
    c.box_label(1580, 230, 165, 105, "Ew ≤ Pg·B", fill=WHITE, stroke=RED,
                sw=4, size=24, weight=500, color=RED)
    c.polyline([(1528, 237), (1550, 237), (1550, 258), (1580, 258)],
               color=RED, sw=3, marker="arrow-red")
    c.polyline([(1528, 314), (1550, 314), (1550, 307), (1580, 307)],
               color=RED, sw=3, marker="arrow-red")
    c.line(1745, 282, 1770, 282, color=RED, sw=5, marker="arrow-red")
    c.text(1662, 362, "Pg = Pₜ − 2⁻²⁰", size=21, color=RED, family=SERIF)

    # Four repeated per-tier accumulator lanes: sum(P) and sum(1) in parallel.
    tiers = ["256", "64", "16", "4"]
    ys = [390, 520, 650, 780]
    c.text(272, 326, "Mₖ", size=25, weight=500, family=SERIF)
    c.text(468, 326, "ΣP̂b / Σ1", size=25, weight=500, family=SERIF)
    c.text(790, 326, "[Eₘ, Nₘ]", size=25, weight=500, family=SERIF)
    for tier, yy in zip(tiers, ys):
        selected = tier == "64"
        c.box_label(210, yy - 32, 125, 64, tier,
                    fill=LIGHT_RED if selected else WHITE,
                    stroke=RED if selected else BLACK,
                    sw=4 if selected else 2,
                    dash="10 7" if selected else None,
                    size=28, weight=500,
                    color=RED if selected else BLACK)
        c.line(335, yy, 385, yy, sw=3)
        c.dot(385, yy, r=5)
        c.polyline([(385, yy), (405, yy), (405, yy - 28), (430, yy - 28)],
                   sw=3, marker="arrow-black")
        c.polyline([(385, yy), (405, yy), (405, yy + 28), (430, yy + 28)],
                   sw=3, marker="arrow-black")
        c.box_label(430, yy - 51, 100, 46, "ΣP̂b",
                    fill=LIGHT_BLUE if selected else WHITE,
                    stroke=BLUE if selected else BLACK, sw=3,
                    size=25, weight=500)
        c.box_label(430, yy + 5, 100, 46, "Σ1",
                    fill=LIGHT_BLUE if selected else WHITE,
                    stroke=BLUE if selected else BLACK, sw=3,
                    size=25, weight=500)
        pair_box(c, 685, yy - 37, tier, selected=selected)
        c.polyline([(530, yy - 28), (610, yy - 28), (610, yy - 12),
                    (685, yy - 12)], color=BLUE, sw=3, marker="arrow-blue")
        c.polyline([(530, yy + 28), (610, yy + 28), (610, yy + 14),
                    (685, yy + 14)], color=BLUE, sw=3, marker="arrow-blue")
    c.polyline([(845, 165), (845, 285), (165, 285), (165, 780)],
               color=BLACK, sw=4)
    for yy in ys:
        c.line(165, yy, 210, yy, sw=3, marker="arrow-black")

    # Pairwise tournament for max(E/N), without a divider.
    compare_node(c, 1040, 417, "×↔×")
    compare_node(c, 1040, 677, "×↔×")
    c.polyline([(850, 390), (970, 390), (970, 455), (1040, 455)],
               color=BLACK, sw=3, marker="arrow-black")
    c.polyline([(850, 520), (970, 520), (970, 455)], color=BLACK, sw=3)
    c.polyline([(850, 650), (970, 650), (970, 715), (1040, 715)],
               color=BLACK, sw=3, marker="arrow-black")
    c.polyline([(850, 780), (970, 780), (970, 715)], color=BLACK, sw=3)

    pair_box(c, 1230, 418, "W₀")
    pair_box(c, 1230, 678, "W₁")
    c.line(1156, 455, 1230, 455, color=RED, sw=4, marker="arrow-red")
    c.line(1156, 715, 1230, 715, color=RED, sw=4, marker="arrow-red")
    compare_node(c, 1510, 547, "×↔×")
    c.polyline([(1395, 455), (1450, 455), (1450, 585), (1510, 585)],
               color=BLACK, sw=3, marker="arrow-black")
    c.polyline([(1395, 715), (1450, 715), (1450, 585)], color=BLACK, sw=3)
    c.line(1626, 585, 1760, 585, color=RED, sw=5, marker="arrow-red")
    c.text(1755, 548, "worst M", size=27, weight=500, color=RED,
           anchor="end", family=SERIF)

    # One multiplier is time-shared by all three compare nodes.
    multiplier(c, 1300, 885, r=40, stroke=BLUE, fill=LIGHT_BLUE)
    c.text(1300, 950, "32×9 · 6 cycles", size=24, color=BLUE,
           family=SERIF)
    c.polyline([(1300, 845), (1300, 820), (1098, 820), (1098, 753)],
               color=BLUE, sw=3, dash="10 7", marker="arrow-blue")
    c.polyline([(1300, 820), (1568, 820), (1568, 623)],
               color=BLUE, sw=3, dash="10 7", marker="arrow-blue")
    c.text(1185, 396, "EₐNᵦ ↔ EᵦNₐ", size=22, color=RED, family=SERIF)
    c.text(1295, 368, "N=0 bypass · tie: 256→64→16→4", size=18,
           color=GRAY, family=SERIF)
    c.text(1530, 526, "Level 1", size=23, color=RED, family=SERIF)
    return "".join(c.parts)


def candidate_matrix(c: Canvas, x: float, y: float):
    labels = ["4", "16", "64", "256"]
    selected_col = {"256": 0, "64": 1, "16": 2, "4": 3}
    c.text(x + 260, y - 48, "eligible candidates  (mₘ ≥ Δ)", size=27,
           weight=500, family=SERIF)
    bracket(c, x, y, 590, 300, sw=4)
    for r, tier in enumerate(labels):
        yy = y + 14 + r * 68
        c.text(x - 18, yy + 38, tier, size=23, anchor="end", family=SERIF)
        for col, lab in enumerate(["m₂₅₆", "m₆₄", "m₁₆", "m₄"]):
            xx = x + 26 + col * 137
            selected = selected_col[tier] == col
            selected_values = ["m₂₅₆−Δ", "m₆₄−Δ", "m₁₆−Δ", "m₄−Δ"]
            text = selected_values[col] if selected else lab
            c.box_label(xx, yy, 114, 52, text,
                        fill=LIGHT_RED if selected else WHITE,
                        stroke=RED if selected else BLACK,
                        sw=4 if selected else 2,
                        dash="9 6" if selected else None,
                        size=20 if selected else 24, weight=500,
                        color=RED if selected else BLACK)


def panel_d() -> str:
    c = Canvas()
    title(c, "d", "Margin search & final allocation")

    # Current margins feed the first scan directly (all-zero after reset).
    row_vector(c, 185, 155, ["m₂₅₆", "m₆₄", "m₁₆", "m₄"],
               cell_w=118, cell_h=66, gap=14, label="m*", font_size=27,
               selected=1, selected_color=BLUE)
    c.text(520, 252, "reset: m = 0", size=21, color=GRAY,
           family=SERIF)

    # Single full-band scan core, rendered as a repeated tone strip.
    c.box_label(930, 125, 210, 126, "SCAN", fill=WHITE, stroke=BLACK,
                sw=4, size=35, weight=500)
    for i, txt in enumerate(["1", "2", "…", "255"]):
        c.box_label(930 + i * 53, 265, 45, 45, txt,
                    fill=LIGHT_GRAY if i % 2 == 0 else WHITE,
                    stroke=BLACK, sw=1, size=17, weight=500)
    c.line(753, 188, 930, 188, sw=5, marker="arrow-black")
    c.box_label(1215, 142, 180, 92, "≤ Pg ?", fill=WHITE, stroke=RED,
                sw=4, size=30, weight=500, color=RED)
    c.text(1305, 265, "Pg = Pₜ − 2⁻²⁰", size=19, color=RED,
           family=SERIF)
    c.line(1140, 188, 1215, 188, color=RED, sw=4,
           marker="arrow-red")

    # Failure path: compare tier BERs, update only the worst tier, then rescan.
    c.polyline([(1305, 142), (1305, 112), (195, 112), (195, 300)],
               color=RED, sw=4, dash="12 8", marker="arrow-red")
    c.text(1260, 126, "0", size=24, color=RED, family=SERIF)
    c.text(84, 342, "UP", size=35, weight=500, color=BLUE, family=SERIF)
    c.box_label(120, 300, 150, 66, "worst M", fill=WHITE, stroke=RED,
                sw=3, size=25, weight=500, color=RED)
    c.line(270, 333, 310, 333, color=RED, sw=4,
           marker="arrow-red")
    row_vector(c, 310, 300, ["m₂₅₆", "m₆₄+Δ", "m₁₆", "m₄"],
               cell_w=118, cell_h=66, gap=14, font_size=27,
               selected=1, selected_color=BLUE)
    c.text(610, 395, "Δ = 0.1 dB", size=24, weight=500, color=BLUE,
           family=SERIF)
    c.polyline([(878, 333), (900, 333), (900, 188), (930, 188)],
               color=BLUE, sw=4, marker="arrow-blue")

    # Success enters the one-step downward refinement phase.
    c.line(1395, 188, 1510, 188, color=RED, sw=5,
           marker="arrow-red")
    c.text(1460, 168, "1", size=24, color=RED, family=SERIF)
    c.line(1510, 188, 1510, 450, color=RED, sw=4,
           marker="arrow-red")

    # Downward candidate matrix and one sequential scan core.
    c.text(95, 552, "DOWN", size=35, weight=500, color=RED, family=SERIF)
    candidate_matrix(c, 185, 575)
    mux(c, 825, 640, 90, 170, "4:1")
    c.line(775, 725, 825, 725, sw=5, marker="arrow-black")
    c.text(870, 625, "sequential", size=20, color=BLUE, family=SERIF)
    c.box_label(940, 661, 190, 126, "SCAN", fill=WHITE, stroke=BLACK,
                sw=4, size=35, weight=500)
    c.line(915, 725, 940, 725, sw=5, marker="arrow-black")
    c.text(1035, 818, "single datapath", size=23, color=BLUE, family=SERIF)

    # Results vector and max-bit selection.
    res_x = 1195
    c.text(res_x + 150, 603, "4→16→64→256   (V, B)", size=22,
           weight=500, family=SERIF)
    for i, tier in enumerate(["4", "16", "64", "256"]):
        yy = 625 + i * 68
        selected = tier == "16"
        c.box_label(res_x, yy, 255, 52, f"{tier}   V│B",
                    fill=LIGHT_RED if selected else WHITE,
                    stroke=RED if selected else BLACK,
                    sw=4 if selected else 2,
                    dash="9 6" if selected else None,
                    size=23, weight=500,
                    color=RED if selected else BLACK)
    c.line(1130, 725, 1195, 725, sw=4, marker="arrow-black")
    c.box_label(1505, 665, 180, 115, "MAX B", fill=LIGHT_RED, stroke=RED,
                sw=4, size=31, weight=500, color=RED)
    c.line(1450, 725, 1505, 725, color=RED, sw=5, marker="arrow-red")

    # Apply winner or finish; visual feedback closes the search loop.
    c.polyline([(1595, 665), (1595, 480), (185, 480), (185, 575)],
               color=RED, sw=4, dash="12 8", marker="arrow-red")
    c.text(1125, 470, "m ← best", size=23, color=RED, family=SERIF)
    c.line(1685, 725, 1745, 725, color=RED, sw=5, marker="arrow-red")
    c.text(1742, 694, "none", size=23, color=RED, anchor="end", family=SERIF)

    # The RTL performs a final scan and streams index/tier/valid; no RAM is implied.
    c.box_label(1450, 835, 145, 90, "FINAL SCAN", fill=LIGHT_BLUE,
                stroke=BLUE, sw=4, size=23, weight=500)
    c.polyline([(1745, 725), (1745, 810), (1522, 810), (1522, 835)],
               color=BLACK, sw=4, marker="arrow-black")
    c.line(1595, 880, 1628, 880, sw=4, marker="arrow-black")
    bracket(c, 1628, 842, 142, 70, sw=3)
    for xx, ww, lab in [(1635, 35, "k"), (1676, 45, "Mₖ"),
                        (1727, 35, "v")]:
        c.box_label(xx, 852, ww, 50, lab, fill=WHITE, stroke=BLACK,
                    sw=2, size=19, weight=500)
    c.text(1699, 830, "output stream", size=19, color=GRAY,
           family=SERIF)
    c.text(1699, 940, "× 255", size=20, color=GRAY, family=SERIF)
    return "".join(c.parts)


def svg_document(content: str, width: int, height: int, label: str) -> str:
    return (
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" '
        f'viewBox="0 0 {width} {height}" role="img" aria-labelledby="title desc" '
        f'shape-rendering="geometricPrecision" text-rendering="geometricPrecision">\n'
        f'<title id="title">{escape(label)}</title>\n'
        '<desc id="desc">Structure-first explanatory diagram of the proposed BER-informed loading engine.</desc>\n'
        f'{DEFS}<rect width="100%" height="100%" fill="{WHITE}"/>\n{content}\n</svg>\n'
    )


def combined_document(panels: list[str]) -> str:
    gap = 34
    mx = 36
    mt = 34
    footer = 34
    width = mx * 2 + W * 2 + gap
    height = mt + H * 2 + gap + footer
    placements = [(mx, mt), (mx + W + gap, mt),
                  (mx, mt + H + gap), (mx + W + gap, mt + H + gap)]
    body = [f'<rect width="100%" height="100%" fill="{WHITE}"/>']
    for panel, (x, y) in zip(panels, placements):
        body.append(f'<g transform="translate({x},{y})">{panel}</g>')
    return (
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" '
        f'viewBox="0 0 {width} {height}" role="img" aria-labelledby="title desc" '
        f'shape-rendering="geometricPrecision" text-rendering="geometricPrecision">\n'
        '<title id="title">Four visual parts of the proposed BER-informed bit-loading engine</title>\n'
        '<desc id="desc">Parallel per-tone QAM selection, Q24 BER datapath, accumulation and comparison tree, and margin candidate search.</desc>\n'
        f'{DEFS}{"".join(body)}\n</svg>\n'
    )


def main():
    panels = [panel_a(), panel_b(), panel_c(), panel_d()]
    names = [
        "part-a-parallel-qam-selection",
        "part-b-q24-ber-datapath",
        "part-c-accumulator-decision-tree",
        "part-d-margin-candidate-search",
    ]
    labels = [
        "Parallel per-tone QAM selection",
        "Pipelined Q24 BER core",
        "Full-band statistics and decision tree",
        "Margin search and final allocation",
    ]
    for name, label, panel in zip(names, labels, panels):
        (OUT / f"{name}.svg").write_text(
            svg_document(panel, W, H, label), encoding="utf-8")

    (OUT / "proposed-engine-four-part.svg").write_text(
        combined_document(panels), encoding="utf-8")

    (OUT / "figure-notes-ko.md").write_text(
        "# Structure-first four-part figure\n\n"
        "- (a) threshold-vector addition feeds four parallel per-tone comparators and a priority selector; a compact ordered-threshold inset shows the 64-QAM example.\n"
        "- (b) a selected K/C row, Y-word split, physical ROM array, and q-controlled shift show the Q24 BER datapath.\n"
        "- (c) four E/N accumulator lanes feed a two-level cross-product comparison tree.\n"
        "- (d) one-cell margin updates and a four-row candidate matrix feed one sequential scan datapath.\n\n"
        "Suggested caption: *Operation of the proposed BER-informed bit-loading engine: "
        "(a) parallel per-tone QAM selection using adaptive SNR thresholds, "
        "(b) pipelined Q24 BER evaluation, (c) full-band accumulation and "
        "divider-free worst-tier selection, and (d) upward margin correction "
        "followed by sequential one-step downward refinement and final allocation.*\n",
        encoding="utf-8")

    return names


if __name__ == "__main__":
    main()
