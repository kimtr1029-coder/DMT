# Structure-first four-part figure

- (a) threshold-vector addition feeds four parallel per-tone comparators and a priority selector; a compact ordered-threshold inset shows the 64-QAM example.
- (b) a selected K/C row, Y-word split, physical ROM array, and q-controlled shift show the Q24 BER datapath.
- (c) four E/N accumulator lanes feed a two-level cross-product comparison tree.
- (d) one-cell margin updates and a four-row candidate matrix feed one sequential scan datapath.

Suggested caption: *Operation of the proposed BER-informed bit-loading engine: (a) parallel per-tone QAM selection using adaptive SNR thresholds, (b) pipelined Q24 BER evaluation, (c) full-band accumulation and divider-free worst-tier selection, and (d) upward margin correction followed by sequential one-step downward refinement and final allocation.*
