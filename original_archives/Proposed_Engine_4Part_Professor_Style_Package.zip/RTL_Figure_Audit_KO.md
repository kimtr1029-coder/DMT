# Proposed engine 4-part figure — RTL 대조 검증서

검증 대상은 다음 세 RTL 파일이다.

- `FINAL_Q24_REFINE_top_20260812.v`
- `FINAL_Q24_REFINE_datapath_20260812.v`
- `FINAL_Q24_REFINE_margin_ctrl_20260812.v`

## 결론

최종 그림은 논문용 추상화 수준에서 데이터패스와 제어 알고리즘의 핵심 동작을 RTL과 일치시킨다. 그림은 모든 handshake·timeout·진단 신호를 나열한 block-level schematic은 아니지만, 할당, BER 계산, 통계, worst-tier 선택, upward search, downward refinement 및 최종 stream 생성의 순서와 연산에는 다른 부분이 없다.

## 패널별 RTL 대응

| 패널 | 그림의 표현 | RTL 대응 및 검증 결과 |
|---|---|---|
| (a) | `T+m=theta`, 네 개의 병렬 비교, 256→64→16→4 priority | base threshold는 24/18/12/6 dB(Q16)이고, 각 margin과 33-bit로 더한 뒤 `i_snr_db`와 독립 비교한다. 우선순위도 RTL과 동일하다. margin에 따라 threshold 순서가 바뀔 수 있으므로 ladder에는 `ordered-threshold example`이라고 명시했다. |
| (b) | QAM별 Q16 `K/C`, `Y=K*SNR_linear`, `q=Y[36:32]`, `f=Y[31:27]`, 32-entry ROM, `[31:8]`, `>>q`, Q24 출력 | LUT는 실제로 32-entry, 17-bit Q16이다. `C(16-bit) × LUT(17-bit)`의 33-bit product에서 `[31:8]`을 취하고 정수부만큼 shift한다. `Y>=24` 또는 OFF tier이면 0을 출력한다. tier와 BER이 함께 pipeline되는 구조와 1 tone/clock도 일치한다. |
| (c) | bit weight 8/6/4/2, shift/add weighted error, `Ew <= Pg*B`, QAM별 `(E,N)`, cross-product tree | weighted error는 multiplier가 아니라 RTL의 shift/add 구현(8: `<<3`, 6: `<<2 + <<1`, 4: `<<2`, 2: `<<1`)으로 수정했다. target은 `Pg=1/10000-2^-20`과 동치다. worst tier는 `E_a*N_b`와 `E_b*N_a`를 비교하며 한 개의 32x9 multiplier를 6 cycle 재사용한다. zero-count bypass와 tie order 256→64→16→4도 표시했다. |
| (d) | current margin scan, 실패 시 worst-tier margin `+Delta`, 성공 시 eligible one-step decrement, 4→16→64→256 sequential scan, strict max-bit selection, final stream | reset margin은 모두 0이다. `Delta=6554/2^16 dB`, 즉 약 0.100006 dB이다. downward 후보는 base margin이 Delta 이상일 때만 평가한다. `total_bits`가 strictly larger인 후보만 갱신하므로 동률은 앞선 4→16→64→256 후보가 유지된다. 후보가 없으면 final scan 후 `(index,tier,valid)`를 255-tone stream으로 출력한다. RTL 내부 RAM은 없으므로 이전 RAM 표시는 제거했다. |

## 의도적으로 생략한 보조 신호

논문 그림의 가독성을 위해 다음은 표시하지 않았다.

- `clk`, `rst_n`, `i_start`
- external SNR table의 address/valid handshake
- request/response counters와 pipeline-valid 지연
- `MAX_MARGIN_UPDATES=1000`, `MAX_REFINEMENT_ACCEPTS=1000` timeout 경로
- convergence/timeout/debug counters 및 status outputs
- accumulator의 모든 내부 bit width

이 항목들은 예외 처리·인터페이스·관측용 제어이며 그림에 나타낸 핵심 알고리즘의 연산이나 탐색 순서를 바꾸지 않는다.

## 잘못 해석될 수 있는 항목의 처리

- `1100 bit` 고정 조건은 RTL과 그림 어디에도 없다. `B=sum b_M`은 현재 allocation에 따라 매 scan마다 달라진다.
- panel (a)의 64-QAM, panel (b)의 selected coefficient row, panel (c)의 selected accumulator lane, panel (d)의 16-QAM winner는 동작 설명을 위한 하나의 예시이지 고정 결과가 아니다.
- panel (d)의 final block은 storage RAM이 아니라 RTL의 `S_OUTPUT_STREAM`에 대응하는 final scan/output stream이다.
- 모든 패널을 2600-pixel 개별 렌더링과 결합 렌더링으로 확인했으며, 문자 위를 지나는 신호선, 의도하지 않은 선 교차, 잘림 및 panel-frame 침범을 제거했다. 동일 신호의 fan-out과 블록 입력에서의 합류만 의도된 접속으로 남겼다.
