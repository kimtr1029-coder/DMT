"""A self-explanatory register-transfer diagram of margin search hardware."""
from pathlib import Path
import json
import zipfile

import fitz
from pypdf import PdfReader, PdfWriter
import build_dmt_figures as draw


OUT = Path(__file__).resolve().parent / "output/margin_search/revision_20"
OUT.mkdir(parents=True, exist_ok=True)
draw.OUT = OUT
f = draw.Figure("DMT_Margin_search", 1280, 523)

INK = "#20262c"
MUTED = "#596874"
RULE = "#97a3ad"
PALE = "#f5f7f8"
BLUE = "#265d82"
BLUE_PALE = "#edf5fa"
RED = "#af3440"
RED_PALE = "#fff0f0"
WHITE = "#ffffff"


def t(x,y,s,size=18,bold=False,color=INK,anchor="start",maxw=None):
    f.text(x,y,s,size,"Bold" if bold else "Sans",color,anchor,maxw)


def rect(x,y,w,h,fill=WHITE,stroke=RULE,sw=1.35,bg=False):
    f.rect(x,y,w,h,fill,stroke,sw,layer="background" if bg else "shape")


def chip(x,y,w,h,s,size=17,fill=WHITE,stroke=RULE,
         color=INK,bold=False):
    rect(x,y,w,h,fill,stroke,1.2)
    t(x+w/2,y+h/2+size*.34,s,size,bold,color,"middle",w-8)


def line(*pts,color=INK,width=1.45,arrow=False,dashed=False):
    f.line(list(pts),color,width,arrow,dashed)


t(28,37,"(d) Margin-search hardware",25,True)
t(1252,37,"one shared Q16 lane unit  ·  one 255-tone evaluator",16,
  color=MUTED,anchor="end")
line((28,54),(1252,54),color=RULE,width=1.15)

# Outside feedback is the only long loop. The selector's result clocks the
# active vector register; every scan then uses that registered vector.
line((1225,380),(1264,380),(1264,78),(299,78),(299,105),arrow=True)
t(785,72,"m<sub>next</sub>  [4 × 32 bit]",16,color=MUTED,anchor="middle")

# State registers. m0 and m* are real copies of active m, each with an
# independent write enable indicated at its register port.
rect(28,105,408,334,WHITE,RULE,1.45,bg=True)
t(46,134,"Q16 MARGIN REGISTERS",19,True)
t(422,134,"QAM",15,color=MUTED,anchor="end")
tiers=(256,64,16,4)
xs=(128,204,280,356)
for x,mod in zip(xs,tiers):
    t(x+35,165,str(mod),17,True,MUTED,"middle")
line((128,174),(426,174),color=RULE,width=1.0)
for label,y,fill,stroke in (
    ("m",180,BLUE_PALE,BLUE),
    ("m<sub>0</sub>",272,WHITE,RULE),
    ("m*",364,WHITE,RULE),
):
    t(47,y+32,label,21,True,BLUE if label=="m" else INK)
    for x,mod in zip(xs,tiers):
        s=(f"m<sub>{mod}</sub>" if label=="m" else
           f"m<sub>0,{mod}</sub>" if label=="m<sub>0</sub>" else
           f"m*<sub>{mod}</sub>")
        chip(x,y,70,48,s,18 if label=="m" else 17,fill,stroke)
line((128,204),(116,204),(116,296),(128,296),arrow=True,width=1.25)
line((116,296),(116,388),(128,388),arrow=True,width=1.25)
f.dot(116,296)
t(47,429,"base_we → m<sub>0</sub>",15,color=BLUE)
t(270,429,"best_we → m*",15,color=RED)

# One tone scan produces status for the controller, not a second copy of
# the margin arithmetic.
rect(502,105,255,133,WHITE,INK,1.4,bg=True)
t(520,134,"255-TONE SCAN",18,True)
for x,w,s in ((520,45,"1"),(565,45,"2"),(610,83,"···"),(693,46,"255")):
    chip(x,151,w,34,s,18)
chip(520,195,55,29,"B",17,BLUE_PALE,RULE,BLUE)
chip(580,195,77,29,"pass",16,BLUE_PALE,RULE,BLUE)
chip(662,195,77,29,"j<sub>w</sub>",17,BLUE_PALE,RULE,BLUE)
line((426,204),(465,204),(465,168),(502,168),arrow=True)
line((757,209),(799,209),color=BLUE,arrow=True)

# FSM hardware: mode flops, trial-index counter and best-score registers.
rect(799,105,452,133,WHITE,INK,1.4,bg=True)
t(817,134,"SEARCH CONTROL",18,True)
for x,w,s,fill,col in (
    (816,75,"UP",RED_PALE,RED),
    (897,88,"TRIAL",BLUE_PALE,BLUE),
    (991,103,"COMMIT",PALE,INK),
):
    chip(x,146,w,28,s,15,fill,RULE,col,True)
chip(1102,146,133,28,"j<sub>ctr</sub>: 4→16→64→256",12,PALE)
chip(817,184,61,29,"B*",17,PALE)
chip(883,184,81,29,"found",15,PALE)
t(975,205,"pass ∧ (¬found ∨ B &gt; B*)",14,
  color=RED,maxw=257)
t(817,227,"UP · pass → base_we",14,color=BLUE)
t(1030,227,"TRIAL → best_we",14,color=RED)

# Control bundle runs entirely in the free gap above the data path.
line((1030,238),(1030,274),(602,274),width=1.2,color=RED,dashed=True)
line((1030,274),(1165,274),width=1.2,color=RED,dashed=True)
for x,label in ((602,"src_sel"),(699,"j<sub>w</sub> / j<sub>ctr</sub>"),
                (819,"UP:+  TRIAL:−"),(951,"write j"),
                (1165,"wb_sel")):
    line((x,274),(x,295),width=1.15,color=RED,arrow=True,dashed=True)
    t(x-8 if x==602 else x,266,label,13,color=RED,
      anchor="end" if x==602 else "middle")
f.dot(1030,274,RED)

# Current m and saved m0 feed the two ports of a vector-source MUX.
line((465,204),(465,259),(492,259),(492,354),(570,354),arrow=True)
f.dot(465,204)
line((426,296),(480,296),(480,383),(570,383),arrow=True)
f.dot(480,296)

# A single selected coordinate enters the Q16 ALU. The other three vector
# lanes physically bypass it, then rejoin at the lane-insertion unit.
rect(502,295,510,151,WHITE,INK,1.4,bg=True)
t(520,323,"ONE-COORDINATE UPDATE",19,True)
t(517,348,"m (UP)",13,color=MUTED)
t(510,381,"m<sub>0</sub> (TRIAL)",13,color=MUTED)
f.poly([(570,344),(632,358),(632,382),(570,399)],WHITE,INK,1.35)
t(601,377,"2:1",18,True,anchor="middle")
line((632,371),(657,371),arrow=True)
f.dot(645,371)
f.poly([(657,347),(733,359),(733,384),(657,396)],WHITE,INK,1.35)
t(695,376,"4:1",18,True,anchor="middle")
line((733,371),(777,371),arrow=True)
chip(777,347,84,47,"± Δ",20,RED_PALE,RED,RED,True)
line((861,371),(909,371),arrow=True,color=RED)
chip(909,345,81,53,"1:4",18,WHITE,INK,INK,True)
line((645,371),(645,427),(950,427),(950,398),
     color=MUTED,width=1.25,arrow=True)
t(786,421,"3 unchanged lanes",15,color=MUTED,anchor="middle")

# Three complete vectors are candidate writeback sources. Distinct lower
# tracks keep restore and accept paths away from the Q16 lane arithmetic.
line((480,296),(480,464),(1020,464),(1020,383),(1034,383),arrow=True)
line((426,388),(455,388),(455,483),(1026,483),(1026,411),
     (1034,411),arrow=True)
line((990,371),(1019,371),(1019,353),(1034,353),
     color=RED,arrow=True)

rect(1034,295,217,151,WHITE,INK,1.4,bg=True)
t(1051,323,"WRITEBACK",19,True)
chip(1050,340,90,26,"updated m′",14,RED_PALE,RULE,RED)
chip(1050,370,90,26,"restore m<sub>0</sub>",14)
chip(1050,398,90,26,"commit m*",14)
f.poly([(1160,337),(1225,354),(1225,406),(1160,423)],
       WHITE,INK,1.4)
t(1193,387,"3:1",18,True,anchor="middle")
for y in (353,383,411):
    line((1140,y),(1160,y),arrow=True,width=1.2)

line((28,507),(1251,507),color=RULE,width=1.15)
checks=f.save()

pdf=OUT/"DMT_Margin_search.pdf"
reader=PdfReader(pdf);writer=PdfWriter()
for page in reader.pages:page.scale_by(170/210);writer.add_page(page)
with pdf.open("wb") as s:writer.write(s)
doc=fitz.open(pdf)
doc[0].get_pixmap(dpi=340,alpha=False).save(OUT/"DMT_Margin_search.png")
doc[0].get_pixmap(matrix=fitz.Matrix(2.7,2.7),alpha=False).save(OUT/"preview.png")
(OUT/"layout_checks.json").write_text(json.dumps(checks,indent=2),
                                     encoding="utf-8")
(OUT/"DMT_Margin_search_caption.md").write_text(
    "**Suggested caption.** Register-transfer architecture of the "
    "per-QAM margin search. The active four-word Q16 register m drives "
    "one shared 255-tone scan, which returns loaded bits B, target pass, "
    "and worst tier j_w to the FSM. The FSM includes a 4→16→64→256 trial "
    "index counter and best-score registers B* and found. In UP, the "
    "source MUX selects m, the index is j_w, and the shared ALU adds Δ. "
    "In TRIAL, the MUX selects the saved base m0, the counter provides "
    "j, and the ALU subtracts Δ, if m0,j≥Δ. A four-to-one lane read "
    "and one-to-four insertion unit alter only coordinate j while the "
    "other three lanes bypass arithmetic. The writeback MUX loads the "
    "new vector, restores m0, or commits m*. The UP passing vector is "
    "snapshotted into m0. A passing trial captures current m into m* "
    "only if no earlier feasible trial exists or B>B*. At sweep end "
    "the FSM commits m* if found, otherwise restores m0. Solid paths "
    "are four-word data or scan status; dashed paths are control. "
    "The named best_we control pin on the best register is driven by "
    "the identically named FSM output. Vector PDF width: 170 mm.\n",
    encoding="utf-8")
with zipfile.ZipFile(OUT/"DMT_Margin_search_editable.zip","w",
                     zipfile.ZIP_DEFLATED) as z:
    for ext in ("svg","pdf","png"):
        p=OUT/f"DMT_Margin_search.{ext}";z.write(p,p.name)
    p=OUT/"DMT_Margin_search_caption.md";z.write(p,p.name)
    for p in (Path(__file__),Path(draw.__file__)):z.write(p,p.name)
print(json.dumps(checks,indent=2))
