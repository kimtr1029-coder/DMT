from pathlib import Path
import json
import figure_renderer as draw

OUT = Path(__file__).resolve().parent / 'rendered'
OUT.mkdir(parents=True, exist_ok=True)
draw.OUT = OUT
F = draw.Figure('DMT_QAM_selection',1080,600)
K='#111111'; GR='#555555'; LIGHT='#f0f0f0'; R='#cf242b'; PINK='#fff0f0'

def text(x,y,s,size=24,bold=False,color=K,anchor='middle',maxw=None):
    return F.text(x,y,s,size,'Bold' if bold else 'Sans',color,anchor,maxw)
def rect(x,y,w,h,fill='#ffffff',stroke=K,sw=2,layer='shape',dash=False):
    F.rect(x,y,w,h,fill=fill,stroke=stroke,sw=sw,layer=layer,dash=dash)
def line(pts,color=K,width=2,arrow=True,dash=False):
    F.line(pts,color,width,arrow,dash)

rect(5,5,1070,590,fill=None,sw=3,layer='background')

# Threshold generation is a compact vector definition; all entries are in dB.
banks=[(25,298,'Base thresholds (dB)',['24','18','12','6']),
       (373,298,'Margins (dB)',['m<sub>256</sub>','m<sub>64</sub>','m<sub>16</sub>','m<sub>4</sub>']),
       (725,330,'Effective thresholds (dB)',['θ<sub>256</sub>','θ<sub>64</sub>','θ<sub>16</sub>','θ<sub>4</sub>'])]
for x,w,title,cells in banks:
    text(x+w/2,30,title,18,bold=True,maxw=w)
    rect(x,40,w,49,sw=2)
    cw=(w-16)/4
    for i,s in enumerate(cells):
        rect(x+5+i*cw,45,cw-3,39,sw=1.6)
        text(x+5+i*cw+(cw-3)/2,72,s,24,bold=True,maxw=cw-8)
text(348,73,'+',31)
text(697,72,'=',31)
line([(25,105),(1055,105)],color='#bbbbbb',width=1,arrow=False)

# Four explicit comparators. The common gamma bus feeds the upper input;
# theta feeds the lower input, consistently implementing gamma >= theta.
text(212,137,'Threshold',19,bold=True)
text(384,137,'Comparators',19,bold=True)
text(561,137,'Example bits',19,bold=True)
text(948,244,'Selected QAM',19,bold=True)
text(65,170,'γ<sub>k,dB</sub>',26,bold=True)
line([(48,179),(113,179),(113,395)],arrow=False,width=2.2)

rows=[(256,193,0),(64,265,1),(16,337,1),(4,409,1)]
# Light row emphasis remains readable when printed in grayscale.
rect(145,231,491,77,fill=PINK,stroke=R,sw=1.5,layer='background',dash=True)

rect(642,158,201,289,sw=2.4)
for M,y,bit in rows:
    selected=M==64
    col=R if selected else K
    rect(166,y+4,94,34,stroke=col,sw=2)
    text(213,y+29,f'θ<sub>{M}</sub>',25,bold=True,color=col)
    rect(318,y-30,132,68,stroke=col,sw=2)
    text(338,y-4,'γ',18,color=col)
    text(338,y+29,'θ',18,color=col)
    text(397,y+14,'≥',36,bold=True,color=col)
    # This horizontal branch passes above the threshold cell, without a crossing.
    line([(113,y-14),(318,y-14)],width=2)
    F.dot(113,y-14,K)
    line([(260,y+21),(318,y+21)],color=col)
    line([(450,y+4),(538,y+4)],color=col)
    text(493,y-8,f'c<sub>{M}</sub>',21,color=col)
    rect(538,y-20,47,48,fill=PINK if selected else '#ffffff',stroke=col,sw=2)
    text(561.5,y+14,str(bit),29,bold=True,color=col)
    line([(585,y+4),(642,y+4)],color=col,width=2.5 if selected else 2)
    text(659,y+12,str(M),22,bold=selected,color=col,anchor='start')

text(751,268,'Priority',23,bold=True,maxw=151)
text(751,297,'encoder',23,bold=True,maxw=151)
text(751,328,'highest M',18,maxw=146)
line([(843,301),(880,301)],color=R,width=2.5)
rect(880,268,164,66,fill='#fbdcde',stroke=R,sw=2.3)
text(962,309,'64-QAM',29,bold=True,maxw=152)
text(943,368,'M<sub>k</sub> = 64',24,bold=True,color=R)
text(743,470,'All c<sub>M</sub> = 0 → OFF',19,color=GR)

# Explicitly bounded interpretation inset, not part of the signal wiring.
line([(25,488),(1055,488)],color='#999999',width=1.2,arrow=False)
text(32,515,'Ordered-threshold example',18,bold=True,anchor='start')
text(1043,515,'θ<sub>4</sub> &lt; θ<sub>16</sub> &lt; θ<sub>64</sub> &lt; θ<sub>256</sub>',20,anchor='end',color=GR)
left,right=46,1038
ticks=[209,411,613,823]
rect(left,536,right-left,32,fill=LIGHT,stroke=None,layer='background')
rect(613,536,210,32,fill='#f5bdc0',stroke=None,layer='background')
for a,b,label in zip([left]+ticks,ticks+[right],['OFF','4-QAM','16-QAM','64-QAM','256-QAM']):
    text((a+b)/2,558,label,21,bold=True)
line([(left,568),(1048,568)],width=1.7)
for x,M in zip(ticks,[4,16,64,256]):
    line([(x,532),(x,575)],width=1.6,arrow=False)
    text(x,590,f'θ<sub>{M}</sub>',19)
line([(650,529),(650,574)],color=R,width=2,arrow=False,dash=True)
text(650,529,'γ<sub>k,dB</sub>',20,bold=True,color=R)

result=F.save()
(OUT/'layout_checks.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))
