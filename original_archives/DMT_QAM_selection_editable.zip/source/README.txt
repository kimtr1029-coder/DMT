Run: python3 create_qam_panel.py
Dependencies: reportlab, pypdf, pymupdf; DejaVu Sans fonts.
PDF and SVG contain editable vector elements. PNG is rendered at 600 dpi.
