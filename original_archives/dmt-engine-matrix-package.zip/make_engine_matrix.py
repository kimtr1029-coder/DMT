from pathlib import Path
import subprocess,zipfile
R=Path(__file__).resolve().parent;O=R/'output';W,H=1000,422;p=[]
I='#17191c';G='#6b7178';L='#f0f1f2';RED='#c7242c';PINK='#fce9e9';BLUE='#225b89'
def sub(a,b):return a+f'<tspan baseline-shift="sub" font-size="67%">{b}</tspan>'
def t(x,y,s,n=17,c=I,b=False,a='middle',math=False):p.append(f'<text x="{x}" y="{y}" text-anchor="{a}" font-family="{"Nimbus Roman" if math else "Nimbus Sans"}" font-size="{n}" font-weight="{700 if b else 400}" fill="{c}">{s}</text>')
def rect(x,y,w,h,f='white',c=I,sw=1.5):p.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" fill="{f}" stroke="{c}" stroke-width="{sw}"/>')
def line(q,end=True,c=I,w=1.8,dash=False):
 assert all(a[0]==b[0] or a[1]==b[1] for a,b in zip(q,q[1:]))
 p.append('<path d="M '+' L '.join(f'{x},{y}' for x,y in q)+f'" fill="none" stroke="{c}" stroke-width="{w}"'+(' stroke-dasharray="5 3"' if dash else '')+(f' marker-end="url(#a{c[1:]})"' if end else '')+'/>')
def box(x,y,w,h,s,n=17,f='white',c=I):rect(x,y,w,h,f,c);t(x+w/2,y+h/2+n*.32,s,n,c)
def bracket(x,y,w,h):
 line([(x+7,y),(x,y),(x,y+h),(x+7,y+h)],False,w=1.5);line([(x+w-7,y),(x+w,y),(x+w,y+h),(x+w-7,y+h)],False,w=1.5)
def circ(x,y,r=17,c=I):p.append(f'<circle cx="{x}" cy="{y}" r="{r}" fill="white" stroke="{c}" stroke-width="1.8"/>');t(x,y+8,'×',28,c)
def reg(x,y,h,s):
 rect(x,y,14,h,L);t(x+7,y-9,s,14,G);p.append(f'<path d="M{x},{y+h-14} l6,4 l-6,4" fill="none" stroke="{I}" stroke-width="1.2"/>')
def dot(x,y):p.append(f'<circle cx="{x}" cy="{y}" r="2.6" fill="{I}"/>')
# Compact parallel threshold bank, with one example lane highlighted.
t(28,18,'Parallel QAM selection',16,b=True,a='start')
for j,m in enumerate([256,64,16,4]):
 y=42+35*j;col=RED if m==64 else I;fill=PINK if m==64 else 'white'
 box(39,y,62,27,sub('θ',str(m)),17,fill,col)
 box(121,y,32,27,'≥',21,fill,col)
 line([(101,y+13.5),(121,y+13.5)],c=col);line([(153,y+13.5),(180,y+13.5)],c=col)
 line([(112,y-5),(137,y-5),(137,y)],c=I,w=1.3)
line([(112,31),(112,142)],False,w=1.3)
t(112,32,sub('γ','dB'),14,math=True)
bracket(28,35,136,151)
p.append(f'<path d="M180,40 L207,63 L207,158 L180,181 Z" fill="white" stroke="{I}" stroke-width="1.8"/>');t(193,116,'P',17)
line([(207,111),(239,111),(239,239),(266,239)])
t(218,102,sub('M','k'),16,math=True)
t(102,207,'θ = T + m',17,math=True)
# Coefficient ROM presented as a genuine four-row bank aligned with the selector.
t(365,22,'Coefficient bank',17,b=True)
for j,m in enumerate([256,64,16,4]):
 y=42+35*j;sel=m==64
 t(286,y+19,str(m),12,RED if sel else G,a='end')
 box(305,y,80,27,sub('K',str(m)),17,PINK if sel else L,RED if sel else I)
 box(393,y,80,27,sub('C',str(m)),17,PINK if sel else L,RED if sel else I)
bracket(295,35,188,151)
# Selection is abstracted at the bank output, not connected to one constant cell.
line([(345,186),(345,236)]);t(360,222,sub('K','M₁'),15,a='start',math=True)
line([(441,186),(441,197),(588,197),(588,236)]);t(603,223,sub('C','M₂'),15,a='start',math=True)
# Main registered arithmetic occupies a single uninterrupted horizontal lane.
reg(266,234,56,'R1');reg(408,234,56,'R2');reg(766,234,56,'R3')
line([(34,262),(266,262)]);t(39,250,sub('γ','lin'),17,a='start',math=True)
circ(345,254);line([(280,254),(328,254)]);line([(362,254),(408,254)]);t(384,242,'Y',17,math=True)
box(458,234,67,40,'LUT',19,f='#eef4f9',c=BLUE);t(491,222,'32 × 17',13,G)
line([(422,254),(458,254)]);t(438,243,'f',16,math=True)
circ(588,254);line([(525,254),(571,254)])
box(638,233,77,42,'≫ q',23);line([(605,254),(638,254)]);line([(715,254),(766,254)])
t(734,279,'Q24',13,G)
line([(422,277),(436,277),(436,303),(676,303),(676,275)]);t(550,297,'q, s',14,G)
# Output register and one statistics tap.
line([(780,254),(805,254)],False);dot(805,254)
line([(805,254),(864,254)])
rect(864,232,111,44)
line([(897,232),(897,276)],False,w=1.2);line([(947,232),(947,276)],False,w=1.2)
t(880,261,'k',20,math=True);t(922,261,sub('M','k'),19,math=True);t(960,261,'v',17)
t(919,220,'Allocation',16,b=True)
line([(975,254),(994,254)])
# Statistics and decision fill the upper-right, rather than leaving a blank output quadrant.
t(528,22,'Full-band statistics',17,b=True,a='start')
for j,m in enumerate([256,64,16,4]):
 x=538+104*j;sel=m==64
 t(x+43,54,str(m),13,RED if sel else G)
 box(x,66,86,33,sub('E',str(m)),19,PINK if sel else L,RED if sel else I)
 box(x,99,86,33,sub('N',str(m)),19,PINK if sel else L,RED if sel else I)
bracket(528,60,418,78)
# Bank input is a grouped tier-qualified accumulation interface.
line([(805,254),(805,181),(977,181),(977,84),(946,84)])
t(823,290,sub('M','k')+', '+sub('P̂','b,k'),15,math=True)
# Weighted accumulators share the input stream; the vertical route stays outside the bank.
box(840,144,61,26,sub('E','w'),17,L);box(901,144,61,26,'B',17,L)
line([(977,156),(962,156)]);dot(977,156)
# The shared cross-product unit and target comparator return two decisions.
box(532,151,123,32,'×  /  CMP',17,f='#eef4f9',c=BLUE)
line([(548,138),(548,151)]);t(593,147,'shared',12,BLUE)
line([(532,167),(502,167)])
t(511,186,'w',16,BLUE,math=True)
box(686,144,140,31,sub('E','w')+' ≤ '+sub('P','g')+' B',17)
line([(840,158),(826,158)])
line([(756,175),(756,199)]);t(775,200,'V',16,BLUE,math=True)
# Search state is an organized register bank and FSM, not a large empty container.
t(30,334,'Margin search',17,b=True,a='start')
for j,m in enumerate([256,64,16,4]):box(30+j*66,349,60,36,sub('m',str(m)),17,PINK if m==64 else L,RED if m==64 else I)
bracket(20,343,280,48)
line([(20,365),(10,365),(10,195),(28,195),(28,169)])
rect(338,342,279,50,sw=1)
for j,s in enumerate(['UP','DOWN','FINAL']):box(348+j*88,349,79,36,s,15)
line([(338,367),(300,367)])
line([(387,329),(387,342)],c=BLUE);t(387,325,'w',16,BLUE,math=True)
line([(475,329),(475,342)],c=BLUE);t(475,325,'V',16,BLUE,math=True)
box(701,349,265,36,'Best candidate',16,L)
line([(701,367),(617,367)])
t(699,411,'Red: 64-QAM example',13,RED,a='end')
t(966,411,'w: worst tier   V: target test',13,G,a='end')
# Export editable vector and publication PDF.
defs=''.join(f'<marker id="a{c[1:]}" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="4.8" markerHeight="4.8" orient="auto"><path d="M0,0 L10,5 L0,10 Z" fill="{c}"/></marker>' for c in [I,G,RED,BLUE])
svg=f'<svg xmlns="http://www.w3.org/2000/svg" width="180mm" height="{180*H/W}mm" viewBox="0 0 {W} {H}"><defs>{defs}</defs><rect width="{W}" height="{H}" fill="white"/>'+''.join(p)+'</svg>'
f=O/'dmt-engine-matrix.svg';f.write_text(svg)
for ext in ['pdf','png']:
 cmd=['inkscape',str(f),'--export-filename='+str(O/('dmt-engine-matrix.'+ext))]
 cmd+=['--export-text-to-path'] if ext=='pdf' else ['--export-width=4800']
 subprocess.run(cmd,check=True,stdout=subprocess.DEVNULL)
