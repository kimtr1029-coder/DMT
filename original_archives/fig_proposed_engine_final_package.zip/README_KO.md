# Proposed engine block diagram

## 논문용 권장 캡션

**Block diagram of the proposed BER-informed bit-loading engine.** A three-stage, one-tone-per-cycle datapath performs threshold-based QAM allocation and conservative Q24 BER estimation using four Q16 coefficient pairs and a shared 32-entry exponential LUT. The controller first raises the margin of the QAM tier with the largest average estimated BER, then performs one-step downward local refinement while enforcing the residual-guarded BER target. A single 32×9 multiplier is time-shared for worst-tier selection.

## RTL 대조 사항

- 기준 RTL: `per_qam_datapath_balanced`, `per_qam_margin_ctrl_balanced`, `per_qam_bitloading_pipeline_top_balanced`
- 삭제된 과거 구조: alpha search, correction-factor bank, validator/fallback bank
- BER 형식: Q24 (`o_subcarrier_err[23:0]`)
- Stage 1: 4개의 33-bit threshold add, 4개 compare, priority encode, R1
- Stage 2: K selection, 32×16 multiply, `frac[4:0]`, `shift[4:0]`, `ge24`, R2
- Stage 3: 32-entry 17-bit LUT, C selection, 16×17 multiply, `[31:8]` Q24 slice, shift/zero, R3
- K/C selector: 네 QAM 계수와 tier-0의 zero를 포함하는 5:1 선택으로 표시
- Margin update: Q16 0.1 dB step
- Target: estimated BER <= 1e-4 - 2^-20
- Worst-QAM comparison: 하나의 32×9 multiplier를 6 cycle 동안 공유
- External SNR profile RAM과 external QAM allocation RAM은 엔진 RTL 바깥에 명시

## 파일

- `fig_proposed_engine_final.svg`: 편집 가능한 원본 벡터
- `fig_proposed_engine_final.pdf`: 기본 폭 7.16 in의 논문 삽입용 벡터 PDF
- `fig_proposed_engine_final.png`: 4400×1560 고해상도 PNG
- `proposed-engine-block-diagram.html`: 폭에 맞춰 표시되는 미리보기
