"""Hardware-only worst-tier selection figure; cross-check against margin RTL."""
from pathlib import Path
import json
import zipfile

import fitz
from pypdf import PdfReader, PdfWriter

import build_dmt_figures as draw


OUT = Path(__file__).resolve().parent / "output/worst_tier/revision_08"
OUT.mkdir(parents=True, exist_ok=True)
draw.OUT = OUT
f = draw.Figure("DMT_Worst_tier_selection", 1220, 470)

INK = "#202832"
MUTED = "#687787"
RULE = "#b8c4ce"
PALE = "#f5f8fa"
BLUE = "#285e86"
BLUE_PALE = "#ecf3f8"
RED = "#ac3540"
RED_PALE = "#fff2f1"
WHITE = "#ffffff"


def t(x, y, label, size=18, bold=False, color=INK, anchor="start", maxw=None):
    return f.text(x, y, label, size, "Bold" if bold else "Sans", color, anchor, maxw)


def rect(x, y, w, h, fill=WHITE, stroke=INK, sw=1.25, layer="shape"):
    f.rect(x, y, w, h, fill=fill, stroke=stroke, sw=sw, layer=layer)


def line(*points, color=INK, width=1.45, arrow=False, dash=False):
    f.line(list(points), color=color, width=width, arrow=arrow, dash=dash)


def port(x, y, color=INK):
    f.dot(x, y, color)


def chip(x, y, w, h, label, size=19, bold=False, fill=WHITE, stroke=INK, color=INK):
    rect(x, y, w, h, fill, stroke)
    t(x+w/2, y+h/2+size*.33, label, size, bold, color, "middle", w-10)


# Compact title and grid system follow the earlier publication example; no frame.
t(24, 36, "(c) BER check and shared worst-tier selector", 25, True)
t(1195, 35, "255 tones  ·  6 multiply cycles", 16, color=BLUE, anchor="end")
line((24, 51), (1196, 51), color=RULE, width=1.3)

# The scan produces exactly six statistics in two register groups.
chip(56, 76, 198, 39, "(M<sub>k</sub>, p<sub>k</sub>)  ·  k = 1…255", 17, fill=PALE, stroke=RULE)
line((155, 115), (155, 133), arrow=True)
rect(24, 134, 266, 307, WHITE, RULE, 1.35)
t(39, 158, "STREAM ACCUMULATORS", 16, True, MUTED)
chip(38, 169, 237, 37, "E<sub>w</sub> = Σ b<sub>k</sub> p<sub>k</sub>", 19, fill=BLUE_PALE, stroke=RULE)
chip(38, 215, 237, 37, "B = Σ b<sub>k</sub>", 19, fill=BLUE_PALE, stroke=RULE)
t(49, 275, "TIER", 14, True, MUTED)
t(139, 275, "ERROR", 14, True, MUTED, "middle")
t(234, 275, "COUNT", 14, True, MUTED, "middle")
for row, m in enumerate((256, 64, 16, 4)):
    y = 282 + 38*row
    chip(39, y, 70, 32, str(m), 17, bold=True, fill=PALE, stroke=RULE)
    chip(113, y, 92, 32, "E<sub>%s</sub>" % m, 19, stroke=RULE)
    chip(209, y, 66, 32, "N<sub>%s</sub>" % m, 19, stroke=RULE)

# Only hardware present in the global target check appears here.
rect(315, 74, 882, 161, PALE, RULE, 1.1, layer="background")
t(334, 99, "GLOBAL BER TEST", 17, True, MUTED)
t(1178, 99, "G = 16,617,216", 15, color=MUTED, anchor="end")
chip(377, 113, 117, 38, "× 10<sup>4</sup>", 20)
chip(377, 171, 117, 38, "× G", 20)
line((275, 187), (337, 187), (337, 132), (377, 132), arrow=True)
t(302, 177, "E<sub>w</sub>", 15, color=MUTED)
line((275, 233), (353, 233), (353, 190), (377, 190), arrow=True)
t(302, 224, "B", 15, color=MUTED)

chip(553, 136, 67, 52, "≤", 28, bold=True)
line((494, 132), (530, 132), (530, 151), (553, 151), arrow=True)
line((494, 190), (530, 190), (530, 173), (553, 173), arrow=True)
chip(645, 188, 91, 33, "B = 0", 17, fill=WHITE, stroke=RULE)
line((353, 225), (631, 225), (631, 204), (645, 204), arrow=True, color=MUTED, width=1.1)
chip(763, 143, 66, 44, "OR", 18, True)
line((620, 162), (763, 162), arrow=True)
line((736, 204), (750, 204), (750, 175), (763, 175), arrow=True, color=MUTED, width=1.2)
chip(909, 141, 213, 48, "target_met", 22, True, BLUE_PALE, BLUE, BLUE)
line((829, 165), (909, 165), arrow=True, color=BLUE, width=1.8)
line((1122, 165), (1180, 165), arrow=True, color=BLUE, width=1.8)

# Datapath: one operand mux and one multiplier are time shared over six cycles.
line((315, 246), (1197, 246), color=RULE, width=1.25)
t(345, 269, "SHARED × UNIT", 16, True, MUTED)
t(548, 269, "PRODUCT REGISTERS", 16, True, MUTED)
t(817, 269, "CMP / SEL", 15, True, MUTED)
t(959, 269, "WINNER RECORDS", 15, True, MUTED)

# Tier data also selects the record written by the two first-stage MUXes.
line((290, 362), (315, 362), (315, 345), (347, 345), arrow=True)
t(304, 352, "M, E, N", 13, color=MUTED)

# An actual A/B operand MUX drives the fifth and sixth multiplier cycles.
# The two winner records remain independent until that selector.
line((1153, 283), (373, 283), (373, 321), color=MUTED, width=1.3, arrow=True)

# Operand selector, shared arithmetic unit, and serially filled product bank.
f.poly([(348, 316), (404, 334), (404, 375), (348, 393)],
       WHITE, INK, 1.5)
t(371, 356, "SEL", 17, True, anchor="middle")
line((404, 354), (438, 354), arrow=True)
f.circle(464, 354, 25, RED_PALE, RED, 1.5)
t(464, 365, "×", 33, True, RED, "middle")
t(464, 421, "32 × 9", 15, color=MUTED, anchor="middle")
line((489, 354), (517, 354), arrow=True)
line((517, 319), (517, 414), width=1.3)
port(517, 354)

# A single write port fills six physical registers in successive cycles.
rect(538, 297, 236, 145, WHITE, RULE, 1.1, layer="background")
products = [
    (303, "E<sub>256</sub>N<sub>64</sub>", "E<sub>64</sub>N<sub>256</sub>"),
    (351, "E<sub>16</sub>N<sub>4</sub>", "E<sub>4</sub>N<sub>16</sub>"),
    (399, "E<sub>A</sub>N<sub>B</sub>", "E<sub>B</sub>N<sub>A</sub>"),
]
for y, a, b in products:
    line((517, y+18), (538, y+18), arrow=True)
    chip(546, y, 109, 36, a, 18, fill=WHITE, stroke=RULE)
    chip(659, y, 109, 36, b, 18, fill=WHITE, stroke=RULE)
    line((774, y+18), (814, y+18), arrow=True)

# Two first-stage record MUXes and one final record MUX implement the exact
# hierarchical comparison from S_CMP_1 and S_UP_UPDATE.
for y in (303, 351, 399):
    rect(814, y, 112, 36)
    t(870, y+17, "CMP / SEL", 16, True, anchor="middle")
    t(870, y+32, "N &gt; 0", 13, color=MUTED, anchor="middle")
chip(952, 303, 126, 36, "R<sub>A</sub>: M, E, N", 17, fill=PALE, stroke=RULE)
chip(952, 351, 126, 36, "R<sub>B</sub>: M, E, N", 17, fill=PALE, stroke=RULE)
chip(952, 399, 126, 36, "j<sub>w</sub>  ·  tier ID", 18, True, RED_PALE, RED, RED)
for y in (321, 369, 417):
    line((926, y), (952, y), arrow=True)

# The A and B register buses are separate inputs to the operand MUX.
f.poly([(1102, 309), (1144, 322), (1144, 364), (1102, 382)],
       WHITE, MUTED, 1.2)
t(1122, 348, "A/B", 14, True, MUTED, "middle")
line((1078, 321), (1102, 321), arrow=True, color=MUTED, width=1.25)
line((1078, 369), (1102, 369), arrow=True, color=MUTED, width=1.25)
line((1144, 343), (1153, 343), (1153, 283), color=MUTED, width=1.3)
line((1078, 417), (1179, 417), arrow=True, color=RED, width=1.8)

line((24, 453), (1196, 453), color=RULE, width=1.3)

checks = f.save()
pdf = OUT / "DMT_Worst_tier_selection.pdf"
r = PdfReader(pdf)
w = PdfWriter()
for page in r.pages:
    page.scale_by(170/210)
    w.add_page(page)
with pdf.open("wb") as stream:
    w.write(stream)
doc = fitz.open(pdf)
doc[0].get_pixmap(dpi=340, alpha=False).save(OUT / "DMT_Worst_tier_selection.png")
doc[0].get_pixmap(matrix=fitz.Matrix(2.7, 2.7), alpha=False).save(OUT / "preview.png")
(OUT / "layout_checks.json").write_text(json.dumps(checks, indent=2), encoding="utf-8")
(OUT / "DMT_Worst_tier_caption.md").write_text(
    "**Suggested caption.** Hardware datapath for BER checking and worst-tier "
    "selection. Per-tone results accumulate the bit-weighted error E_w, "
    "loaded bits B, and four tier records (M, E_M, N_M). The global comparison "
    "generates target_met. A single 32 × 9-bit multiplier serially produces "
    "six registered cross products. Two compare/select stages retain winners "
    "A (256 vs 64) and B (16 vs 4), which return through the A/B operand "
    "MUX for the final comparison. The final compare/select stage emits j_w.\n\n"
    "**Definitions.** E_w = Σ_k b_k p_k, B = Σ_k b_k, "
    "E_M = Σ_{k:M_k=M} p_k, and N_M is the number of tones in tier M. "
    "For nonempty tiers, E_i N_j ≥ E_j N_i compares E_i/N_i "
    "against E_j/N_j without dividers. Empty tiers are excluded. "
    "The global predicate is (B = 0) OR (10⁴ E_w ≤ G B), "
    "where G = 16,617,216 in the supplied Q24 RTL. "
    "Equal mean errors favor higher-order tiers.\n\n"
    "**Drawing scope.** Product pairs depict six separately written 41-bit "
    "registers, not six multipliers. CMP/SEL groups a cross-product comparator, "
    "nonempty-tier qualification, and record-selection logic. The two outputs "
    "target_met and j_w feed the surrounding search controller. "
    "Clock, reset, register enables, and controller sequencing are omitted. "
    "Vector PDF: 170 × 65.5 mm; editable SVG and 340-dpi PNG supplied.\n",
    encoding="utf-8",
)
with zipfile.ZipFile(OUT / "DMT_Worst_tier_selection_editable.zip", "w", zipfile.ZIP_DEFLATED) as archive:
    for suffix in ("svg", "pdf", "png"):
        path = OUT / f"DMT_Worst_tier_selection.{suffix}"
        archive.write(path, path.name)
    cap = OUT / "DMT_Worst_tier_caption.md"
    archive.write(cap, cap.name)
    for source in (Path(__file__), Path(draw.__file__)):
        archive.write(source, source.name)
print(json.dumps(checks, indent=2))
