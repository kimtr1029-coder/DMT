from pathlib import Path
from dataclasses import dataclass
from html import escape
from html.parser import HTMLParser
import math, json, zipfile
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.colors import HexColor
from pypdf import PdfReader, PdfWriter
import fitz

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'output' / 'dmt_figures'
OUT.mkdir(parents=True, exist_ok=True)
FONT_DIR = Path('/usr/share/fonts/truetype/dejavu')
for name, file in [('Sans','DejaVuSans.ttf'), ('Bold','DejaVuSans-Bold.ttf'), ('Italic','DejaVuSans.ttf')]:
    pdfmetrics.registerFont(TTFont(name, str(FONT_DIR / file)))

INK='#1d2732'; MUTED='#526171'; LINE='#bdc7d0'; BLUE='#21659c'; BLUE_BG='#edf5fb'
WARM='#ae492b'; WARM_BG='#fff3ed'; LIGHT='#f5f7f9'; WHITE='#ffffff'

class RichParser(HTMLParser):
    def __init__(self):
        super().__init__(); self.runs=[]; self.style=[(1.0,0.0,None)]
    def handle_starttag(self, tag, attrs):
        scale, dy, font = self.style[-1]
        if tag=='sub': scale,dy=.72,.24
        elif tag=='sup': scale,dy=.72,-.42
        elif tag=='b': font='Bold'
        elif tag=='i': font='Italic'
        self.style.append((scale,dy,font))
    def handle_endtag(self,tag):
        if len(self.style)>1: self.style.pop()
    def handle_data(self,data):
        self.runs.append((data,*self.style[-1]))

def runs(s):
    p=RichParser(); p.feed(s); return p.runs

class Figure:
    def __init__(self, name, width=1400, height=1100):
        self.name=name; self.W=width; self.H=height
        self.layers={k:[] for k in ['background','edge','shape','text']}
        self.checks=[]
    def add(self, item, layer): self.layers[layer].append(item)
    def rect(self,x,y,w,h,fill=WHITE,stroke=INK,sw=1.8,r=0,layer='shape',dash=False):
        self.add(dict(kind='rect',x=x,y=y,w=w,h=h,fill=fill,stroke=stroke,sw=sw,r=r,dash=dash),layer)
    def poly(self,pts,fill=WHITE,stroke=INK,sw=1.8,layer='shape'):
        self.add(dict(kind='poly',pts=pts,fill=fill,stroke=stroke,sw=sw),layer)
    def circle(self,x,y,r,fill=WHITE,stroke=INK,sw=1.8):
        self.add(dict(kind='circle',x=x,y=y,r=r,fill=fill,stroke=stroke,sw=sw),'shape')
    def line(self,pts,color=INK,width=1.9,arrow=True,dash=False):
        self.add(dict(kind='line',pts=pts,stroke=color,sw=width,dash=dash),'edge')
        if arrow:
            a,b=pts[-2],pts[-1]; ang=math.atan2(b[1]-a[1],b[0]-a[0]); L=9; S=4.4
            p1=(b[0]-L*math.cos(ang)+S*math.sin(ang),b[1]-L*math.sin(ang)-S*math.cos(ang))
            p2=(b[0]-L*math.cos(ang)-S*math.sin(ang),b[1]-L*math.sin(ang)+S*math.cos(ang))
            self.poly([b,p1,p2],fill=color,stroke=color,sw=.5,layer='edge')
    def dot(self,x,y,color=INK):
        self.add(dict(kind='circle',x=x,y=y,r=3,fill=color,stroke=color,sw=0),'edge')
    def text(self,x,y,s,size=22,font='Sans',color=INK,anchor='start',maxw=None):
        rs=runs(s); width=sum(pdfmetrics.stringWidth(t,fo or font,size*sc) for t,sc,dy,fo in rs)
        if maxw is not None and width>maxw+0.2:
            self.checks.append({'text':s,'width':round(width,1),'allowed':maxw})
        left=x if anchor=='start' else x-width/2 if anchor=='middle' else x-width
        if left<0 or left+width>self.W or y<0 or y+size*.3>self.H:
            self.checks.append({'out_of_bounds':s,'x':left,'y':y,'width':width})
        self.add(dict(kind='text',x=left,y=y,s=s,runs=rs,size=size,font=font,color=color),'text')
        return width
    def box(self,x,y,w,h,lines,fill=WHITE,stroke=INK,size=22,boldfirst=True,color=INK):
        self.rect(x,y,w,h,fill=fill,stroke=stroke)
        lead=size*1.35; start=y+h/2-(len(lines)-1)*lead/2+size*.35
        for i,s in enumerate(lines):
            self.text(x+w/2,start+i*lead,s,size=size,font='Bold' if i==0 and boldfirst else 'Sans',color=color,anchor='middle',maxw=w-14)
    def diamond(self,cx,cy,w,h,lines,size=22):
        self.poly([(cx,cy-h/2),(cx+w/2,cy),(cx,cy+h/2),(cx-w/2,cy)],fill=BLUE_BG,stroke=BLUE)
        lead=size*1.2; y=cy-(len(lines)-1)*lead/2+size*.33
        for i,s in enumerate(lines): self.text(cx,y+i*lead,s,size,anchor='middle',font='Bold',maxw=w*.72)
    def panel(self,x,y,w,h,label,title):
        self.rect(x,y,w,h,stroke=LINE,sw=1.5,layer='background')
        self.text(x+20,y+34,f'({label})',size=22,font='Bold',color=BLUE)
        self.text(x+66,y+34,title,size=22,font='Bold',maxw=w-84)
    def head(self,num,title,subtitle):
        self.text(48,42,f'{num}  /  DMT BIT-LOADING ENGINE',size=19,font='Bold',color=BLUE)
        self.text(48,85,title,size=33,font='Bold')
        self.text(1352,43,subtitle,size=18,color=MUTED,anchor='end')
    def save(self):
        svg=['<?xml version="1.0" encoding="UTF-8"?>',f'<svg xmlns="http://www.w3.org/2000/svg" width="{self.W}" height="{self.H}" viewBox="0 0 {self.W} {self.H}">',f'<title>{escape(self.name)}</title>',f'<rect width="{self.W}" height="{self.H}" fill="white"/>']
        pdf_path=OUT/(self.name+'.pdf')
        # 210 mm wide: body text remains approximately 8-10 pt in the exported figure.
        scale=(210*72/25.4)/self.W
        c=canvas.Canvas(str(pdf_path),pagesize=(self.W*scale,self.H*scale),pageCompression=1)
        c.setTitle(self.name.replace('_',' ')); c.setAuthor('DMT research figure')
        c.scale(scale,scale)
        def fy(y): return self.H-y
        for layer in self.layers.values():
            for q in layer:
                kind=q['kind']; stroke=q.get('stroke'); fill=q.get('fill')
                if kind!='text':
                    if stroke: c.setStrokeColor(HexColor(stroke))
                    if fill: c.setFillColor(HexColor(fill))
                    c.setLineWidth(q.get('sw',1)); c.setDash([7,5] if q.get('dash') else [])
                attrs=f'fill="{fill or "none"}" stroke="{stroke or "none"}" stroke-width="{q.get("sw",1)}"'
                if q.get('dash'): attrs+=' stroke-dasharray="7 5"'
                if kind=='rect':
                    x,y,w,h=q['x'],q['y'],q['w'],q['h']
                    svg.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{q["r"]}" {attrs}/>')
                    c.roundRect(x,fy(y+h),w,h,q['r'],stroke=int(bool(stroke)),fill=int(bool(fill)))
                elif kind=='circle':
                    svg.append(f'<circle cx="{q["x"]}" cy="{q["y"]}" r="{q["r"]}" {attrs}/>')
                    c.circle(q['x'],fy(q['y']),q['r'],stroke=int(bool(stroke)),fill=int(bool(fill)))
                elif kind=='poly':
                    pts=q['pts']; svg.append('<polygon points="'+' '.join(f'{x},{y}' for x,y in pts)+f'" {attrs}/>')
                    p=c.beginPath();p.moveTo(pts[0][0],fy(pts[0][1]))
                    for x,y in pts[1:]:p.lineTo(x,fy(y))
                    p.close();c.drawPath(p,stroke=int(bool(stroke)),fill=int(bool(fill)))
                elif kind=='line':
                    pts=q['pts']; d='M '+' L '.join(f'{x},{y}' for x,y in pts)
                    svg.append(f'<path d="{d}" fill="none" stroke="{stroke}" stroke-width="{q["sw"]}"'+(' stroke-dasharray="7 5"' if q.get('dash') else '')+'/>')
                    p=c.beginPath();p.moveTo(pts[0][0],fy(pts[0][1]))
                    for x,y in pts[1:]:p.lineTo(x,fy(y))
                    c.drawPath(p,stroke=1,fill=0)
                elif kind=='text':
                    x=q['x']; y=q['y']; size=q['size']; col=q['color']
                    spans=[]
                    for txt,sc,dy,fo in q['runs']:
                        f=fo or q['font']; sz=size*sc; yy=y+dy*size
                        c.setFillColor(HexColor(col));c.setFont(f,sz);c.drawString(x,fy(yy),txt)
                        weight='700' if f=='Bold' else '400'; style='italic' if f=='Italic' else 'normal'
                        spans.append(f'<tspan x="{x:.3f}" y="{yy:.3f}" font-size="{sz:.3f}" font-weight="{weight}" font-style="{style}">{escape(txt)}</tspan>')
                        x+=pdfmetrics.stringWidth(txt,f,sz)
                    svg.append(f'<text font-family="DejaVu Sans, Arial, sans-serif" fill="{col}">'+''.join(spans)+'</text>')
        c.showPage();c.save();svg.append('</svg>')
        (OUT/(self.name+'.svg')).write_text('\n'.join(svg),encoding='utf-8')
        doc=fitz.open(pdf_path);page=doc[0]
        page.get_pixmap(matrix=fitz.Matrix(2.8,2.8),alpha=False).save(OUT/(self.name+'.png'))
        return {'name':self.name,'text_checks':self.checks,'pdf':str(pdf_path)}

