from pathlib import Path
import math,json
import figure_renderer as d
from pypdf import PdfReader,PdfWriter
import fitz
O=Path(__file__).resolve().parent / 'rendered';O.mkdir(parents=True,exist_ok=True);d.OUT=O
f=d.Figure('DMT_BER_pipeline',1170,550)
INK='#1d1d1d';RED='#a92d38';BLUE='#286788';PAPER='#ffffff';GRAY='#f3f4f5';TINT='#edf4f8'
def txt(x,y,value,sz=20,b=False,c=INK,a='middle',maxw=None):f.text(x,y,value,sz,'Bold' if b else 'Sans',c,a,maxw)
def rect(x,y,w,h,fill=PAPER,stroke=INK,sw=1.35,layer='shape'):f.rect(x,y,w,h,fill,stroke,sw,layer=layer)
def wire(pts,c=INK,arrow=True):
 f.line(pts,c,1.45,False)
 if arrow:
  a,b=pts[-2],pts[-1];ang=math.atan2(b[1]-a[1],b[0]-a[0]);L=7;S=3.1
  f.poly([b,(b[0]-L*math.cos(ang)+S*math.sin(ang),b[1]-L*math.sin(ang)-S*math.cos(ang)),(b[0]-L*math.cos(ang)-S*math.sin(ang),b[1]-L*math.sin(ang)+S*math.cos(ang))],c,c,.3,layer='edge')
def register(x,y,w,h,label,size=21):
 rect(x,y,w,h,GRAY);f.add(dict(kind='line',pts=[(x+4,y),(x+4,y+h)],stroke=INK,sw=1),'shape')
 txt(x+w/2,y+h/2+size*.34,label,size,True,maxw=w-12)
def product(x,y):f.circle(x,y,21,'#fff1f2',RED,1.65);txt(x,y+11,'×',34,True,RED)
def lut_bank(x,y,w,h,name,index,data):
 rect(x,y,w,h)
 txt(x+w/2,y+28,name,23,True)
 for i,M in enumerate([256,64,16,4]):
  row=y+39+i*22
  rect(x+9,row,42,22,GRAY,sw=.85)
  rect(x+51,row,w-60,22,PAPER,sw=.85)
  txt(x+30,row+16,str(M),15,True,maxw=38)
  txt(x+51+(w-60)/2,row+16,f'{index}<sub>{M}</sub>',17,True,maxw=w-68)
 txt(x+w/2,y+h-8,data,16)
# Fine black artwork on white; accent colors have one meaning each.
rect(6,6,1158,538,None,INK,1.65,layer='background')
# 4-threshold qualification is a hardware input to R1, not a worked example.
rect(23,100,252,279,PAPER,INK,1.35,layer='background')
txt(149,129,'QAM selection',21,True)
txt(149,150,'γ<sub>k,dB</sub> ≥ θ<sup>0</sup><sub>M</sub> + m<sub>M</sub>',17,maxw=224)
for i,(M,base) in enumerate([(256,24),(64,18),(16,12),(4,6)]):
 y=158+i*37
 rect(37,y,225,34)
 rect(37,y,54,34,GRAY,sw=.9)
 rect(91,y,130,34,PAPER,sw=.9)
 rect(221,y,41,34,TINT,sw=.9)
 txt(64,y+23,str(M),18,True)
 txt(156,y+23,f'{base} + m<sub>{M}</sub>',18,maxw=122)
 txt(241.5,y+23,'≥',22,True)
 wire([(262,y+17),(268,y+17)],BLUE,False)
wire([(268,175),(268,286),(249,286),(249,324)],BLUE)
rect(49,324,200,50,GRAY)
txt(149,346,'Priority encoder',19,True)
txt(149,367,'256>64>16>4>OFF',17,maxw=185)
# Stage 1/2/3 tier code stream. Address only the local coefficient bank.
for x,w,name,M in [(315,105,'R1','M<sub>1</sub>'),(510,125,'R2','M<sub>2</sub>'),(1071,78,'R3','M<sub>3</sub>')]:
 txt(x+w/2,35,name,19,True)
 register(x,49,w,43,M,22)
wire([(249,349),(293,349),(293,70),(315,70)])
wire([(420,70),(510,70)],RED)
wire([(635,70),(1071,70)],RED)
f.dot(445,70,RED);f.dot(905,70,RED)
wire([(445,70),(445,185)],RED)
wire([(905,70),(905,185)],RED)
# Small, genuine coefficient banks; the tier labels index Q16 parameters.
lut_bank(360,185,170,156,'K<sub>M</sub>','K','Q16')
lut_bank(820,185,170,156,'C<sub>M</sub>','C','Q16')
wire([(440,341),(440,364)])
wire([(905,341),(905,348),(860,348),(860,364)])
# Stage 1 SNR multiplication and stage 2 registered exponent fields.
register(315,365,100,43,'γ<sub>k,lin</sub>',18)
wire([(415,386),(419,386)])
product(440,386)
wire([(461,386),(510,386)])
txt(481,377,'Y',19)
txt(440,435,'16 × 32',17)
f.dot(484,386,INK)
register(510,364,125,44,'f: Y[31:27]',17)
register(510,418,125,43,'q: Y[36:32]',17)
register(510,472,125,43,'s: y ≥ 24',18)
wire([(484,386),(484,439),(510,439)])
f.dot(484,439,INK)
wire([(484,439),(484,493),(510,493)])
# 5-bit-addressed, 32-word ROM. All words belong to the connected LUT.
rect(650,167,160,161,TINT)
txt(730,192,'Fraction LUT',20,True)
txt(730,217,'f [4:0]  →  L[f]',17)
for row in range(4):
 for col in range(8):
  rect(658+col*18,229+row*17,17,15,'#fff0f1' if (row,col)==(1,4) else PAPER,sw=.65)
txt(730,321,'32 × 17-bit',17,True)
wire([(635,386),(643,386),(643,265),(650,265)])
wire([(730,328),(730,386),(839,386)])
txt(788,377,'L[f]',17)
# Q24 product, actual integer shift, and saturation to zero.
product(860,386)
wire([(881,386),(943,386)])
txt(914,375,'[31:8]',17)
txt(860,435,'16 × 17',17)
rect(943,364,65,44)
txt(975.5,393,'≫ q',24,True)
wire([(635,439),(975,439),(975,408)],BLUE)
txt(755,434,'q',18,c=BLUE)
f.poly([(1020,348),(1047,365),(1047,406),(1020,423)],fill=PAPER,stroke=INK,sw=1.5)
wire([(1008,386),(1020,386)])
wire([(1000,362),(1020,362)])
txt(1004,353,'0',18,True)
wire([(635,493),(1034,493),(1034,422)],BLUE)
txt(755,487,'s',18,c=BLUE)
register(1065,364,82,44,'P<sub>b,k</sub>',21)
wire([(1047,386),(1065,386)])
txt(1106,435,'Q24',18,True)
res=f.save();p=O/'DMT_BER_pipeline.pdf';r=PdfReader(p);w=PdfWriter()
for page in r.pages:page.scale_by(170/210);w.add_page(page)
with p.open('wb') as h:w.write(h)
a=fitz.open(p);a[0].get_pixmap(dpi=400,alpha=False).save(O/'DMT_BER_pipeline.png');a[0].get_pixmap(matrix=fitz.Matrix(3,3),alpha=False).save(O/'preview.png')
(O/'layout_checks.json').write_text(json.dumps(res,indent=2));print(json.dumps(res))
