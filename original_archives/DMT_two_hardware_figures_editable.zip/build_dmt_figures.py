from pathlib import Path
from dataclasses import dataclass
from html import escape
from html.parser import HTMLParser
import math, json, zipfile
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.colors import HexColor
from pypdf import PdfReader, PdfWriter
import fitz

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'output' / 'dmt_figures'
OUT.mkdir(parents=True, exist_ok=True)
FONT_DIR = Path('/usr/share/fonts/truetype/dejavu')
for name, file in [('Sans','DejaVuSans.ttf'), ('Bold','DejaVuSans-Bold.ttf'), ('Italic','DejaVuSans.ttf')]:
    pdfmetrics.registerFont(TTFont(name, str(FONT_DIR / file)))

INK='#1d2732'; MUTED='#526171'; LINE='#bdc7d0'; BLUE='#21659c'; BLUE_BG='#edf5fb'
WARM='#ae492b'; WARM_BG='#fff3ed'; LIGHT='#f5f7f9'; WHITE='#ffffff'

class RichParser(HTMLParser):
    def __init__(self):
        super().__init__(); self.runs=[]; self.style=[(1.0,0.0,None)]
    def handle_starttag(self, tag, attrs):
        scale, dy, font = self.style[-1]
        if tag=='sub': scale,dy=.72,.24
        elif tag=='sup': scale,dy=.72,-.42
        elif tag=='b': font='Bold'
        elif tag=='i': font='Italic'
        self.style.append((scale,dy,font))
    def handle_endtag(self,tag):
        if len(self.style)>1: self.style.pop()
    def handle_data(self,data):
        self.runs.append((data,*self.style[-1]))

def runs(s):
    p=RichParser(); p.feed(s); return p.runs

class Figure:
    def __init__(self, name, width=1400, height=1100):
        self.name=name; self.W=width; self.H=height
        self.layers={k:[] for k in ['background','edge','shape','text']}
        self.checks=[]
    def add(self, item, layer): self.layers[layer].append(item)
    def rect(self,x,y,w,h,fill=WHITE,stroke=INK,sw=1.8,r=0,layer='shape',dash=False):
        self.add(dict(kind='rect',x=x,y=y,w=w,h=h,fill=fill,stroke=stroke,sw=sw,r=r,dash=dash),layer)
    def poly(self,pts,fill=WHITE,stroke=INK,sw=1.8,layer='shape'):
        self.add(dict(kind='poly',pts=pts,fill=fill,stroke=stroke,sw=sw),layer)
    def circle(self,x,y,r,fill=WHITE,stroke=INK,sw=1.8):
        self.add(dict(kind='circle',x=x,y=y,r=r,fill=fill,stroke=stroke,sw=sw),'shape')
    def line(self,pts,color=INK,width=1.9,arrow=True,dash=False):
        self.add(dict(kind='line',pts=pts,stroke=color,sw=width,dash=dash),'edge')
        if arrow:
            a,b=pts[-2],pts[-1]; ang=math.atan2(b[1]-a[1],b[0]-a[0]); L=9; S=4.4
            p1=(b[0]-L*math.cos(ang)+S*math.sin(ang),b[1]-L*math.sin(ang)-S*math.cos(ang))
            p2=(b[0]-L*math.cos(ang)-S*math.sin(ang),b[1]-L*math.sin(ang)+S*math.cos(ang))
            self.poly([b,p1,p2],fill=color,stroke=color,sw=.5,layer='edge')
    def dot(self,x,y,color=INK):
        self.add(dict(kind='circle',x=x,y=y,r=3,fill=color,stroke=color,sw=0),'edge')
    def text(self,x,y,s,size=22,font='Sans',color=INK,anchor='start',maxw=None):
        rs=runs(s); width=sum(pdfmetrics.stringWidth(t,fo or font,size*sc) for t,sc,dy,fo in rs)
        if maxw is not None and width>maxw+0.2:
            self.checks.append({'text':s,'width':round(width,1),'allowed':maxw})
        left=x if anchor=='start' else x-width/2 if anchor=='middle' else x-width
        if left<0 or left+width>self.W or y<0 or y+size*.3>self.H:
            self.checks.append({'out_of_bounds':s,'x':left,'y':y,'width':width})
        self.add(dict(kind='text',x=left,y=y,s=s,runs=rs,size=size,font=font,color=color),'text')
        return width
    def box(self,x,y,w,h,lines,fill=WHITE,stroke=INK,size=22,boldfirst=True,color=INK):
        self.rect(x,y,w,h,fill=fill,stroke=stroke)
        lead=size*1.35; start=y+h/2-(len(lines)-1)*lead/2+size*.35
        for i,s in enumerate(lines):
            self.text(x+w/2,start+i*lead,s,size=size,font='Bold' if i==0 and boldfirst else 'Sans',color=color,anchor='middle',maxw=w-14)
    def diamond(self,cx,cy,w,h,lines,size=22):
        self.poly([(cx,cy-h/2),(cx+w/2,cy),(cx,cy+h/2),(cx-w/2,cy)],fill=BLUE_BG,stroke=BLUE)
        lead=size*1.2; y=cy-(len(lines)-1)*lead/2+size*.33
        for i,s in enumerate(lines): self.text(cx,y+i*lead,s,size,anchor='middle',font='Bold',maxw=w*.72)
    def panel(self,x,y,w,h,label,title):
        self.rect(x,y,w,h,stroke=LINE,sw=1.5,layer='background')
        self.text(x+20,y+34,f'({label})',size=22,font='Bold',color=BLUE)
        self.text(x+66,y+34,title,size=22,font='Bold',maxw=w-84)
    def head(self,num,title,subtitle):
        self.text(48,42,f'{num}  /  DMT BIT-LOADING ENGINE',size=19,font='Bold',color=BLUE)
        self.text(48,85,title,size=33,font='Bold')
        self.text(1352,43,subtitle,size=18,color=MUTED,anchor='end')
    def save(self):
        svg=['<?xml version="1.0" encoding="UTF-8"?>',f'<svg xmlns="http://www.w3.org/2000/svg" width="{self.W}" height="{self.H}" viewBox="0 0 {self.W} {self.H}">',f'<title>{escape(self.name)}</title>',f'<rect width="{self.W}" height="{self.H}" fill="white"/>']
        pdf_path=OUT/(self.name+'.pdf')
        # 210 mm wide: body text remains approximately 8-10 pt in the exported figure.
        scale=(210*72/25.4)/self.W
        c=canvas.Canvas(str(pdf_path),pagesize=(self.W*scale,self.H*scale),pageCompression=1)
        c.setTitle(self.name.replace('_',' ')); c.setAuthor('DMT research figure')
        c.scale(scale,scale)
        def fy(y): return self.H-y
        for layer in self.layers.values():
            for q in layer:
                kind=q['kind']; stroke=q.get('stroke'); fill=q.get('fill')
                if kind!='text':
                    if stroke: c.setStrokeColor(HexColor(stroke))
                    if fill: c.setFillColor(HexColor(fill))
                    c.setLineWidth(q.get('sw',1)); c.setDash([7,5] if q.get('dash') else [])
                attrs=f'fill="{fill or "none"}" stroke="{stroke or "none"}" stroke-width="{q.get("sw",1)}"'
                if q.get('dash'): attrs+=' stroke-dasharray="7 5"'
                if kind=='rect':
                    x,y,w,h=q['x'],q['y'],q['w'],q['h']
                    svg.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{q["r"]}" {attrs}/>')
                    c.roundRect(x,fy(y+h),w,h,q['r'],stroke=int(bool(stroke)),fill=int(bool(fill)))
                elif kind=='circle':
                    svg.append(f'<circle cx="{q["x"]}" cy="{q["y"]}" r="{q["r"]}" {attrs}/>')
                    c.circle(q['x'],fy(q['y']),q['r'],stroke=int(bool(stroke)),fill=int(bool(fill)))
                elif kind=='poly':
                    pts=q['pts']; svg.append('<polygon points="'+' '.join(f'{x},{y}' for x,y in pts)+f'" {attrs}/>')
                    p=c.beginPath();p.moveTo(pts[0][0],fy(pts[0][1]))
                    for x,y in pts[1:]:p.lineTo(x,fy(y))
                    p.close();c.drawPath(p,stroke=int(bool(stroke)),fill=int(bool(fill)))
                elif kind=='line':
                    pts=q['pts']; d='M '+' L '.join(f'{x},{y}' for x,y in pts)
                    svg.append(f'<path d="{d}" fill="none" stroke="{stroke}" stroke-width="{q["sw"]}"'+(' stroke-dasharray="7 5"' if q.get('dash') else '')+'/>')
                    p=c.beginPath();p.moveTo(pts[0][0],fy(pts[0][1]))
                    for x,y in pts[1:]:p.lineTo(x,fy(y))
                    c.drawPath(p,stroke=1,fill=0)
                elif kind=='text':
                    x=q['x']; y=q['y']; size=q['size']; col=q['color']
                    spans=[]
                    for txt,sc,dy,fo in q['runs']:
                        f=fo or q['font']; sz=size*sc; yy=y+dy*size
                        c.setFillColor(HexColor(col));c.setFont(f,sz);c.drawString(x,fy(yy),txt)
                        weight='700' if f=='Bold' else '400'; style='italic' if f=='Italic' else 'normal'
                        spans.append(f'<tspan x="{x:.3f}" y="{yy:.3f}" font-size="{sz:.3f}" font-weight="{weight}" font-style="{style}">{escape(txt)}</tspan>')
                        x+=pdfmetrics.stringWidth(txt,f,sz)
                    svg.append(f'<text font-family="DejaVu Sans, Arial, sans-serif" fill="{col}">'+''.join(spans)+'</text>')
        c.showPage();c.save();svg.append('</svg>')
        (OUT/(self.name+'.svg')).write_text('\n'.join(svg),encoding='utf-8')
        doc=fitz.open(pdf_path);page=doc[0]
        page.get_pixmap(matrix=fitz.Matrix(2.8,2.8),alpha=False).save(OUT/(self.name+'.png'))
        return {'name':self.name,'text_checks':self.checks,'pdf':str(pdf_path)}


def algorithm():
    f=Figure('DMT_01_algorithm',1400,1100)
    f.head('01','Adaptive bit loading and margin search','ALGORITHM / EXECUTION FLOW')
    f.rect(48,112,1304,70,fill=LIGHT,stroke=None,layer='background')
    f.text(69,140,'Inputs',21,font='Bold')
    f.text(155,140,'SNRs γ<sub>k,dB</sub>,  k = 1, …, 255;   margins m = (m<sub>256</sub>, m<sub>64</sub>, m<sub>16</sub>, m<sub>4</sub>);   step Δ',21)
    f.text(69,167,'Base thresholds',20,font='Bold')
    f.text(267,167,'θ<sup>(0)</sup> = (24, 18, 12, 6) dB, in the same QAM order',20)

    f.panel(48,206,636,812,'a','Margin-search control')
    f.panel(710,206,642,318,'b','One complete tone scan')
    f.panel(710,546,642,214,'c','Worst-tier margin increase')
    f.panel(710,782,642,236,'d','Down-step refinement')

    # Control flow only: there are no circuit symbols in this figure.
    f.box(280,269,314,63,['Initialize margins m'],fill=LIGHT)
    f.box(262,369,350,74,['Evaluate all 255 tones','using scan (b)'],fill=BLUE_BG,stroke=BLUE)
    f.diamond(437,513,252,94,['Target met?'])
    f.box(88,465,186,98,['Raise margin','of worst tier (c)'],fill=WARM_BG,stroke=WARM,size=20)
    f.box(262,623,350,74,['Evaluate down-step','candidates using (d)'],fill=BLUE_BG,stroke=BLUE)
    f.diamond(437,774,252,98,['Any feasible','candidate?'],size=21)
    f.box(88,726,186,99,['Accept trial','margins'],fill=WARM_BG,stroke=WARM,size=20)
    f.box(262,899,350,80,['Keep current margins','Output allocation {M<sub>k</sub>}'],fill=LIGHT)
    f.line([(437,332),(437,369)])
    f.line([(437,443),(437,466)])
    f.line([(311,513),(274,513)],color=WARM)
    f.text(291,499,'No',18,color=WARM,anchor='middle')
    f.line([(181,465),(181,350),(437,350),(437,369)],color=WARM)
    f.dot(437,350,WARM)
    f.line([(437,560),(437,623)],color=BLUE)
    f.text(450,597,'Yes',19,color=BLUE)
    f.line([(437,697),(437,725)])
    f.line([(311,774),(274,774)],color=WARM)
    f.text(291,759,'Yes',18,color=WARM,anchor='middle')
    f.line([(181,726),(181,601),(437,601),(437,623)],color=WARM)
    f.dot(437,601,WARM)
    f.line([(437,823),(437,899)],color=BLUE)
    f.text(450,865,'No',19,color=BLUE)

    f.text(734,273,'For each tone k:',21,font='Bold')
    f.text(734,311,'θ<sub>M</sub> = θ<sub>M</sub><sup>(0)</sup> + m<sub>M</sub>,    M ∈ {4, 16, 64, 256}',21,maxw=594)
    f.text(734,349,'M<sub>k</sub> = max({0} ∪ {M : γ<sub>k,dB</sub> ≥ θ<sub>M</sub>})',22,maxw=594)
    f.text(734,387,'b<sub>k</sub> = log<sub>2</sub>M<sub>k</sub>; OFF → b<sub>k</sub> = 0. Estimate Q24 p<sub>k</sub>.',21,maxw=594)
    f.text(734,426,'E<sub>w</sub> = Σ<sub>k</sub> b<sub>k</sub>p<sub>k</sub>,       B = Σ<sub>k</sub> b<sub>k</sub>',23,maxw=594)
    f.rect(732,458,598,44,fill=BLUE_BG,stroke=None,layer='background')
    f.text(749,488,'Target test:  G B ≥ 10<sup>4</sup>E<sub>w</sub>',23,font='Bold')

    f.text(734,613,'Compare tier statistics by cross multiplication:',20,maxw=594)
    f.text(734,651,'E<sub>i</sub>N<sub>j</sub> ≥ E<sub>j</sub>N<sub>i</sub>  ⇔  E<sub>i</sub>/N<sub>i</sub> ≥ E<sub>j</sub>/N<sub>j</sub>',24,maxw=594)
    f.text(734,687,'Choose j with largest E<sub>M</sub>/N<sub>M</sub> among N<sub>M</sub> &gt; 0.',20,maxw=594)
    f.text(734,729,'Update only that margin:  m<sub>j</sub> ← m<sub>j</sub> + Δ',23,font='Bold',color=WARM,maxw=594)

    f.text(734,850,'Candidate j:  m<sup>(j)</sup> = m − Δe<sub>j</sub>,  j ∈ {4, 16, 64, 256}',21,maxw=594)
    f.text(734,890,'Eligible if m<sub>j</sub> ≥ Δ; evaluate with scan (b).',21,maxw=594)
    f.text(734,930,'Choose the passing trial with the largest B.',21,maxw=594)
    f.text(734,970,'Ties: 4, 16, 64, 256. Repeat; stop if none passes.',21,maxw=594)

    f.text(48,1054,'Arrows show execution order.  Each accepted trial becomes the current margin vector.',20,color=MUTED)
    f.text(48,1080,'G = 16,617,216.  p<sub>k</sub>: Q24 BER code.  E<sub>M</sub>: tier error sum; N<sub>M</sub>: tier population.  e<sub>j</sub>: unit vector.',18,color=MUTED)
    return f


def hardware():
    f=Figure('DMT_02_hardware',1400,1140)
    f.head('02','Datapath and control organization','HARDWARE / FUNCTIONAL ARCHITECTURE')
    f.panel(48,113,1304,303,'a','Engine interfaces and feedback')
    f.panel(48,438,606,370,'b','QAM selection')
    f.panel(680,438,672,370,'c','BER estimation')
    f.panel(48,830,1304,253,'d','Statistics and decision units')

    # (a) Distinct typed arrows: solid data buses, dashed control/status.
    f.box(77,191,173,70,['SNR storage','γ<sub>k,dB</sub>, x<sub>k</sub>'],size=21)
    f.box(319,191,198,70,['QAM selector','detail (b)'],size=21)
    f.box(589,191,209,70,['BER estimator','detail (c)'],size=21)
    f.box(872,191,205,70,['Statistics','detail (d)'],size=21)
    f.box(1151,191,173,70,['Decision units','detail (d)'],size=19)
    f.line([(250,227),(319,227)])
    f.text(283,213,'γ<sub>k,dB</sub>',19,anchor='middle')
    f.line([(517,227),(589,227)])
    f.text(552,213,'M<sub>k</sub>',20,anchor='middle')
    f.line([(798,227),(872,227)])
    f.text(835,203,'M<sub>k</sub>,',18,anchor='middle')
    f.text(835,248,'P<sub>b,k</sub>',18,anchor='middle')
    f.line([(1077,227),(1151,227)])
    f.text(1114,209,'stats',18,anchor='middle')
    f.line([(163,191),(163,169),(694,169),(694,191)])
    f.text(560,162,'x<sub>k</sub>',18,anchor='middle')
    f.box(319,310,198,64,['Margin bank','m<sub>256</sub>, m<sub>64</sub>, m<sub>16</sub>, m<sub>4</sub>'],fill=WARM_BG,stroke=WARM,size=19)
    f.line([(418,310),(418,261)],color=WARM)
    f.text(402,290,'m',20,color=WARM,anchor='end')
    f.box(667,310,410,64,['Search controller','scan control + margin-update logic'],fill=BLUE_BG,stroke=BLUE,size=21)
    f.line([(418,283),(716,283),(716,310)],color=WARM)
    f.dot(418,283,WARM)
    f.text(576,276,'m<sub>current</sub>',18,color=WARM,anchor='middle')
    f.line([(667,331),(517,331)],color=WARM)
    f.text(590,321,'m<sub>next</sub>',18,color=WARM,anchor='middle')
    f.line([(667,355),(517,355)],color=BLUE,dash=True)
    f.text(591,378,'write enable',18,color=BLUE,anchor='middle')
    f.line([(1237,261),(1237,342),(1077,342)],color=BLUE,dash=True)
    f.text(1218,293,'target_met',18,color=BLUE,anchor='end')
    f.text(1218,320,'worst tier',18,color=BLUE,anchor='end')
    f.line([(717,374),(717,395),(163,395),(163,261)],color=BLUE,dash=True)
    f.text(179,389,'tone index k / scan control',17,color=BLUE)
    f.line([(787,310),(787,283),(975,283),(975,261)],color=BLUE,dash=True)
    f.text(876,303,'clear / enable',18,color=BLUE,anchor='middle')

    # (b) QAM decision circuit functions, not an example bit vector.
    f.box(74,513,163,57,['Base values','24, 18, 12, 6 dB'],size=18)
    f.box(74,634,163,57,['Margins','m<sub>M</sub>'],fill=WARM_BG,stroke=WARM,size=20)
    f.circle(271,602,20);f.text(271,610,'+',28,anchor='middle')
    f.line([(237,542),(271,542),(271,582)])
    f.line([(237,663),(271,663),(271,622)],color=WARM)
    f.box(322,563,120,79,['Threshold','tests'],size=18)
    f.line([(291,602),(322,602)])
    f.text(307,587,'θ<sub>M</sub>',18,anchor='middle')
    f.text(382,519,'γ<sub>k,dB</sub>',21,anchor='middle')
    f.line([(382,530),(382,563)])
    f.box(486,563,139,79,['Priority','encoder'],size=20)
    f.line([(442,602),(486,602)])
    f.text(464,580,'c<sub>M</sub>',19,anchor='middle')
    f.line([(555,642),(555,690)])
    f.text(555,718,'M<sub>k</sub>',23,anchor='middle')
    f.text(76,742,'c<sub>M</sub> = [γ<sub>k,dB</sub> ≥ θ<sub>M</sub>]; highest eligible M wins.',20,maxw=552)
    f.text(76,780,'No eligible tier → OFF.  θ<sub>M</sub> = θ<sub>M</sub><sup>(0)</sup> + m<sub>M</sub>',20,maxw=552)

    # (c) Named coefficient ports avoid artificial physical routing claims.
    f.box(711,509,170,58,['Coefficients','K<sub>M</sub>, C<sub>M</sub>'],size=20)
    f.text(796,494,'M<sub>k</sub>',19,anchor='middle')
    f.line([(796,498),(796,509)])
    f.circle(796,624,19);f.text(796,632,'×',27,anchor='middle')
    f.line([(796,567),(796,605)])
    f.text(807,595,'K<sub>M</sub>',18)
    f.text(711,632,'x<sub>k</sub>',22)
    f.line([(743,624),(777,624)])
    f.box(904,558,185,103,['Y fields','q = Y[36:32]','f = Y[31:27]'],size=20)
    f.line([(815,624),(904,624)])
    f.text(860,609,'Y',20,anchor='middle')
    f.box(711,721,151,55,['LUT (32)','L[f]'],size=20)
    f.box(905,721,120,55,['× C<sub>M</sub>'],size=23,boldfirst=False)
    f.box(1069,721,118,55,['q scaling'],size=20)
    f.box(1228,712,97,71,['Cutoff','select'],size=19)
    f.line([(862,749),(905,749)])
    f.line([(1025,749),(1069,749)])
    f.line([(1187,749),(1228,749)])
    f.line([(939,661),(939,677),(786,677),(786,721)])
    f.text(803,701,'f',18)
    f.line([(994,661),(994,685),(1128,685),(1128,721)])
    f.text(1139,703,'q',18)
    # C_M is a named port from the coefficient table.
    f.line([(737,567),(737,584)])
    f.text(737,605,'C<sub>M</sub>',19,anchor='middle')
    f.text(965,700,'C<sub>M</sub>',18,anchor='middle')
    f.line([(965,703),(965,721)])
    f.line([(849,624),(849,588)],arrow=False)
    f.dot(849,624)
    f.box(1126,514,199,63,['Cutoff test','s = [Y ≥ 24]'],size=19)
    f.line([(849,588),(849,580),(894,580),(894,485),(1226,485),(1226,514)])
    f.line([(1277,577),(1277,712)])
    f.text(1288,651,'s',19)
    f.line([(1325,749),(1339,749),(1339,793),(1277,793)])
    f.text(1232,800,'P<sub>b,k</sub>',21,anchor='end')

    # (d) Statistical datapath plus functional cross-product comparison.
    f.box(78,906,248,149,['Accumulator bank','E<sub>w</sub> = Σ b<sub>k</sub>P<sub>b,k</sub>','B = Σ b<sub>k</sub>','Tier statistics E<sub>M</sub>, N<sub>M</sub>'],size=21)
    f.text(202,888,'M<sub>k</sub>, P<sub>b,k</sub>',19,anchor='middle')
    f.line([(202,895),(202,906)])
    f.box(418,903,364,67,['Target comparator','G B ≥ 10<sup>4</sup>E<sub>w</sub>'],size=22)
    f.line([(326,938),(418,938)])
    f.text(372,923,'E<sub>w</sub>, B',19,anchor='middle')
    f.line([(782,938),(1042,938)],color=BLUE,dash=True)
    f.text(1060,946,'target_met',22,color=BLUE)
    f.box(418,1001,364,67,['Cross-product comparator','E<sub>i</sub>N<sub>j</sub> versus E<sub>j</sub>N<sub>i</sub>'],size=21)
    f.line([(326,1034),(418,1034)])
    f.text(371,1017,'E<sub>M</sub>, N<sub>M</sub>',17,anchor='middle')
    f.box(845,1001,260,67,['Tier selector','winner index'],size=21)
    f.line([(782,1034),(845,1034)])
    f.line([(1105,1034),(1211,1034)],color=BLUE,dash=True)
    f.text(1230,1041,'j<sub>worst</sub>',22,color=BLUE)

    f.line([(48,1110),(98,1110)],arrow=True)
    f.text(110,1117,'Data',18,color=MUTED)
    f.line([(197,1110),(247,1110)],arrow=True,color=BLUE,dash=True)
    f.text(259,1117,'Control / status',18,color=BLUE)
    f.line([(454,1110),(504,1110)],arrow=True,color=WARM)
    f.text(516,1117,'Margin data',18,color=WARM)
    f.text(1352,1117,'Functional blocks; resource sharing and timing follow RTL.',18,color=MUTED,anchor='end')
    return f


def main():
    figs=[algorithm(),hardware()]
    checks=[f.save() for f in figs]
    writer=PdfWriter()
    for f in figs:
        writer.append(str(OUT/(f.name+'.pdf')))
    writer.add_metadata({'/Title':'DMT bit-loading engine: algorithm and functional hardware architecture'})
    with (OUT/'DMT_algorithm_hardware.pdf').open('wb') as w: writer.write(w)
    (OUT/'validation.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2))
    print(json.dumps(checks,ensure_ascii=False,indent=2))

if __name__=='__main__': main()
