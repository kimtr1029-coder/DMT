"""Two full-width publication figures for the DMT bit-loading hardware.

Figure (a) follows one tone through the registered QAM and Q24 BER datapath.
Figure (b) shows one reused tone core, scan statistics, search control, and
the four-coordinate margin register-transfer path.  The connections follow
per_qam_datapath_balanced and per_qam_margin_ctrl_balanced.
"""
from pathlib import Path
import json
import zipfile

import fitz
from pypdf import PdfReader, PdfWriter
import build_dmt_figures as d


OUT = Path(__file__).resolve().parent / "output/system_hardware/two_figures"
OUT.mkdir(parents=True, exist_ok=True)
d.OUT = OUT

W = 1500
INK = "#26313a"
SECONDARY = "#52636f"
RULE = "#aab6bf"
FAINT = "#d9e0e5"
PALE = "#f6f8f9"
WHITE = "#ffffff"
BLUE = "#285f82"
BLUE_PALE = "#eaf3f8"
RED = "#a53342"
RED_PALE = "#fff0f1"


def T(f, x, y, s, z=20, bold=False, col=INK, anchor="start", maxw=None):
    return f.text(x, y, s, z, "Bold" if bold else "Sans", col, anchor, maxw)


def R(f, x, y, w, h, fill=WHITE, stroke=RULE, sw=1.25, bg=False):
    f.rect(x, y, w, h, fill, stroke, sw,
           layer="background" if bg else "shape")


def C(f, x, y, w, h, s, z=19, fill=WHITE, stroke=RULE,
      col=INK, bold=False, reg=False):
    R(f, x, y, w, h, fill, stroke, 1.18)
    if reg:
        f.add(dict(kind="line", pts=[(x + 5, y + 3), (x + 5, y + h - 3)],
                   stroke=stroke, sw=1.4), "shape")
    T(f, x + w/2, y + h/2 + z*.34, s, z, bold, col, "middle", w - 15)


def L(f, *points, col=INK, width=1.55, arrow=True, dash=False):
    f.line(list(points), col, width, arrow, dash)


def H(f, mark, title, note, height):
    T(f, 27, 36, f"({mark})  {title}", 26, True)
    T(f, W-27, 35, note, 17, False, SECONDARY, "end")
    L(f, (27, 54), (W-27, 54), col=RULE, width=1.1, arrow=False)
    L(f, (27, height-25), (W-27, height-25), col=RULE,
      width=1.1, arrow=False)


def QAM_BER():
    f = d.Figure("DMT_Hardware_A_Tone_datapath", W, 720)
    H(f, "a", "Per-tone QAM and BER datapath",
      "one tone / clock   ·   3 register stages", 720)

    # Four parallel threshold qualifications; their output feeds one encoder.
    R(f, 27, 90, 420, 581, WHITE, FAINT, 1.4, True)
    T(f, 46, 122, "QAM SELECTION", 20, True)
    T(f, 47, 151, "base θ<sup>0</sup><sub>M</sub>", 16, False, SECONDARY)
    T(f, 130, 151, "margin m<sub>M</sub>", 16, False, SECONDARY)
    C(f, 272, 102, 155, 43, "γ<sub>k,dB</sub>  (Q16)", 18,
      BLUE_PALE, BLUE, BLUE, True)
    L(f, (345,145), (345,173), col=BLUE, width=1.35)
    T(f, 372, 165, "×4", 14, False, BLUE)
    for idx, (mod, base) in enumerate(((256,24),(64,18),(16,12),(4,6))):
        y = 173 + idx*59
        C(f, 47, y, 57, 42, f"{base}", 19, PALE)
        T(f, 114, y+28, "+", 22, True, SECONDARY, "middle")
        C(f, 127, y, 105, 42, f"m<sub>{mod}</sub>", 19,
          BLUE_PALE, BLUE, BLUE)
        L(f, (232,y+21), (251,y+21), width=1.25)
        C(f, 251, y, 115, 42, f"γ ≥ θ<sub>{mod}</sub>", 18,
          WHITE, INK)
        L(f, (366,y+21), (382,y+21), width=1.2)
        C(f, 382, y+4, 44, 34, f"c<sub>{mod}</sub>", 15, PALE)
        L(f, (426,y+21), (433,y+21), arrow=False, width=1.15)
        f.dot(433, y+21)
    L(f, (433,194), (433,449), (323,449), (323,469),
      width=1.2)
    C(f, 169, 469, 255, 83, "priority encoder", 20,
      BLUE_PALE, BLUE, BLUE, True)
    T(f, 297, 537, "256  >  64  >  16  >  4  >  OFF", 16,
      False, SECONDARY, "middle")
    # The encoded tier becomes the registered upper lane of the pipeline.
    L(f, (424,510), (463,510), (463,168), (489,168),
      col=BLUE, width=1.6)
    T(f, 443, 499, "M<sub>k</sub>", 16, False, BLUE, "middle")

    # Three stage registers carry the selected QAM tier along a clear top rail.
    T(f, 536, 121, "R1", 18, True, BLUE, "middle")
    T(f, 951, 121, "R2", 18, True, BLUE, "middle")
    T(f, 1376, 121, "R3", 18, True, BLUE, "middle")
    C(f, 489, 143, 94, 49, "M<sub>1</sub>", 24,
      BLUE_PALE, BLUE, BLUE, True, True)
    C(f, 904, 143, 94, 49, "M<sub>2</sub>", 24,
      BLUE_PALE, BLUE, BLUE, True, True)
    C(f, 1329, 143, 94, 49, "M<sub>3</sub>", 24,
      BLUE_PALE, BLUE, BLUE, True, True)
    L(f, (583,168), (904,168), col=BLUE, width=1.75)
    L(f, (998,168), (1329,168), col=BLUE, width=1.75)
    L(f, (1423,168), (1480,168), col=BLUE, width=1.75)
    T(f, 1478, 153, "M<sub>k</sub>", 19, True, BLUE, "end")

    # Four physical coefficient entries per bank.  Both banks are indexed by
    # the tier register immediately upstream of them.
    f.dot(625,168,BLUE)
    L(f, (625,168), (625,254), col=BLUE, width=1.35)
    R(f, 554, 254, 143, 132, WHITE, INK, 1.35)
    T(f, 625, 282, "K<sub>M</sub> bank", 20, True, anchor="middle")
    for i, mod in enumerate((256,64,16,4)):
        C(f, 567, 292+i*21, 117, 21, f"K<sub>{mod}</sub>", 15, PALE)
    f.dot(1057,168,BLUE)
    L(f, (1057,168), (1057,254), col=BLUE, width=1.35)
    R(f, 1009, 254, 143, 132, WHITE, INK, 1.35)
    T(f, 1080, 282, "C<sub>M</sub> bank", 20, True, anchor="middle")
    for i, mod in enumerate((256,64,16,4)):
        C(f, 1022, 292+i*21, 117, 21, f"C<sub>{mod}</sub>", 15, PALE)

    # The lower lane shows the actual two-multiplier LUT approximation.
    C(f, 495, 490, 147, 50, "γ<sub>k,lin</sub>", 22,
      BLUE_PALE, BLUE, BLUE, True, True)
    T(f, 493, 473, "Q16 input / R1", 16, False, SECONDARY)
    f.circle(747, 515, 23, RED_PALE, RED, 1.6)
    T(f, 747, 525, "×", 34, True, RED, "middle")
    T(f, 747, 566, "16 × 32", 17, False, SECONDARY, "middle")
    L(f, (642,515), (724,515), width=1.75)
    L(f, (625,386), (625,415), (747,415), (747,492),
      width=1.5)
    T(f, 667, 407, "K<sub>M</sub>", 17, False, SECONDARY)
    L(f, (770,515), (821,515), width=1.75)
    T(f, 795, 502, "Y", 20, True, anchor="middle")
    R(f, 821, 459, 176, 144, BLUE_PALE, BLUE, 1.4)
    T(f, 909, 481, "Y field registers", 17, True, BLUE,
      "middle", 166)
    for y, txt in ((489,"f = Y[31:27]"),(527,"q = Y[36:32]"),
                   (565,"s = [Y ≥ 24]")):
        C(f, 833, y, 152, 31, txt, 17, WHITE, RULE)

    R(f, 1025, 454, 130, 109, WHITE, INK, 1.4)
    T(f, 1090, 483, "LUT", 21, True, anchor="middle")
    T(f, 1090, 517, "f → L[f]", 19, False, BLUE, "middle")
    T(f, 1090, 546, "32 × 17 bit", 16, False, SECONDARY,
      "middle")
    L(f, (985,504), (1025,504), col=BLUE, width=1.45)
    f.circle(1197, 515, 23, RED_PALE, RED, 1.6)
    T(f, 1197, 525, "×", 34, True, RED, "middle")
    T(f, 1197, 566, "16 × 17", 17, False, SECONDARY,
      "middle")
    L(f, (1155,515), (1174,515), width=1.6)
    L(f, (1080,386), (1080,415), (1197,415), (1197,492),
      width=1.5)
    T(f, 1130, 407, "C<sub>M</sub>", 17, False, SECONDARY)

    C(f, 1241, 486, 91, 58, "≫ q", 24, WHITE, INK, INK, True)
    L(f, (1220,515), (1241,515), width=1.65)
    T(f, 1287, 566, "[31:8] · Q24", 16, False, SECONDARY,
      "middle")
    # q and s travel on separate lower tracks; M3 supplies the OFF guard.
    L(f, (985,542), (1013,542), (1013,630), (1287,630),
      (1287,544), col=BLUE, width=1.3)
    T(f, 1044, 623, "q", 17, False, BLUE)
    L(f, (985,580), (1002,580), (1002,668), (1385,668),
      (1385,550), col=BLUE, width=1.3)
    T(f, 1037, 661, "s", 17, False, BLUE)
    L(f, (1332,515), (1350,515), width=1.65)
    R(f, 1350, 479, 70, 71, WHITE, INK, 1.4)
    T(f, 1385, 506, "0 / p", 17, True, anchor="middle")
    T(f, 1385, 534, "SEL", 18, True, anchor="middle")
    T(f, 1385, 577, "s ∨ OFF", 16, False, SECONDARY,
      "middle")
    f.dot(1440,168,BLUE)
    L(f, (1440,168), (1440,444), (1396,444), (1396,479),
      col=BLUE, width=1.3)
    T(f, 1451, 433, "M=0", 16, False, BLUE, "end")
    C(f, 1425, 490, 66, 51, "P<sub>b,k</sub>", 17,
      BLUE_PALE, BLUE, BLUE, True, True)
    L(f, (1420,515), (1425,515), width=1.3)
    L(f, (1491,515), (1497,515), col=BLUE, width=1.3)
    T(f, 1482, 566, "Q24", 16, True, BLUE, "end")

    T(f, 47, 634, "base θ<sup>0</sup> = (24, 18, 12, 6) dB",
      17, False, SECONDARY)
    T(f, 47, 659, "M = 0 → OFF", 17, False, SECONDARY)
    T(f, 1480, 685, "solid: data   ·   blue cells: clocked values",
      15, False, SECONDARY, "end")
    return f


def SEARCH_ENGINE():
    f = d.Figure("DMT_Hardware_B_Search_engine", W, 830)
    H(f, "b", "Scan, decision, and margin-update hardware",
      "one reused tone core   ·   255-tone scan", 830)

    # A single FSM controls both the address scan and the lower writeback path.
    L(f, (1330,131), (1330,90), (135,90), (135,132),
      col=RED, width=1.25, dash=True)
    L(f, (630,90), (630,132), col=RED, width=1.25, dash=True)
    f.dot(630,90,RED)
    T(f, 741, 83, "scan / clear", 16, False, RED, "middle")

    # Tone address and SNR pair are read once per requested address.
    R(f, 27, 131, 205, 254, WHITE, FAINT, 1.4, True)
    T(f, 44, 160, "TONE ADDRESS", 19, True)
    C(f, 44, 178, 171, 45, "k = 1 … 255", 21,
      BLUE_PALE, BLUE, BLUE, True, True)
    L(f, (129,223), (129,248), width=1.35)
    R(f, 44, 248, 171, 105, WHITE, INK, 1.25)
    T(f, 129, 274, "SNR MEMORY", 18, True,
      anchor="middle")
    C(f, 59, 285, 141, 26, "γ<sub>k,dB</sub>", 17, PALE)
    C(f, 59, 317, 141, 26, "γ<sub>k,lin</sub>", 17, PALE)

    # This is the actual pipelined hardware detailed in figure (a).
    R(f, 255, 131, 207, 254, WHITE, INK, 1.4, True)
    T(f, 273, 160, "TONE CORE  (a)", 18, True)
    C(f, 276, 191, 165, 52, "QAM selector", 19,
      WHITE, INK, INK, True)
    L(f, (358,243), (358,265), width=1.25)
    C(f, 276, 265, 165, 64, "BER · LUT32", 20,
      WHITE, INK, INK, True)
    L(f, (215,298), (237,298), (237,217), (276,217),
      width=1.45)
    L(f, (215,330), (246,330), (246,297), (276,297),
      width=1.45)
    L(f, (462,295), (484,295), width=1.7)
    T(f, 358, 357, "out: M<sub>k</sub>, P<sub>b,k</sub>", 17,
      True, BLUE, "middle")

    # Streaming accumulators.  Tier registers are shown as four clocked lanes.
    R(f, 484, 131, 326, 254, WHITE, FAINT, 1.4, True)
    T(f, 500, 160, "SCAN ACCUMULATORS", 19, True)
    C(f, 501, 183, 123, 38, "b(M<sub>k</sub>)", 19, PALE)
    C(f, 649, 183, 143, 38, "b<sub>k</sub> · P<sub>k</sub>", 19,
      PALE)
    L(f, (624,202), (649,202), width=1.15)
    L(f, (563,221), (563,247), width=1.25)
    L(f, (721,221), (721,247), width=1.25)
    C(f, 501, 247, 123, 48, "B = Σb<sub>k</sub>", 19,
      BLUE_PALE, BLUE, BLUE, True, True)
    C(f, 649, 247, 143, 48, "E<sub>w</sub> = Σb<sub>k</sub>P<sub>k</sub>",
      18, BLUE_PALE, BLUE, BLUE, True, True)
    T(f, 501, 326, "4 × (E<sub>M</sub>, N<sub>M</sub>) REGISTERS", 16,
      True, SECONDARY)
    for i, mod in enumerate((256,64,16,4)):
        x=501+i*73
        C(f, x, 337, 69, 32, str(mod), 17,
          WHITE, RULE, INK, True, True)
    L(f, (810,263), (822,263), (822,222), (847,222),
      width=1.5)
    L(f, (810,353), (842,353), (842,333), (858,333),
      width=1.5)

    # Two true combinational decision structures share the statistics.
    R(f, 829, 131, 337, 254, WHITE, FAINT, 1.4, True)
    T(f, 846, 160, "DECISION DATAPATH", 19, True)
    R(f, 847, 175, 301, 88, PALE, RULE, 1.05)
    T(f, 858, 194, "TARGET CMP", 17, True)
    C(f, 859, 207, 89, 35, "G · B", 18, WHITE)
    T(f, 960, 232, "≥", 25, True, anchor="middle")
    C(f, 979, 207, 128, 35, "10<sup>4</sup> · E<sub>w</sub>", 18, WHITE)
    T(f, 862, 255, "G = 16,617,216 (Q24)", 14,
      False, SECONDARY)
    L(f, (1148,222), (1185,222), col=BLUE, width=1.6)
    T(f, 1171, 210, "pass", 15, False, BLUE, "middle")
    R(f, 847, 277, 301, 105, PALE, RULE, 1.05)
    T(f, 858, 296, "WORST-TIER CIRCUIT", 17, True)
    C(f, 858, 313, 62, 40, "MUX", 16)
    C(f, 933, 313, 65, 40, "32×9", 16,
      RED_PALE, RED, RED, True)
    C(f, 1011, 313, 65, 40, "R × 6", 16,
      BLUE_PALE, BLUE, BLUE, True, True)
    C(f, 1089, 313, 56, 40, "CMP", 16)
    for a,b in ((920,933),(998,1011),(1076,1089)):
        L(f, (a,333), (b,333), width=1.1)
    T(f, 858, 376, "E<sub>i</sub>N<sub>j</sub>  vs  E<sub>j</sub>N<sub>i</sub>",
      15, False, SECONDARY)
    L(f, (1148,333), (1185,333), col=BLUE, width=1.6)
    T(f, 1171, 323, "j<sub>w</sub>", 16, False, BLUE,
      "middle")

    # Clocked phase and score registers; red dashed outputs fan out below.
    R(f, 1185, 131, 289, 254, WHITE, INK, 1.4, True)
    T(f, 1201, 160, "SEARCH CONTROL", 19, True)
    for x,w,s in ((1201,75,"UP"),(1283,88,"TRIAL"),
                  (1378,81,"COMMIT")):
        C(f, x, 177, w, 38, s, 14 if s=="COMMIT" else 16,
          RED_PALE if s=="UP" else BLUE_PALE if s=="TRIAL" else PALE,
          RULE, RED if s=="UP" else BLUE if s=="TRIAL" else INK,
          True, True)
    C(f, 1201, 230, 258, 37,
      "trial j: 4 → 16 → 64 → 256", 17, PALE)
    C(f, 1201, 279, 112, 42, "B* / found", 16,
      BLUE_PALE, BLUE, BLUE, True, True)
    C(f, 1324, 279, 135, 42, "B &gt; B*", 18,
      WHITE, INK, INK, True)
    L(f, (1313,300), (1324,300), width=1.1)
    T(f, 1201, 346, "base_we   ·   best_we", 16, False, RED,
      maxw=255)
    T(f, 1201, 372, "src  ·  j  ·  ±Δ  ·  wb select", 15,
      False, RED, maxw=255)
    L(f, (1325,385), (1325,430), (544,430),
      col=RED, width=1.3, dash=True, arrow=False)
    L(f, (1325,430), (1304,430), col=RED,
      width=1.3, dash=True, arrow=False)
    f.dot(1325,430,RED)
    for x, lab in ((548,"source"),(686,"tier j"),(813,"±Δ"),
                   (965,"write j"),(1304,"wb")):
        L(f, (x,430), (x,463), col=RED, width=1.25, dash=True)
        T(f, x, 423, lab, 15, False, RED, "middle")

    # Three actual copies of a four-word Q16 vector.
    R(f, 27, 466, 420, 247, WHITE, FAINT, 1.4, True)
    T(f, 44, 491, "MARGIN REGISTERS", 19, True)
    for x,mod in zip((132,208,284,360),(256,64,16,4)):
        T(f, x+33, 509, str(mod), 16, True, SECONDARY,
          "middle")
    for name,y,bg,edge in (("m",516,BLUE_PALE,BLUE),
                           ("m<sub>0</sub>",584,WHITE,RULE),
                           ("m*",652,WHITE,RULE)):
        T(f, 46, y+(31 if name=="m" else 23), name, 23, True,
          BLUE if name=="m" else INK)
        for x,mod in zip((132,208,284,360),(256,64,16,4)):
            sym = (f"m<sub>{mod}</sub>" if name=="m" else
                   f"m<sub>0,{mod}</sub>" if name=="m<sub>0</sub>" else
                   f"m*<sub>{mod}</sub>")
            C(f, x, y, 70, 45, sym, 17, bg, edge, INK, False, True)
    T(f, 45, 628, "base_we", 14, False, BLUE)
    T(f, 45, 696, "best_we", 14, False, RED)
    L(f, (447,538), (455,538), (455,398), (386,398),
      (386,385), col=BLUE, width=1.65)
    T(f, 351, 412, "m[4]", 16, True, BLUE)

    # Source selection, one arithmetic lane, and three physical bypass lanes.
    R(f, 467, 466, 605, 247, WHITE, FAINT, 1.4, True)
    T(f, 486, 491, "ONE-COORDINATE UPDATE", 19, True)
    L(f, (447,538), (510,538), width=1.45)
    L(f, (447,606), (484,606), (484,601), (510,601),
      width=1.45)
    T(f, 475, 530, "UP", 14, False, BLUE, "middle")
    T(f, 475, 597, "TRIAL", 14, False, BLUE, "middle")
    f.poly([(510,517),(582,538),(582,584),(510,605)],
           WHITE, INK, 1.4)
    T(f, 548, 570, "2:1", 20, True, anchor="middle")
    L(f, (582,561), (628,561), width=1.55)
    f.dot(610,561)
    f.poly([(628,535),(706,548),(706,578),(628,591)],
           WHITE, INK, 1.4)
    T(f, 668, 568, "4:1", 20, True, anchor="middle")
    L(f, (706,561), (765,561), width=1.5)
    C(f, 765, 535, 94, 54, "± Δ", 25,
      RED_PALE, RED, RED, True)
    L(f, (859,561), (913,561), col=RED, width=1.6)
    C(f, 913, 530, 90, 61, "1:4", 21, WHITE, INK,
      INK, True)
    L(f, (610,561), (610,677), (957,677), (957,591),
      col=SECONDARY, width=1.35)
    T(f, 803, 668, "3 unchanged lanes", 17,
      False, SECONDARY, "middle")
    T(f, 638, 616, "selected j", 15, False, SECONDARY)

    # Independent base and best vectors reach the final 3:1 MUX on two lower
    # tracks.  The long outside rail is only m_next returning to active m.
    L(f, (447,606), (458,606), (458,730), (1087,730),
      (1087,591), (1101,591), width=1.35)
    L(f, (447,674), (450,674), (450,751), (1094,751),
      (1094,661), (1101,661), width=1.35)
    T(f, 731, 725, "m<sub>0</sub> (restore)", 15,
      False, SECONDARY, "middle")
    T(f, 731, 747, "m* (commit)", 15,
      False, SECONDARY, "middle")
    L(f, (1003,561), (1067,561), (1067,526), (1101,526),
      col=RED, width=1.6)
    R(f, 1101, 466, 373, 247, WHITE, INK, 1.4, True)
    T(f, 1118, 491, "WRITEBACK", 19, True)
    C(f, 1118, 509, 143, 34, "updated m′", 17,
      RED_PALE, RULE, RED)
    C(f, 1118, 574, 143, 34, "base m<sub>0</sub>", 17)
    C(f, 1118, 644, 143, 34, "best m*", 17)
    f.poly([(1310,512),(1398,531),(1398,665),(1310,684)],
           WHITE, INK, 1.5)
    T(f, 1355, 607, "3:1", 23, True, anchor="middle")
    for y in (526,591,661):
        L(f, (1261,y), (1310,y), width=1.3)
    L(f, (1398,600), (1487,600), (1487,786),
      (14,786), (14,538), (132,538), width=1.65)
    T(f, 741, 780, "m<sub>next</sub>   [4 × Q16 words]", 17,
      True, BLUE, "middle")
    T(f, 1468, 803, "solid: data   ·   dashed red: control",
      15, False, SECONDARY, "end")
    return f


def export_figure(f, caption):
    checks = f.save()
    name = f.name
    pdf = OUT / f"{name}.pdf"
    rd = PdfReader(pdf)
    wr = PdfWriter()
    for page in rd.pages:
        page.scale_by(170/210)
        wr.add_page(page)
    with pdf.open("wb") as stream:
        wr.write(stream)
    doc = fitz.open(pdf)
    doc[0].get_pixmap(dpi=360, alpha=False).save(OUT/f"{name}.png")
    doc[0].get_pixmap(matrix=fitz.Matrix(2.4,2.4), alpha=False).save(
        OUT/f"{name}_preview.png")
    (OUT/f"{name}_caption.md").write_text(caption, encoding="utf-8")
    return checks


def main():
    c1 = ("**Fig. X(a).** Per-tone QAM selection and Q24 BER datapath. "
          "Four Q16 base thresholds (24, 18, 12, and 6 dB) are combined "
          "with four QAM-specific margins; parallel qualification and a "
          "priority encoder register the highest admissible tier M. "
          "The selected tier addresses K and C coefficient banks. "
          "The first multiplier forms Y=K_M γ_{k,lin}; its registered "
          "fraction f addresses a shared 32-word exponential LUT, while "
          "q controls the shift. The second multiplier forms C_M L[f]. "
          "A cutoff at Y≥24 and the OFF tier force the Q24 BER output to "
          "zero. The three registered tier symbols show pipeline alignment.\n")
    c2 = ("**Fig. X(b).** Shared scan and margin-search hardware. "
          "One per-tone core from Fig. X(a) evaluates 255 SNR entries for "
          "each margin-vector setting. Global accumulators B and E_w feed "
          "the BER-target comparator; four E_M,N_M register lanes feed a "
          "shared 32×9 cross-product and worst-tier selector. The controller "
          "stores the active m, accepted base m0, best trial m*, and a "
          "4→16→64→256 trial index. The source and tier MUXes select one "
          "coordinate for a shared Q16 ±Δ ALU; the other three coordinates "
          "bypass that ALU. A three-input writeback MUX updates m, restores "
          "m0 between trials, or commits m*. Solid nets carry data; dashed "
          "red nets carry control. The target comparator uses a conservative "
          "Q24 guard constant G=16,617,216.\n")
    checks_a = export_figure(QAM_BER(), c1)
    checks_b = export_figure(SEARCH_ENGINE(), c2)
    (OUT/"layout_checks.json").write_text(
        json.dumps({"a":checks_a,"b":checks_b},indent=2),
        encoding="utf-8")
    with zipfile.ZipFile(OUT/"DMT_two_hardware_figures_editable.zip",
                         "w",zipfile.ZIP_DEFLATED) as z:
        for f in sorted(OUT.glob("DMT_Hardware_*")):
            if not f.name.endswith("_preview.png"):
                z.write(f, f.name)
        z.write(Path(__file__), Path(__file__).name)
        z.write(Path(d.__file__), Path(d.__file__).name)
    print(json.dumps({"a":checks_a,"b":checks_b},indent=2))


if __name__ == "__main__":
    main()
