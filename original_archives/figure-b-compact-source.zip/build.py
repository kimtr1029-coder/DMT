"""Compact paper figure: connected architectural view of Q24 margin RTL.

Blocks intentionally group register arrays and FSM substates. The PDF caption
documents the omitted six product writes and candidate scan sequencing.
"""
from pathlib import Path
from html import escape
import subprocess

OUT=Path(__file__).resolve().parent
W,H=1180,345
INK='#20262c'; BLUE='#275e80'; GREY='#66717a'; SOFT='#eef1f2'; TINT='#ebf1f5'

class F:
    def __init__(self): self.s=[]
    def text(self,x,y,v,n=17,c=INK,a='middle',bold=False,serif=False):
        family='Nimbus Roman, Times New Roman, serif' if serif else 'Nimbus Sans, Arial, sans-serif'
        self.s.append(f'<text x="{x}" y="{y}" text-anchor="{a}" fill="{c}" '
                      f'font-size="{n}" font-weight="{700 if bold else 400}" '
                      f'font-family="{family}">{escape(str(v))}</text>')
    def rect(self,x,y,w,h,fill='white',c=INK,sw=1.7):
        self.s.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" '
                      f'fill="{fill}" stroke="{c}" stroke-width="{sw}"/>')
    def box(self,x,y,w,h,v,n=17,fill='white',c=INK,serif=False,bold=False):
        self.rect(x,y,w,h,fill,c)
        self.text(x+w/2,y+h/2+n*.33,v,n,c,serif=serif,bold=bold)
    def line(self,p,c=INK,sw=1.7,arrow=True):
        m=f' marker-end="url(#a-{c[1:]})"' if arrow else ''
        self.s.append(f'<polyline points="{" ".join(f"{x},{y}" for x,y in p)}" '
                      f'fill="none" stroke="{c}" stroke-width="{sw}" '
                      f'stroke-linejoin="miter"{m}/>')
    def dot(self,x,y,c=INK):
        self.s.append(f'<circle cx="{x}" cy="{y}" r="2.8" fill="{c}"/>')
    def circ(self,x,y,r,v,n=23,c=BLUE):
        self.s.append(f'<circle cx="{x}" cy="{y}" r="{r}" fill="white" stroke="{c}" stroke-width="1.8"/>')
        self.text(x,y+n*.33,v,n,c)
    def save(self):
        defs=''.join(f'<marker id="a-{c[1:]}" viewBox="0 0 10 10" '
                     f'refX="9" refY="5" markerWidth="5.5" markerHeight="5.5" '
                     f'orient="auto"><path d="M0 0L10 5L0 10Z" fill="{c}"/></marker>'
                     for c in (INK,BLUE))
        xml=(f'<svg xmlns="http://www.w3.org/2000/svg" width="180mm" '
             f'height="{180*H/W:.3f}mm" viewBox="0 0 {W} {H}">'
             f'<defs>{defs}</defs><rect width="{W}" height="{H}" fill="white"/>'
             +''.join(self.s)+'</svg>')
        p=OUT/'figure-b-compact'
        p.with_suffix('.svg').write_text(xml,encoding='utf-8')
        subprocess.run(['inkscape',str(p.with_suffix('.svg')),
                        '--export-text-to-path',f'--export-filename={p.with_suffix(".pdf")}'],
                        check=True,stdout=subprocess.DEVNULL)
        subprocess.run(['inkscape',str(p.with_suffix('.svg')),
                        '--export-width=3600',f'--export-filename={p.with_suffix(".png")}'],
                        check=True,stdout=subprocess.DEVNULL)

def main():
    f=F()
    f.text(24,31,'(b)',23,serif=True,a='start')
    f.text(78,31,'BER statistics and margin control',21,bold=True,a='start')

    # One reused per-tone estimator (shown in detail in panel a).
    f.text(80,106,'255-tone scan',17,bold=True,a='start')
    f.box(70,128,222,96,'QAM + Q24 BER',20,TINT,BLUE)
    f.text(182,198,'datapath (a)',16,BLUE)
    f.text(24,197,'m',18,BLUE,a='start',serif=True)
    f.line([(38,195),(70,195)],BLUE)

    # Two summaries share the scan. Four actual QAM E/N rows are grouped.
    f.text(345,106,'Scan statistics',17,bold=True,a='start')
    f.rect(344,120,228,104)
    f.line([(292,173),(354,173)],INK,1.9,False)
    f.dot(354,173)
    f.line([(354,146),(354,195)],INK,1.5,False)
    f.line([(354,146),(367,146)],INK)
    f.line([(354,195),(367,195)],INK)
    f.box(368,130,188,33,'Ew = Σ bₖP̂b,k  ;  B = Σ bₖ',16,SOFT,INK,serif=True)
    f.box(368,179,188,33,'Eₘ, Nₘ   [4 QAM tiers]',17,SOFT,INK,serif=True)

    # Target validity V and worst tier W are the two controller inputs.
    f.text(626,106,'Decision',17,bold=True,a='start')
    f.line([(556,146),(624,146)],INK)
    f.box(625,127,240,39,'10⁴ Ew ≤ 16 617 216 B',17,SOFT,INK,serif=True)
    f.line([(865,146),(916,146)],BLUE,1.9)
    f.text(891,136,'V',16,BLUE,serif=True)
    f.line([(556,195),(624,195)],INK)
    f.rect(625,177,240,68)
    f.box(633,186,72,31,'E,N sel',16,TINT,BLUE)
    f.line([(705,202),(719,202)],BLUE)
    f.circ(734,202,14,'×',22,BLUE)
    f.line([(748,202),(754,202)],BLUE)
    f.box(755,186,100,31,'pairwise max',15,TINT,BLUE)
    f.line([(855,202),(916,202)],BLUE,1.9)
    f.text(891,192,'W',16,BLUE,serif=True)
    f.text(735,238,'shared 32 × 9',15,BLUE)

    # The FSM and its refinements form one block with three state families.
    f.text(918,106,'Margin controller',17,bold=True,a='start')
    f.rect(917,120,156,108)
    f.text(995,151,'UP · DOWN · FINAL',16,INK)
    f.text(995,183,'Δ  /  best B',16,INK,serif=True)
    f.line([(1073,173),(1094,173)],INK)
    f.box(1095,149,80,48,'k, M, v',17,TINT,BLUE,serif=True)
    f.text(1135,216,'255 outputs',15,GREY)

    # During FINAL, the scanned tier reaches the output controller directly;
    # k is generated by the controller's 255-address scan.
    f.line([(292,213),(320,213),(320,267),(942,267),(942,228)],INK,1.4)
    f.text(698,283,'M to FINAL stream',15,GREY)

    # A single feedback loop closes the whole drawing. The QAM/BER datapath
    # and scan statistics are reused for UP, DOWN and FINAL scans.
    f.text(74,269,'Four margin registers',17,bold=True,a='start')
    f.rect(69,279,355,43)
    for i,m in enumerate([256,64,16,4]):
        x=77+86*i
        f.box(x,286,79,29,'m'+str(m),17,TINT,BLUE,serif=True)
    f.line([(996,228),(996,301),(424,301)],BLUE,1.9)
    f.line([(69,301),(38,301),(38,195)],BLUE,1.9,False)
    f.dot(38,195,BLUE)
    f.text(659,320,'margin update · rescan',15,BLUE)
    f.save()

if __name__=='__main__': main()
