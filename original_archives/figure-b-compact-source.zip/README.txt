Figure (b): BER statistics and margin control
============================================

Suggested manuscript caption:
Fig. X(b). Shared scan and decision path for BER-driven margin search. The four
QAM margins feed the same 255-tone datapath during updates, refinement and the
final allocation scan. The worst occupied QAM tier is selected using one
time-multiplexed multiplier.

RTL mapping and intentional grouping
------------------------------------
- Based on FINAL_Q24_REFINE_margin_ctrl_20260812.v and its Q24 datapath.
- B = sum_k b_k; Ew = sum_k b_k*P_hat_b,k, with b_k in {0,2,4,6,8}.
- The depicted validity comparison is bypassed as valid for B=0 in the RTL.
  Otherwise the exact integer check is 10000*Ew <= 16617216*B.
- E_M and N_M are four per-tier sums/counts collected in an UP scan. They are
  omitted from refinement scans. The worst occupied tier maximizes E_M/N_M.
- The 32-by-9 multiplier evaluates six cross products in six separate states,
  followed by pairwise decisions. It is one reused hardware multiplier.
- UP increments the selected tier margin by 6554 Q16 codes (about 0.1 dB),
  then repeats the scan. DOWN sequentially tries a single decrement for each
  eligible tier in the order 4, 16, 64, 256 and retains a feasible candidate
  with the largest B. FINAL emits 255 (carrier index, tier, valid) records.
- The lower black route shows the QAM-tier stream from the datapath to the
  controller during FINAL. The lower blue route shows margin-register feedback
  into the reused datapath. No fixed total-bit count is implied.

Use the vector PDF in a full-width (two-column) figure. The SVG retains editable
text; the PDF has outlined text for reproducible typesetting. The PNG is a
review preview. build.py generates all three files.
