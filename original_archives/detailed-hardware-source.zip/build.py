from pathlib import Path
from html import escape
import subprocess
import zipfile

OUT = Path(__file__).resolve().parent
INK = '#161a1e'
BLUE = '#235a80'
RED = '#c3262e'
GREY = '#67717b'
PALE = '#ecf2f6'
PINK = '#fae9ea'
SOFT = '#f2f3f4'

class Fig:
    def __init__(self, width, height):
        self.w, self.h, self.items = width, height, []
    def text(self, x, y, value, size=18, color=INK, anchor='middle', bold=False, serif=False):
        font = 'Nimbus Roman, Times New Roman, serif' if serif else 'Nimbus Sans, Arial, sans-serif'
        self.items.append(f'<text x="{x}" y="{y}" text-anchor="{anchor}" fill="{color}" font-family="{font}" font-weight="{700 if bold else 400}" font-size="{size}">{escape(value)}</text>')
    def rect(self, x, y, w, h, fill='white', stroke=INK, sw=1.6, radius=0):
        self.items.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{radius}" fill="{fill}" stroke="{stroke}" stroke-width="{sw}"/>')
    def box(self,x,y,w,h,label,size=18,fill='white',stroke=INK,bold=False,serif=False):
        self.rect(x,y,w,h,fill,stroke)
        self.text(x+w/2,y+h/2+size*.33,label,size,stroke,bold=bold,serif=serif)
    def path(self,points,color=INK,sw=1.7,arrow=True,dash=None):
        xy=' '.join(f'{x},{y}' for x,y in points)
        ds=f' stroke-dasharray="{dash}"' if dash else ''
        ma=f' marker-end="url(#{"arr-"+color[1:]})"' if arrow else ''
        self.items.append(f'<polyline points="{xy}" fill="none" stroke="{color}" stroke-width="{sw}" stroke-linejoin="miter"{ds}{ma}/>')
    def bracket(self,x,y,w,h,color=INK):
        self.path([(x+9,y),(x,y),(x,y+h),(x+9,y+h)],color,1.5,False)
        self.path([(x+w-9,y),(x+w,y),(x+w,y+h),(x+w-9,y+h)],color,1.5,False)
    def circle(self,x,y,r,label,size=23,color=INK,fill='white'):
        self.items.append(f'<circle cx="{x}" cy="{y}" r="{r}" stroke="{color}" stroke-width="1.8" fill="{fill}"/>')
        self.text(x,y+size*.34,label,size,color)
    def reg(self,x,y,w,h,name,sections):
        self.text(x+w/2,y-12,name,18,BLUE,bold=True)
        self.rect(x,y,w,h,SOFT,INK,1.7)
        rh=h/len(sections)
        for i,value in enumerate(sections):
            if i:
                self.path([(x,y+i*rh),(x+w,y+i*rh)],GREY,1,False)
            self.text(x+w/2,y+rh*(i+.5)+5,value,16,INK,serif=True)
        # Conventional clock mark on the lower left.
        self.path([(x,y+h-16),(x+8,y+h-11),(x,y+h-6)],INK,1.1,False)
    def export(self,name):
        mark=''.join(f'<marker id="arr-{c[1:]}" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="5.2" markerHeight="5.2" orient="auto"><path d="M0,0 L10,5 L0,10 Z" fill="{c}"/></marker>' for c in [INK,BLUE,RED,GREY])
        content=f'<svg xmlns="http://www.w3.org/2000/svg" width="180mm" height="{180*self.h/self.w:.4f}mm" viewBox="0 0 {self.w} {self.h}"><defs>{mark}</defs><rect x="0" y="0" width="{self.w}" height="{self.h}" fill="white"/>'+''.join(self.items)+'</svg>'
        svg=OUT/(name+'.svg');svg.write_text(content,encoding='utf-8')
        for ext in ['pdf','png']:
            command=['inkscape',str(svg),'--export-filename='+str(OUT/(name+'.'+ext))]
            command+=['--export-text-to-path'] if ext=='pdf' else ['--export-width=4000']
            subprocess.run(command,check=True,stdout=subprocess.DEVNULL)


def datapath():
    f=Fig(1180,466)
    f.text(21,30,'(a)',22,INK,anchor='start',serif=True)
    f.text(65,30,'QAM-tier selection',18,INK,bold=True,anchor='start')
    f.text(423,30,'Per-tier coefficients',18,INK,bold=True,anchor='start')
    f.text(819,30,'Fractional-exponent LUT',18,INK,bold=True,anchor='start')

    # Four truly parallel threshold comparators. Both operands of each adder are visible.
    f.bracket(26,55,283,212)
    f.text(39,53,'M',14,GREY,serif=True)
    f.text(114,53,'T, m',14,GREY,serif=True)
    f.text(242,53,'γdB ≥ θ',14,GREY,serif=True)
    for j,(m,th) in enumerate([(256,24),(64,18),(16,12),(4,6)]):
        y=65+j*50
        red=(m==64)
        c=RED if red else INK
        back=PINK if red else 'white'
        f.box(32,y+7,40,31,str(m),16,back,c,bold=red)
        f.box(81,y+3,79,19,f'{th} dB',14,back,c)
        f.box(81,y+22,79,19,f'm{m}',14,back,c,serif=True)
        f.path([(160,y+13),(175,y+13)],c,1.4,False)
        f.path([(160,y+32),(175,y+32)],c,1.4,False)
        f.circle(188,y+22,12,'+',17,c)
        f.path([(200,y+22),(217,y+22)],c,1.5)
        f.box(218,y+7,51,31,'≥',24,back,c)
        f.path([(269,y+22),(286,y+22)],c,1.5)
    f.items.append(f'<path d="M286,69 L307,92 L307,238 L286,259 Z" fill="white" stroke="{INK}" stroke-width="1.8"/>')
    f.text(296,170,'P',17)
    f.path([(307,166),(341,166),(341,278),(351,278),(351,306)],INK)
    f.text(326,156,'M₁',16,INK,serif=True)

    # Two aligned coefficient rows; highlight one tier only as a tracing example.
    f.bracket(412,57,268,105)
    for i,m in enumerate([256,64,16,4]):
        x=423+61*i
        c=RED if m==64 else INK
        bg=PINK if m==64 else SOFT
        f.text(x+28,56,str(m),13,c)
        f.box(x,68,55,34,'K'+str(m),15,bg,c,serif=True)
        f.box(x,111,55,34,'C'+str(m),15,bg,c,serif=True)
    # K port is drawn directly; C port is a named coefficient connection to avoid crossing f.
    f.path([(545,162),(545,250),(442,250),(442,329)],INK,1.6)
    f.text(452,303,'K(M₁)',16,BLUE,anchor='start',serif=True)

    # ROM is shown as a real 32-entry (4-by-8) bank, with an indexed active cell.
    f.rect(776,65,344,110,'white',INK,1.5)
    for k in range(32):
        row,col=divmod(k,8)
        x,y=790+40*col,77+21*row
        active=(k==11)
        f.rect(x,y,35,17,PALE if active else SOFT,BLUE if active else '#aeb8c1',1.1 if active else .7)
        if active:
            f.text(x+17,y+13,'f',12,BLUE,serif=True)
    f.items.append(f'<text x="948" y="207" text-anchor="middle" fill="{BLUE}" font-family="Nimbus Roman, Times New Roman, serif" font-size="17">L[f] = 2<tspan baseline-shift="super" font-size="70%">−f/32</tspan>  ·  32 × 17 bits</text>')

    # Three physical register boundaries and the two actual arithmetic multipliers.
    f.reg(351,306,49,91,'R1',['M₁','γlin','v'])
    f.text(297,355,'γlin',19,INK,anchor='start',serif=True)
    f.path([(330,351),(351,351)],INK)
    f.circle(442,351,22,'×',29)
    f.path([(400,351),(420,351)],INK,1.9)
    f.path([(464,351),(510,351)],INK,1.9)
    f.text(487,339,'Y',17,INK,serif=True)
    f.text(443,394,'16 × 32',14,GREY)
    f.reg(510,294,113,100,'R2',['M₂, v','f = Y[31:27]','q = Y[36:32]','s = (Y ≥ 24)'])

    # f addresses the 32-word ROM; ROM output joins C at the second multiplier.
    f.path([(623,331),(665,331),(665,218),(796,218),(796,175)],BLUE,1.6)
    f.text(638,321,'f',16,BLUE,serif=True)
    f.path([(1060,175),(1060,236),(752,236),(752,351),(771,351)],BLUE,1.7)
    f.text(1035,231,'L[f]',15,BLUE,serif=True)
    f.circle(793,351,22,'×',29)
    f.text(793,311,'C(M₂)',17,BLUE,serif=True)
    f.path([(793,320),(793,329)],BLUE,1.5)
    f.text(793,394,'16 × 17',14,GREY)
    f.path([(815,351),(830,351)],INK,1.8)
    f.box(831,329,74,44,'[31:8]',18)
    f.path([(905,351),(926,351)],INK,1.8)
    f.box(927,329,69,44,'≫ q',21)
    f.path([(996,351),(1014,351)],INK,1.8)
    f.box(1015,329,67,44,'0 / P',16)
    f.path([(1082,351),(1100,351)],INK,1.8)
    f.reg(1100,308,63,88,'R3',['M₃','P̂ Q24','v'])
    f.path([(1163,351),(1178,351)],INK)

    # Separate q and saturation paths occupy two reserved rows beneath the datapath.
    f.path([(623,356),(640,356),(640,414),(959,414),(959,373)],BLUE,1.55)
    f.text(672,407,'q',15,BLUE,serif=True)
    f.path([(623,381),(633,381),(633,442),(1048,442),(1048,373)],BLUE,1.55)
    f.text(681,435,'s  or  M₂ = OFF',15,BLUE,serif=True)
    f.export('detail-1-qam-ber')


def controller():
    f=Fig(1180,730)
    f.text(20,29,'(b)',22,INK,anchor='start',serif=True)
    f.text(69,29,'Full-band scan',18,INK,bold=True,anchor='start')
    f.text(490,29,'Bit-weighted decision',18,INK,bold=True,anchor='start')
    f.text(59,201,'Per-QAM statistics',18,INK,bold=True,anchor='start')
    f.text(581,201,'Worst-tier comparison',18,INK,bold=True,anchor='start')

    # Scan address and delayed response are explicitly distinct counters.
    f.text(21,95,'k',18,INK,serif=True)
    for i,token in enumerate(['0','1','···','254']):
        f.box(39+42*i,70,37,43,token,17,SOFT)
    f.path([(207,91),(224,91)],INK)
    f.box(225,67,189,50,'(Mₖ, P̂b,k, v)',19,PALE,BLUE,serif=True)
    f.text(319,139,'aligned R3 response',14,GREY)
    f.path([(414,92),(452,92)],INK,1.8,False)
    f.items.append(f'<circle cx="452" cy="92" r="3.0" fill="{INK}"/>')

    # Independent bit-weighted accumulators, exact guarded integer decision.
    f.path([(452,92),(477,92)],INK)
    f.path([(452,92),(452,141),(477,141)],INK)
    f.box(478,68,133,47,'Σ bₖP̂ₖ',20,SOFT,INK,serif=True)
    f.box(619,68,63,47,'Ew',21,PALE,BLUE,serif=True)
    f.box(478,117,133,47,'Σ bₖ',20,SOFT,INK,serif=True)
    f.box(619,117,63,47,'B',21,PALE,BLUE,serif=True)
    f.path([(611,92),(619,92)],INK)
    f.path([(611,141),(619,141)],INK)
    f.path([(682,92),(707,92),(707,100),(735,100)],INK)
    f.path([(682,141),(707,141),(707,125),(735,125)],INK)
    f.rect(735,68,262,99,'white',INK)
    f.text(866,111,'10⁴ Ew ≤ 16 617 216 B',20,INK,serif=True)
    f.text(865,143,'B = 0 : pass',14,GREY)
    f.path([(997,117),(1061,117)],BLUE,1.8)
    f.box(1063,92,85,49,'V = 1 / 0',17,PALE,BLUE)

    # Scan feed to one row per assigned QAM, bypassing OFF.
    f.path([(452,92),(452,170),(43,170),(43,372)],INK,1.6,False)
    f.bracket(58,220,430,158)
    f.text(110,215,'M',14,GREY,serif=True)
    f.text(263,215,'Eₘ = Σ P̂',14,GREY,serif=True)
    f.text(421,215,'Nₘ = Σ 1',14,GREY,serif=True)
    for j,m in enumerate([256,64,16,4]):
        y=225+38*j
        c=RED if m==64 else INK
        fill=PINK if m==64 else SOFT
        f.path([(43,y+16),(72,y+16)],c,1.5)
        f.box(72,y,94,32,str(m),18,fill,c,bold=(m==64))
        f.box(166,y,192,32,'E'+str(m),19,fill,c,serif=True)
        f.box(358,y,115,32,'N'+str(m),19,fill,c,serif=True)
    f.text(267,405,'UP: update the matching tier; OFF is bypassed.',15,GREY)

    # Pairwise reduction: each comparison is computed using cross-products.
    f.path([(488,244),(533,244),(533,267),(566,267)],INK)
    f.path([(488,282),(566,282)],RED)
    f.box(566,252,82,44,'MAX',19)
    f.path([(488,320),(533,320),(533,351),(566,351)],INK)
    f.path([(488,358),(566,366)],INK,1.6)
    f.box(566,336,82,44,'MAX',19)
    f.path([(648,274),(670,274)],RED)
    f.box(671,254,150,42,'W₀ = (M,E,N)',17,PINK,RED,serif=True)
    f.path([(648,358),(670,358)],INK)
    f.box(671,338,150,42,'W₁ = (M,E,N)',17,SOFT)
    f.path([(821,275),(860,275),(860,311),(882,311)],RED)
    f.path([(821,359),(860,359),(860,329),(882,329)],INK)
    f.box(883,298,83,44,'MAX',19)
    f.path([(966,320),(1005,320)],RED)
    f.box(1006,300,145,42,'worst M',18,PINK,RED)
    f.text(1124,293,'W',15,RED,serif=True)

    # One physical 32-by-9 multiplier time-shared by six FSM states.
    f.text(581,430,'One shared 32 × 9 multiplier',17,BLUE,bold=True,anchor='start')
    f.box(586,449,120,44,'E × N',21,PALE,BLUE,serif=True)
    f.path([(706,471),(741,471)],BLUE,1.7)
    f.bracket(740,443,405,73,BLUE)
    names=['E₂₅₆N₆₄','E₆₄N₂₅₆','E₁₆N₄','E₄N₁₆','Ew₀Nw₁','Ew₁Nw₀']
    for j,s in enumerate(names):
        x=751+(j//2)*131
        y=450+(j%2)*31
        f.box(x,y,120,27,f'{j+1}   {s}',16,PALE,BLUE,serif=True)

    # Margin search: test the scan first, branch on V, update only on failure.
    f.text(20,559,'Margin update and refinement',18,INK,bold=True,anchor='start')
    for j,m in enumerate([256,64,16,4]):
        f.box(25+73*j,582,67,36,'m'+str(m),16,SOFT,INK,serif=True)
    f.bracket(17,576,308,47)
    f.path([(326,600),(350,600)],INK)
    f.box(351,580,111,40,'SCAN',18,PALE,BLUE)
    f.path([(462,600),(488,600)],INK)
    f.box(489,580,72,40,'V ?',18,PALE,BLUE)
    f.text(601,588,'pass',14,BLUE)
    f.path([(561,600),(674,600)],BLUE,1.8)
    f.box(675,580,129,40,'DOWN  −Δ',17)
    f.path([(804,600),(822,600)],INK)
    f.box(823,580,129,40,'best / base',16,SOFT)
    f.path([(952,600),(970,600)],INK)
    f.box(971,580,100,40,'FINAL',18,PALE,BLUE)
    f.path([(1071,600),(1088,600)],INK)
    f.box(1089,580,70,40,'k,M,v',15,SOFT,INK,serif=True)
    f.text(1021,645,'255-tone rescan',14,GREY)

    f.text(556,643,'fail',14,RED)
    f.path([(525,620),(525,654)],RED,1.7)
    f.box(480,655,90,39,'UP  +Δ',17,PINK,RED)
    f.path([(480,674),(352,674),(352,634),(14,634),(14,600),(25,600)],RED,1.6)
    f.text(641,680,'W = worst M',16,RED,serif=True)
    f.path([(591,674),(570,674)],RED,1.6)
    f.text(679,716,'Δ = 6554 / 2¹⁶ dB ≈ 0.1 dB; DOWN trial order: 4 → 16 → 64 → 256',15,GREY)
    f.export('detail-2-statistics-search')

datapath()
controller()

(OUT/'captions-and-scope.txt').write_text(
    'Figure (a). QAM-tier selection and the Q24 BER datapath. Four parallel comparisons use T_M + m_M with T_M = {24,18,12,6} dB. The 256/64/16/4 priority selects M1, and R1 captures the tier, linear SNR and valid bit. K(M1) times linear SNR forms Q32 Y. R2 retains aligned M2/valid and only f=Y[31:27], q=Y[36:32], and s=Y>=24, not the whole Y. A 32-word, 17-bit Q16 ROM implements 2^(-f/32); a 16x17 C(M2) product is sliced [31:8], shifted by q, and zeroed when s or OFF. R3 produces Q24 BER, tier and valid. Red shows one 64-QAM example, not a fixed tier. One input per clock is accepted; R1/R2/R3 are separate boundaries. The named C(M2) port denotes the per-tier coefficient connection rather than a new circuit block.\n\n'
    'Figure (b). Accumulation, worst-tier comparison and margin search. Each 255-tone scan uses zero-based controller addresses 0..254 and sums E_w=sum b_k*estimated BER and B=sum b_k, with b_k in {8,6,4,2,0}. The guarded target test is 10000 E_w <= 16617216 B (B=0 passes). During UP only, E_M and N_M update for the assigned QAM tier. Pairwise worst-tier comparisons use the six cross-products shown in the lower right; they are scheduled through ONE shared 32x9 multiplier over six non-streaming cycles, with empty tiers bypassed and ties favoring 256>64>16>4. UP increases one worst-tier margin by Delta=6554 Q16, approximately 0.1 dB. DOWN tests eligible single-coordinate decrements in the order 4,16,64,256, restoring the accepted base margins before each trial. Among feasible trials the greatest B is saved, with ties retaining the earlier trial. FINAL rescans and streams (k,M_k,valid). The colored 64-QAM row is an example. The bottom search strip is a phase/flow abstraction, not additional parallel scan hardware. Counter limits and timeout are omitted for readability. No globally valid one-sided property is implied outside the verified design range.\n',
    encoding='utf-8')
with zipfile.ZipFile(OUT/'detailed-hardware-source.zip','w',zipfile.ZIP_DEFLATED) as z:
    for stem in ['detail-1-qam-ber','detail-2-statistics-search']:
        for ext in ['svg','pdf','png']:
            path=OUT/(stem+'.'+ext)
            z.write(path,path.name)
    z.write(OUT/'captions-and-scope.txt','captions-and-scope.txt')
    z.write(Path(__file__),'build.py')
