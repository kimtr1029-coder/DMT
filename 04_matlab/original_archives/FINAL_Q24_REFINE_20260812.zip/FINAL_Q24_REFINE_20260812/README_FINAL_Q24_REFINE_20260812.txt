FINAL Q24 + DOWNWARD REFINEMENT BUILD
Build ID: FINAL_Q24_REFINE_20260812
============================================================

This package uses new filenames so that it cannot be confused with the
previous Single Fitted-LUT MATLAB/RTL files.

MATLAB FILES
------------
1. FINAL_Q24_REFINE_channel25_20260812.m
2. FINAL_Q24_REFINE_two_null_20260812.m

For the channel-25 case, keep channel_25db.txt in this same folder.

Before running in MATLAB:
  clear all; close all; clc;
  which FINAL_Q24_REFINE_channel25_20260812 -all
  run('FINAL_Q24_REFINE_channel25_20260812.m')

The right-hand Figure 1 title MUST contain:
  Proposed Engine Allocation (Conservative Q24 LUT)

If it says "Single Fitted-LUT", MATLAB is running the old file.

FINAL COEFFICIENTS, ORDER [4 16 64 256]
---------------------------------------
K_Q16 = [50734 10213 2436 602]
C_Q16 = [12756 10206 8057 6506]
BER output fractional bits = 24
Residual guard = 2^-20

EXPECTED CHANNEL-25 PROPOSED RESULT
-----------------------------------
Margin [4 16 64 256] = [3.9002 4.1003 4.6003 5.8004] dB
Loaded bits/symbol    = 1034
Net rate              = 37.463768 Gbps
Runtime Q24 BER       = 9.900551e-05
Offline exact BER     = 8.228648e-05
Upward updates        = 188
Refinement            = 4 accepts / 20 candidate scans

EXPECTED TWO-NULL PROPOSED RESULT
---------------------------------
Margin [4 16 64 256] = [2.8002 4.9003 5.0003 5.2003] dB
Loaded bits/symbol    = 1034
Net rate              = 37.463768 Gbps
Runtime Q24 BER       = 9.853213e-05
Offline exact BER     = 8.177735e-05
Upward updates        = 185
Refinement            = 6 accepts / 28 candidate scans

RTL FILES
---------
1. FINAL_Q24_REFINE_datapath_20260812.v
2. FINAL_Q24_REFINE_margin_ctrl_20260812.v
3. FINAL_Q24_REFINE_top_20260812.v

The Verilog module names are intentionally unchanged so that the three files
instantiate one another without modifying an existing testbench hierarchy.

INTEGRITY CHECK (SHA-256)
------------------------
b96df8d7ec7d840de6d791a31a551f6a9b2c39db331df8abf2892b9b209f1fb0  FINAL_Q24_REFINE_channel25_20260812.m
9470ae41c68ca225f5f1bc765491bad1ef53842e12ca6e4ecdaecfdac6209512  FINAL_Q24_REFINE_two_null_20260812.m
5d22c81a249971c69fa89f1fffeb6066e2c3dcd85af90afa82dc5b889c971d16  FINAL_Q24_REFINE_datapath_20260812.v
716a52893f37b769f03cc6a2f4fc3d2a7d3d4512fda4b2d9884b885aeaa92271  FINAL_Q24_REFINE_margin_ctrl_20260812.v
a5585fbc91dc70648df9ac172d222f168bb3ac3ae7568836fc6c764d696c3daf  FINAL_Q24_REFINE_top_20260812.v
777700e762ca3bd160ea1b3a488d4d4c0c9c64a8e6fcc8a210afb3f6a1740d08  channel_25db.txt
